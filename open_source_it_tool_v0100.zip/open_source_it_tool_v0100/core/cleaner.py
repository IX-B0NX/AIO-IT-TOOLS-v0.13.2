from __future__ import annotations

import os
import shutil
import subprocess
import tempfile
import time
from dataclasses import dataclass
from pathlib import Path
from typing import Iterable, List, Tuple


@dataclass
class CleanerTarget:
    category: str
    name: str
    path: str
    estimated_bytes: int = 0
    risk: str = "Safe"
    action: str = "Review"
    description: str = ""
    cleanup_key: str = ""


def _folder_size(path: Path, max_items: int = 6000, max_seconds: float = 2.5) -> int:
    """Estimate folder size with hard caps so Cleaner analysis cannot hang.

    This is intentionally approximate. It favors responsiveness over crawling
    huge folder trees.
    """
    total = 0
    count = 0
    start = time.monotonic()

    try:
        if not path or str(path) in {"", "."} or not path.exists() or not path.is_dir():
            return 0
    except OSError:
        return 0

    stack = [path]
    while stack and count < max_items:
        if time.monotonic() - start > max_seconds:
            return total

        current = stack.pop()
        try:
            with os.scandir(current) as entries:
                for entry in entries:
                    try:
                        if entry.is_dir(follow_symlinks=False):
                            name = entry.name.lower()
                            if name.startswith("$") or name in {"system volume information", "$recycle.bin"}:
                                continue
                            stack.append(Path(entry.path))
                        elif entry.is_file(follow_symlinks=False):
                            total += entry.stat(follow_symlinks=False).st_size
                            count += 1
                            if count >= max_items:
                                return total
                    except OSError:
                        continue
        except OSError:
            continue

    return total


def format_bytes(num: int) -> str:
    value = float(max(0, num))
    for unit in ["B", "KB", "MB", "GB", "TB"]:
        if value < 1024:
            return f"{value:.1f} {unit}"
        value /= 1024
    return f"{value:.1f} PB"


def _env_path(var: str, *parts: str) -> Path:
    base = os.environ.get(var, "")
    if not base:
        return Path("__missing_env__") / var
    return Path(base).joinpath(*parts)


def _existing_targets(targets: Iterable[CleanerTarget]) -> List[CleanerTarget]:
    # Keep missing paths in the detail view if they are important enough to explain.
    return list(targets)


def browser_cache_targets() -> List[CleanerTarget]:
    local = os.environ.get("LOCALAPPDATA", "")
    roaming = os.environ.get("APPDATA", "")
    targets: List[CleanerTarget] = []
    candidates = []

    if local:
        local_path = Path(local)
        candidates.extend([
            ("Google Chrome Cache", local_path / "Google" / "Chrome" / "User Data" / "Default" / "Cache" / "Cache_Data"),
            ("Microsoft Edge Cache", local_path / "Microsoft" / "Edge" / "User Data" / "Default" / "Cache" / "Cache_Data"),
            ("Brave Cache", local_path / "BraveSoftware" / "Brave-Browser" / "User Data" / "Default" / "Cache" / "Cache_Data"),
        ])

    if roaming:
        roaming_path = Path(roaming)
        candidates.append(("Opera Cache", roaming_path / "Opera Software" / "Opera Stable" / "Cache" / "Cache_Data"))
        firefox_profiles = roaming_path / "Mozilla" / "Firefox" / "Profiles"
        if firefox_profiles.exists():
            for profile in firefox_profiles.iterdir():
                if profile.is_dir():
                    candidates.append((f"Firefox Cache ({profile.name})", profile / "cache2"))

    for name, path in candidates:
        targets.append(CleanerTarget(
            category="Browser & Privacy",
            name=name,
            path=str(path),
            estimated_bytes=_folder_size(path),
            risk="Safe",
            action="Cleanable",
            description="Browser cache files. Open browsers may lock some files.",
            cleanup_key="browser_cache",
        ))

    return targets


def analyze_cleaner() -> List[CleanerTarget]:
    user_temp = Path(tempfile.gettempdir())
    windows_root = Path(os.environ.get("SystemRoot", r"C:\Windows"))

    downloads = _env_path("USERPROFILE", "Downloads")
    desktop = _env_path("USERPROFILE", "Desktop")
    documents = _env_path("USERPROFILE", "Documents")

    targets: List[CleanerTarget] = [
        CleanerTarget(
            "Windows Cleanup",
            "User Temp Files",
            str(user_temp),
            _folder_size(user_temp),
            "Safe",
            "Cleanable",
            "Temporary files created by apps and installers. Locked files are skipped.",
            "user_temp",
        ),
        CleanerTarget(
            "Windows Cleanup",
            "Windows Temp Files",
            str(windows_root / "Temp"),
            _folder_size(windows_root / "Temp"),
            "Admin",
            "Cleanable",
            "System temp files. Admin rights may be required for some items.",
            "windows_temp",
        ),
        CleanerTarget(
            "Windows Cleanup",
            "Windows Update Download Cache",
            str(windows_root / "SoftwareDistribution" / "Download"),
            _folder_size(windows_root / "SoftwareDistribution" / "Download"),
            "Admin",
            "Review",
            "Downloaded update cache. Cleanup should stop update services first, so this is review-only for now.",
            "",
        ),
        CleanerTarget(
            "Windows Cleanup",
            "Thumbnail Cache",
            str(_env_path("LOCALAPPDATA", "Microsoft", "Windows", "Explorer")),
            _folder_size(_env_path("LOCALAPPDATA", "Microsoft", "Windows", "Explorer")),
            "Safe",
            "Cleanable",
            "Windows thumbnail databases. Explorer may recreate them later.",
            "thumbnails",
        ),
        CleanerTarget(
            "Diagnostics Cleanup",
            "User Crash Dumps",
            str(_env_path("LOCALAPPDATA", "CrashDumps")),
            _folder_size(_env_path("LOCALAPPDATA", "CrashDumps")),
            "Safe",
            "Cleanable",
            "Crash dump files created when applications fail.",
            "crash_dumps",
        ),
        CleanerTarget(
            "Downloads Review",
            "Downloads Folder",
            str(downloads),
            _folder_size(downloads, max_items=3500, max_seconds=1.8),
            "Review",
            "Review",
            "Consumer downloads can contain personal files, installers, photos, and documents. Review manually.",
            "",
        ),
        CleanerTarget(
            "Personal File Review",
            "Desktop Folder",
            str(desktop),
            _folder_size(desktop, max_items=2500, max_seconds=1.5),
            "Review",
            "Review",
            "Desktop size only. The cleaner does not delete desktop files.",
            "",
        ),
        CleanerTarget(
            "Personal File Review",
            "Documents Folder",
            str(documents),
            _folder_size(documents, max_items=3500, max_seconds=1.8),
            "Review",
            "Review",
            "Documents size only. The cleaner does not delete documents.",
            "",
        ),
    ]

    targets.extend(browser_cache_targets())
    return _existing_targets(targets)


def consumer_summary(targets: List[CleanerTarget]) -> str:
    """Create a simplified consumer-facing cleaner summary."""
    groups: dict[str, int] = {}
    cleanable = 0
    review = 0

    for target in targets:
        groups[target.category] = groups.get(target.category, 0) + target.estimated_bytes
        if target.action == "Cleanable":
            cleanable += target.estimated_bytes
        else:
            review += target.estimated_bytes

    lines = [
        "Cleaner Summary",
        "===============",
        "",
        f"Safe cleanup estimate: {format_bytes(cleanable)}",
        f"Review-only storage found: {format_bytes(review)}",
        "",
        "Categories:",
    ]

    for category, size in sorted(groups.items()):
        lines.append(f"- {category}: {format_bytes(size)}")

    lines.extend([
        "",
        "What this means:",
        "- Safe cleanup items are caches, temp files, and crash dumps.",
        "- Review-only items may contain personal files and are not deleted automatically.",
        "- Some files may be skipped if they are locked by running apps.",
        "",
        "Open the More Info tab for paths, risk labels, and technical details.",
    ])

    return "\n".join(lines)


def technical_details(targets: List[CleanerTarget]) -> str:
    lines = [
        "Cleaner Technical Details",
        "=========================",
        "",
    ]

    for target in targets:
        lines.append(f"[{target.category}] {target.name}")
        lines.append(f"  Size: {format_bytes(target.estimated_bytes)}")
        lines.append(f"  Risk: {target.risk}")
        lines.append(f"  Action: {target.action}")
        lines.append(f"  Path: {target.path}")
        lines.append(f"  Cleanup key: {target.cleanup_key or 'review-only'}")
        lines.append(f"  Notes: {target.description}")
        lines.append("")

    return "\n".join(lines).strip()


def clean_folder_contents(path: str) -> Tuple[str, int]:
    folder = Path(path)
    if not folder.exists() or not folder.is_dir():
        return f"Folder not found: {path}", 0

    deleted = 0
    skipped = 0
    freed = 0

    for item in folder.iterdir():
        try:
            if item.is_file() or item.is_symlink():
                try:
                    freed += item.stat().st_size
                except OSError:
                    pass
                item.unlink()
                deleted += 1
            elif item.is_dir():
                try:
                    freed += _folder_size(item)
                except OSError:
                    pass
                shutil.rmtree(item, ignore_errors=False)
                deleted += 1
        except OSError:
            skipped += 1

    return (
        f"Cleaned: {path}\n"
        f"Deleted items: {deleted}\n"
        f"Skipped locked/protected items: {skipped}\n"
        f"Estimated freed: {format_bytes(freed)}",
        freed,
    )


def clean_user_temp() -> Tuple[str, int]:
    return clean_folder_contents(tempfile.gettempdir())


def clean_windows_temp() -> Tuple[str, int]:
    return clean_folder_contents(str(Path(os.environ.get("SystemRoot", r"C:\Windows")) / "Temp"))


def clean_thumbnail_cache() -> Tuple[str, int]:
    folder = _env_path("LOCALAPPDATA", "Microsoft", "Windows", "Explorer")
    if not folder.exists():
        return "Thumbnail cache folder not found.", 0

    deleted = 0
    skipped = 0
    freed = 0

    for file in folder.glob("thumbcache*.db"):
        try:
            freed += file.stat().st_size
            file.unlink()
            deleted += 1
        except OSError:
            skipped += 1

    return (
        f"Thumbnail cache cleanup complete.\n"
        f"Deleted files: {deleted}\n"
        f"Skipped locked files: {skipped}\n"
        f"Estimated freed: {format_bytes(freed)}",
        freed,
    )


def clean_crash_dumps() -> Tuple[str, int]:
    return clean_folder_contents(str(_env_path("LOCALAPPDATA", "CrashDumps")))


def clean_browser_cache() -> Tuple[str, int]:
    targets = [t for t in browser_cache_targets() if t.path and Path(t.path).exists()]
    if not targets:
        return "No browser cache folders were found.", 0

    reports: list[str] = []
    total = 0

    for target in targets:
        report, freed = clean_folder_contents(target.path)
        total += freed
        reports.append(f"{target.name}\n{report}")

    reports.append(f"Total estimated freed: {format_bytes(total)}")
    return "\n\n".join(reports), total


def empty_recycle_bin() -> Tuple[str, int]:
    try:
        result = run_hidden(
            [
                "powershell", "-NoProfile", "-ExecutionPolicy", "Bypass", "-WindowStyle", "Hidden",
                "-Command", "Clear-RecycleBin -Force -ErrorAction SilentlyContinue; Write-Output 'Recycle Bin cleanup requested.'"
            ],
            timeout=180,
        )
        output = result.stdout or ""
        if result.stderr:
            output += "\n" + result.stderr
        return output.strip() or "Recycle Bin cleanup requested.", 0
    except FileNotFoundError:
        return "Recycle Bin cleanup requires Windows PowerShell.", 0
    except Exception as exc:
        return f"Recycle Bin cleanup could not run: {exc}", 0
