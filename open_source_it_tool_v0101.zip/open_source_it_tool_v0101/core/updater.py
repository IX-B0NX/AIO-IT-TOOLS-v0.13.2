from __future__ import annotations

import os
import shutil
import subprocess
from core.process_utils import run_hidden
from typing import Iterable, Tuple

from core.models import UpdateRow


def creationflags() -> int:
    return subprocess.CREATE_NO_WINDOW if os.name == "nt" else 0


def winget_available() -> bool:
    return shutil.which("winget") is not None


def run_process(command: list[str], timeout: int = 1800) -> Tuple[str, int]:
    """Run a command and return combined output plus exit code.

    Use a list of arguments instead of shell=True for package-manager commands.
    This avoids quoting problems when package IDs contain punctuation.
    """
    if not command:
        return "No command was provided.", 1

    if command[0].lower() == "winget" and not winget_available():
        return "winget was not found. Install or repair App Installer, then scan again.", 1

    try:
        result = subprocess.run(
            command,
            capture_output=True,
            text=True,
            timeout=timeout,
            encoding="utf-8",
            errors="replace",
            creationflags=creationflags(),
        )
    except subprocess.TimeoutExpired:
        return f"Command timed out after {timeout} seconds:\n{' '.join(command)}", 124
    except FileNotFoundError:
        return f"Command not found: {command[0]}", 1
    except Exception as exc:
        return f"Command failed before launch:\n{exc}", 1

    output = result.stdout or ""
    if result.stderr:
        output += "\n" + result.stderr
    return output.strip(), int(result.returncode)


def can_update_with_winget(row: UpdateRow) -> bool:
    """Only winget app rows with a known package ID can be updated directly."""
    return row.update_status == "YES" and row.item_type == "App" and bool(row.raw_id)


def update_command_for_row(row: UpdateRow) -> list[str]:
    return [
        "winget",
        "upgrade",
        "--id", row.raw_id,
        "--exact",
        "--accept-package-agreements",
        "--accept-source-agreements",
        "--disable-interactivity",
    ]


def update_selected_app(row: UpdateRow) -> Tuple[str, int]:
    if not can_update_with_winget(row):
        return (
            "This item cannot be updated directly yet.\n\n"
            "Direct updating currently supports YES app updates detected by winget with a package ID.",
            1,
        )
    return run_process(update_command_for_row(row))


def update_detected_apps(rows: Iterable[UpdateRow]) -> Tuple[str, int]:
    """Update only the app updates detected in the current scan.

    This is safer than winget upgrade --all because the user is acting on the
    visible scan results rather than whatever winget discovers at runtime.
    """
    updateable = [row for row in rows if can_update_with_winget(row)]

    if not updateable:
        return "No detected winget app updates are available to process.", 1

    final_lines: list[str] = []
    highest_code = 0

    for index, row in enumerate(updateable, start=1):
        final_lines.append("=" * 80)
        final_lines.append(f"[{index}/{len(updateable)}] {row.name}")
        final_lines.append(f"Package ID: {row.raw_id}")
        final_lines.append(f"Current: {row.current_version or 'Unknown'}")
        final_lines.append(f"Latest: {row.latest_version or 'Unknown'}")
        final_lines.append("-" * 80)

        output, code = run_process(update_command_for_row(row))
        highest_code = max(highest_code, code)
        final_lines.append(output or "No output returned.")
        final_lines.append(f"Exit code: {code}")
        final_lines.append("")

    return "\n".join(final_lines).strip(), highest_code
