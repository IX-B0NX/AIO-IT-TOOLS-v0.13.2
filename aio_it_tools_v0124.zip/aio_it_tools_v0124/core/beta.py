from __future__ import annotations

APP_PUBLIC_VERSION = "0.12.4"
RELEASE_CHANNEL = "Public Beta Candidate"

BETA_WARNING = """
AIO IT TOOLS is currently a Public Beta Candidate.

Use it for testing and feedback before consumer release. Some workflows rely on Windows components such as winget, Windows Update, PowerShell, Device Manager, and administrator permissions. Behavior can vary by PC, policy, security software, and Windows version.

Single-EXE goal:
- Consumers should eventually receive only AIOITTools.exe from the dist folder.
- Runtime logs, support ZIPs, settings, and driver backups are created automatically.
- No installer is planned for now.

Safer defaults are enabled:
- Cleaner personal folders are review-only.
- Driver automation requires review and safety checks.
- Advanced repair tools are hidden until enabled.
- Support ZIP export is available for troubleshooting.
""".strip()

KNOWN_ISSUES = [
    {
        "area": "Windows Update",
        "severity": "Medium",
        "status": "Improved; still dependent on Windows policy/services",
        "issue": "Automatic scan can still fail or return warnings on managed/restricted PCs.",
        "workaround": "Use Check Update Health, open Windows Update manually, then scan again.",
    },
    {
        "area": "winget",
        "severity": "Medium",
        "status": "Improved; still dependent on App Installer and winget output format",
        "issue": "winget may be missing, sources may be broken, or output may not parse cleanly on some systems.",
        "workaround": "Use Repair winget Sources or repair App Installer from Microsoft Store.",
    },
    {
        "area": "Drivers",
        "severity": "High",
        "status": "Known limitation",
        "issue": "Driver comparison depends on Windows Update metadata and may not match every installed device perfectly.",
        "workaround": "Use Review Drivers and match confidence before allowing automated driver updates.",
    },
    {
        "area": "EXE Reputation",
        "severity": "Medium",
        "status": "Unresolved until code signing",
        "issue": "Unsigned beta builds may trigger Windows SmartScreen or antivirus reputation prompts.",
        "workaround": "Use only builds from your trusted source until code signing is added.",
    },
    {
        "area": "Single EXE Runtime Data",
        "severity": "Low",
        "status": "Needs Windows EXE test",
        "issue": "Compiled one-file EXE builds must create logs, support ZIPs, settings, and driver backups at runtime.",
        "workaround": "If runtime folders fail, export a support ZIP or run from source/dev package for debugging.",
    },
    {
        "area": "Local Wi-Fi Password Display",
        "severity": "Low",
        "status": "New in v0.12.4; needs Windows admin test",
        "issue": "Wi-Fi password display depends on Windows netsh and may not show keys for every profile depending on policy/security state.",
        "workaround": "Run as administrator and verify output in Repair > Wi-Fi Profiles + Passwords.",
    },
]


def known_issues_text() -> str:
    lines = ["Known Issues", "============", ""]
    for item in KNOWN_ISSUES:
        lines.append(f"[{item['severity']}] {item['area']} — {item.get('status', 'Tracked')}")
        lines.append(f"  Issue: {item['issue']}")
        lines.append(f"  Workaround: {item['workaround']}")
        lines.append("")
    return "\n".join(lines).strip()
