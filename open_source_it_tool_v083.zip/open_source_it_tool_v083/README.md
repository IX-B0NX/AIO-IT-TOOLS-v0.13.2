# Open Source IT Tool v0.8.3

created by ฿0₦Ӿ

Professional Windows update, cleanup, and IT maintenance utility.

## Main features

- Dark glass desktop interface
- Full app/driver/update inventory
- Green YES for available updates
- Red NO for no update detected
- Orange WARNING for scanner issues
- Direct app updating through winget
- Update Selected
- Update Detected Apps
- Consumer-friendly Cleaner tab
- More Info tab for technical cleanup details
- AIO Toolkit tab with repair and diagnostic actions
- Logs saved under `logs/`
- CSV and HTML report export

## Cleaner design

The Cleaner tab shows a consumer-friendly summary first.

It separates results into:

- Safe cleanup estimate
- Review-only storage
- Browser and privacy cache
- Windows cleanup
- Diagnostics cleanup
- Personal file review

The More Info tab shows:

- full paths
- risk labels
- cleanup status
- estimated size
- notes for each target

## Direct update behavior

Direct updates currently support winget app updates only.

`Update Selected` updates the selected YES app row when it has a winget package ID.

`Update Detected Apps` processes only the winget app updates detected in the current scan. It does not blindly run a full package-manager update against items that were not shown in the table.

## Run

```text
run_open_source_it_tool.bat
```

## Build portable EXE

```text
build_exe.bat
```

Output:

```text
dist\OpenSourceITTool.exe
```

## Developer notes

- Keep destructive actions behind confirmation prompts.
- Keep driver updates conservative until official vendor/OEM update flows are added.
- Keep review-only locations separate from cleanable locations.
- Avoid cleaning personal folders automatically.
- Keep logs plain text for support workflows.


## v0.8.2 admin and consumer UI pass

- Startup now requests Administrator mode on Windows.
- The packaged EXE build uses a UAC admin manifest.
- The app cannot bypass UAC; Windows still requires approval.
- Header now shows Administrator Mode status.
- Removed harsh red cleanup buttons and replaced them with warning-styled action buttons.
- Renamed some UI buttons for consumers:
  - Scan PC
  - Update Apps
  - Windows Update
  - Report
- Cleaner wording is more consumer-friendly while keeping More Info for technical details.


## v0.8.3 consumer UI and confirmation pass

- Added Home dashboard with large action cards:
  - Update Apps
  - Clean PC
  - Check Health
  - Repair Tools
- Added plain-English dashboard status after scanning.
- Added custom confirmation dialogs for updates, cleanup, and toolkit actions.
- Confirmation dialogs now explain exactly what will happen before the action runs.
- Generic question-mark prompts have been replaced with review-style confirmation text.
- Cleaner still provides a simple summary first and deeper technical detail in More Info.
