from __future__ import annotations

import os
import subprocess
import sys
from pathlib import Path
from typing import List, Tuple

from core.models import ToolAction


def app_root() -> Path:
    # In a PyInstaller build, bundled assets live under sys._MEIPASS.
    if getattr(sys, "frozen", False) and hasattr(sys, "_MEIPASS"):
        return Path(sys._MEIPASS)
    return Path(__file__).resolve().parents[1]


def toolkit_bat_path() -> Path:
    return app_root() / "assets" / "IT_Troubleshooting_Toolkit.bat"


TOOL_ACTIONS: List[ToolAction] = [
    ToolAction(
        name="Launch Original BAT Toolkit",
        category="Original Toolkit",
        description="Opens your original IT Troubleshooting Toolkit batch menu as a fallback.",
        command=f'cmd /c "{toolkit_bat_path()}"',
        risk="System-changing menu",
        requires_admin=True,
        confirm=True,
    ),
    ToolAction(
        name="System Quick-Look",
        category="Diagnostics",
        description="Shows IP configuration, adapter information, boot time, and system summary.",
        command='cmd /c "hostname & echo. & ipconfig & echo. & systeminfo | findstr /B /C:\\"OS Name\\" /C:\\"OS Version\\" /C:\\"System Boot Time\\""',
        risk="Read-only",
    ),
    ToolAction(
        name="Flush DNS",
        category="Network",
        description="Clears the local DNS resolver cache. Useful when websites resolve incorrectly.",
        command="ipconfig /flushdns",
        risk="Safe repair",
        confirm=True,
    ),
    ToolAction(
        name="Network Refresher",
        category="Network",
        description="Releases/renews IP, flushes DNS, and resets Winsock. A reboot may be needed.",
        command='cmd /c "ipconfig /release & ipconfig /renew & ipconfig /flushdns & netsh winsock reset"',
        risk="System-changing",
        requires_admin=True,
        confirm=True,
    ),
    ToolAction(
        name="SFC Scan",
        category="Repair",
        description="Runs System File Checker to verify and repair protected Windows files.",
        command="sfc /scannow",
        risk="Safe repair",
        requires_admin=True,
        confirm=True,
    ),
    ToolAction(
        name="DISM RestoreHealth",
        category="Repair",
        description="Repairs the Windows component store. Often used before or after SFC.",
        command="DISM /Online /Cleanup-Image /RestoreHealth",
        risk="Safe repair",
        requires_admin=True,
        confirm=True,
    ),
    ToolAction(
        name="Drive SMART Status",
        category="Diagnostics",
        description="Reads physical disk health status through PowerShell.",
        command='powershell -NoProfile -Command "Get-PhysicalDisk | Select FriendlyName,HealthStatus,OperationalStatus,Size | Format-Table -AutoSize"',
        risk="Read-only",
    ),
    ToolAction(
        name="Battery Report",
        category="Reports",
        description="Generates a Windows battery report HTML file.",
        command='cmd /c "powercfg /batteryreport /output %USERPROFILE%\\Desktop\\battery-report.html"',
        risk="Read-only report",
    ),
    ToolAction(
        name="Explorer Refresh",
        category="Repair",
        description="Restarts Windows Explorer to fix taskbar or desktop UI hangs.",
        command='cmd /c "taskkill /f /im explorer.exe & start explorer.exe"',
        risk="Safe repair",
        confirm=True,
    ),
    ToolAction(
        name="Windows Update Settings",
        category="Shortcuts",
        description="Opens Windows Update settings.",
        command="ms-settings:windowsupdate",
        risk="Shortcut",
    ),
    ToolAction(
        name="Device Manager",
        category="Shortcuts",
        description="Opens Device Manager.",
        command="devmgmt.msc",
        risk="Shortcut",
    ),
    ToolAction(
        name="Wi-Fi Profiles",
        category="Diagnostics",
        description="Lists saved Wi-Fi profile names. Does not reveal passwords.",
        command="netsh wlan show profiles",
        risk="Read-only",
    ),
]


def run_action(action: ToolAction, timeout: int = 120) -> Tuple[str, bool]:
    """Return output, opened_external."""
    if action.command.startswith("ms-settings:") or action.command.endswith(".msc"):
        os.startfile(action.command)  # type: ignore[attr-defined]
        return f"Opened {action.command}", True

    result = subprocess.run(
        action.command,
        shell=True,
        capture_output=True,
        text=True,
        timeout=timeout,
        encoding="utf-8",
        errors="replace",
    )
    output = result.stdout or ""
    if result.stderr:
        output += "\n" + result.stderr
    return output.strip(), False
