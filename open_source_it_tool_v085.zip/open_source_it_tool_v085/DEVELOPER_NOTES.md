# Developer Notes

## v0.8.1 cleanup pass

- Removed production debug artifacts from the package.
- Added plain-text command logs under `logs/`.
- Tightened `Update Detected Apps` so it processes scanned winget rows instead of running a blind global update.
- Broadened Cleaner analysis for consumer use.
- Added a More Info tab for technical cleaner detail.
- Added cleaner targets for browser cache, crash dumps, Windows Update cache review, and personal-folder review.
- Added table repaint suppression while loading rows.
- Left driver updates as detection/manual-vendor-link only.

## Safety decisions

- Personal folders are review-only.
- Windows Update download cache is review-only until a proper service-stop workflow is added.
- Browser cache cleanup skips locked files.
- Cleaner actions are confirmation-gated.
- Package updates are limited to detected winget package IDs.


## v0.8.2 notes

- Added startup elevation through ShellExecuteW `runas`.
- Added PyInstaller `--uac-admin` flag for the portable EXE build.
- Kept UAC approval mandatory; the app requests elevation, Windows grants it.
- Replaced danger-red button treatment with warning-style action buttons.
- Added admin status badge in the header.
- Simplified some button labels for a more consumer-facing layout.


## v0.8.3 notes

- Added dashboard tab as the consumer entry point.
- Added shared `confirm_action` helper to remove generic question prompts.
- Confirmation dialogs now list specific action behavior for updater, cleaner, and toolkit flows.
- Dashboard summary is derived from the filtered scan rows and updates after scans/searches.
- Existing table and technical tabs remain available for advanced users.


## v0.8.4 notes

- Added `core/driver_updates.py`.
- Driver comparison uses installed `Win32_PnPSignedDriver` inventory and available Windows Update driver updates.
- Available driver metadata is collected from Windows Update COM properties when exposed.
- Matching is heuristic and reports High/Medium/Low confidence.
- Driver install is intentionally not wired yet. Add restore point, export current driver, and rollback guidance before enabling direct install.


## v0.8.5 notes

- Added `core/driver_install.py`.
- Added guarded automated driver workflow:
  1. restore point attempt
  2. pnputil driver export
  3. Windows Update driver install
  4. rollback notes
- Installation scope is limited to driver updates returned by the Windows Update COM search.
- Workflow uses one confirmation, then runs without additional app prompts.
- Rescan is triggered after completion to refresh the comparison table.
