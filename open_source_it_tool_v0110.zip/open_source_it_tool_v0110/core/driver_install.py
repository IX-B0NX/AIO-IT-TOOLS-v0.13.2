from __future__ import annotations

import os
import platform
import subprocess
from dataclasses import dataclass
from datetime import datetime
from pathlib import Path
from typing import Callable, Tuple

from core.admin import is_admin
from core.config import app_dir
from core.process_utils import run_hidden


Progress = Callable[[str], None]


@dataclass
class SafetyCheck:
    name: str
    status: str
    message: str
    blocking: bool = False

    def line(self) -> str:
        marker = "BLOCK" if self.blocking else self.status.upper()
        return f"[{marker}] {self.name}: {self.message}"


@dataclass
class BackupVerification:
    ok: bool
    backup_dir: Path
    inf_count: int
    file_count: int
    total_bytes: int
    message: str


def is_windows() -> bool:
    return platform.system().lower() == "windows"


def run_cmd(command: list[str], timeout: int = 1800) -> Tuple[str, int]:
    try:
        result = run_hidden(command, timeout=timeout)
    except subprocess.TimeoutExpired:
        return f"Timed out after {timeout} seconds:\n{' '.join(command)}", 124
    except Exception as exc:
        return f"Failed to launch command:\n{exc}", 1

    output = result.stdout or ""
    if result.stderr:
        output += "\n" + result.stderr
    return output.strip(), int(result.returncode)


def run_powershell(script: str, timeout: int = 1800) -> Tuple[str, int]:
    if not is_windows():
        return "Driver installation requires Windows.", 1

    return run_cmd(
        ["powershell.exe", "-NoProfile", "-ExecutionPolicy", "Bypass", "-WindowStyle", "Hidden", "-Command", script],
        timeout=timeout,
    )


def driver_backup_root() -> Path:
    root = app_dir() / "driver_backups"
    root.mkdir(parents=True, exist_ok=True)
    return root


def new_backup_folder() -> Path:
    stamp = datetime.now().strftime("%Y%m%d_%H%M%S")
    path = driver_backup_root() / f"drivers_{stamp}"
    path.mkdir(parents=True, exist_ok=True)
    return path


def format_bytes(num: int) -> str:
    value = float(max(0, num))
    for unit in ["B", "KB", "MB", "GB", "TB"]:
        if value < 1024:
            return f"{value:.1f} {unit}"
        value /= 1024
    return f"{value:.1f} PB"


def pending_reboot_check() -> SafetyCheck:
    if not is_windows():
        return SafetyCheck("Pending reboot", "Warning", "This check requires Windows.", False)

    script = r"""
$paths = @(
 'HKLM:\SOFTWARE\Microsoft\Windows\CurrentVersion\Component Based Servicing\RebootPending',
 'HKLM:\SOFTWARE\Microsoft\Windows\CurrentVersion\WindowsUpdate\Auto Update\RebootRequired',
 'HKLM:\SYSTEM\CurrentControlSet\Control\Session Manager'
)
$pending = $false
$notes = @()

if (Test-Path $paths[0]) { $pending = $true; $notes += 'CBS reboot pending' }
if (Test-Path $paths[1]) { $pending = $true; $notes += 'Windows Update reboot required' }
try {
  $value = (Get-ItemProperty -Path $paths[2] -Name PendingFileRenameOperations -ErrorAction SilentlyContinue).PendingFileRenameOperations
  if ($value) { $pending = $true; $notes += 'Pending file rename operations' }
} catch {}

if ($pending) {
  Write-Output ('PENDING|' + ($notes -join '; '))
} else {
  Write-Output 'OK|No pending reboot indicators found.'
}
"""
    output, _ = run_powershell(script, timeout=25)
    output = output.strip()

    if output.startswith("PENDING|"):
        return SafetyCheck(
            "Pending reboot",
            "Blocked",
            output.split("|", 1)[1] or "A reboot is already pending.",
            True,
        )
    if output.startswith("OK|"):
        return SafetyCheck("Pending reboot", "Good", output.split("|", 1)[1], False)

    return SafetyCheck("Pending reboot", "Warning", output or "Could not determine reboot status.", False)


def battery_power_check(min_percent: int = 30) -> SafetyCheck:
    if not is_windows():
        return SafetyCheck("Battery / AC power", "Warning", "This check requires Windows.", False)

    script = r"""
try {
  $b = Get-CimInstance Win32_Battery -ErrorAction SilentlyContinue
  if ($null -eq $b) {
    Write-Output 'OK|No battery detected. Desktop or always-on-power device.'
    exit 0
  }

  $pct = [int]($b.EstimatedChargeRemaining | Select-Object -First 1)
  $status = [int]($b.BatteryStatus | Select-Object -First 1)
  # Common BatteryStatus values: 2 = AC power, 6/7/8/9 = charging/high/low/critical
  if ($pct -lt """ + str(min_percent) + r""") {
    Write-Output ('LOW|' + $pct + '% battery remaining.')
  } elseif ($status -eq 1) {
    Write-Output ('BATTERY|' + $pct + '% battery remaining; device appears to be discharging.')
  } else {
    Write-Output ('OK|' + $pct + '% battery remaining; status code ' + $status + '.')
  }
}
catch {
  Write-Output ('UNKNOWN|' + $_.Exception.Message)
}
"""
    output, _ = run_powershell(script, timeout=25)
    output = output.strip()

    if output.startswith("LOW|"):
        return SafetyCheck("Battery / AC power", "Blocked", output.split("|", 1)[1], True)
    if output.startswith("BATTERY|"):
        return SafetyCheck(
            "Battery / AC power",
            "Warning",
            output.split("|", 1)[1] + " Plug in power before driver updates if possible.",
            False,
        )
    if output.startswith("OK|"):
        return SafetyCheck("Battery / AC power", "Good", output.split("|", 1)[1], False)
    if output.startswith("UNKNOWN|"):
        return SafetyCheck("Battery / AC power", "Warning", output.split("|", 1)[1], False)

    return SafetyCheck("Battery / AC power", "Warning", output or "Could not determine power state.", False)


def admin_check() -> SafetyCheck:
    if is_admin():
        return SafetyCheck("Administrator mode", "Good", "Running with administrator privileges.", False)
    return SafetyCheck("Administrator mode", "Blocked", "Driver installation requires administrator mode.", True)


def windows_update_scope_check() -> SafetyCheck:
    return SafetyCheck(
        "Driver source scope",
        "Good",
        "Driver installs are limited to driver-class updates returned by Windows Update.",
        False,
    )


def preflight_safety_checks() -> list[SafetyCheck]:
    checks = [
        admin_check(),
        pending_reboot_check(),
        battery_power_check(),
        windows_update_scope_check(),
    ]
    return checks


def safety_report(checks: list[SafetyCheck]) -> str:
    lines = [
        "Driver Safety Preflight",
        "=======================",
        "",
    ]
    lines.extend(check.line() for check in checks)
    blockers = [c for c in checks if c.blocking]
    lines.extend([
        "",
        "Result:",
        "Blocked" if blockers else "Allowed",
    ])
    if blockers:
        lines.append("")
        lines.append("Resolve the blocked items before running automated driver updates.")
    return "\n".join(lines)


def create_restore_point(progress: Progress | None = None) -> tuple[str, bool]:
    if progress:
        progress("Creating system restore point...")

    script = r"""
try {
  Checkpoint-Computer -Description "Open Source IT Tool - Driver Update" -RestorePointType "MODIFY_SETTINGS" -ErrorAction Stop
  Write-Output "OK|Restore point created successfully."
}
catch {
  Write-Output "WARN|Restore point could not be created: " + $_.Exception.Message
}
"""
    output, _code = run_powershell(script, timeout=300)
    output = output.strip()
    ok = output.startswith("OK|")
    return output.replace("OK|", "").replace("WARN|", ""), ok


def verify_backup_folder(backup_dir: Path) -> BackupVerification:
    try:
        files = [p for p in backup_dir.rglob("*") if p.is_file()]
        inf_count = len([p for p in files if p.suffix.lower() == ".inf"])
        total = 0
        for file in files:
            try:
                total += file.stat().st_size
            except OSError:
                pass

        ok = inf_count > 0 and len(files) > 0
        if ok:
            message = f"Backup verified: {inf_count} INF file(s), {len(files)} total file(s), {format_bytes(total)}."
        else:
            message = "Backup verification failed: no exported driver INF files were found."
        return BackupVerification(ok, backup_dir, inf_count, len(files), total, message)
    except Exception as exc:
        return BackupVerification(False, backup_dir, 0, 0, 0, f"Backup verification failed: {exc}")


def export_current_drivers(progress: Progress | None = None) -> tuple[str, Path, BackupVerification]:
    backup_dir = new_backup_folder()
    if progress:
        progress(f"Exporting current drivers to {backup_dir.name}...")

    output, code = run_cmd(
        ["pnputil", "/export-driver", "*", str(backup_dir)],
        timeout=1800,
    )

    if code != 0:
        output = (
            output
            + "\n\nDriver export did not complete successfully."
            + "\nThis usually requires Administrator mode."
        ).strip()

    verification = verify_backup_folder(backup_dir)
    output = (output + "\n\n" + verification.message).strip()

    return output, backup_dir, verification


def install_windows_update_drivers(progress: Progress | None = None) -> str:
    if progress:
        progress("Installing driver updates from Windows Update...")

    script = r"""
try {
  $session = New-Object -ComObject Microsoft.Update.Session
  $searcher = $session.CreateUpdateSearcher()
  $result = $searcher.Search("IsInstalled=0 and IsHidden=0")

  $driverUpdates = New-Object -ComObject Microsoft.Update.UpdateColl

  for ($i = 0; $i -lt $result.Updates.Count; $i++) {
    $u = $result.Updates.Item($i)

    $isDriver = $false
    if ([int]$u.Type -eq 2) { $isDriver = $true }
    foreach ($cat in $u.Categories) {
      if ($cat.Name -match "Driver") { $isDriver = $true }
    }
    if ($u.Title -match "driver") { $isDriver = $true }

    if ($isDriver) {
      Write-Output ("Queued Windows Update driver: " + $u.Title)
      [void]$driverUpdates.Add($u)
    }
  }

  if ($driverUpdates.Count -eq 0) {
    Write-Output "No available Windows Update driver updates were found."
    exit 0
  }

  Write-Output ("Windows Update driver updates queued: " + $driverUpdates.Count)

  $downloader = $session.CreateUpdateDownloader()
  $downloader.Updates = $driverUpdates
  $downloadResult = $downloader.Download()
  Write-Output ("Download result code: " + $downloadResult.ResultCode)

  $installer = $session.CreateUpdateInstaller()
  $installer.Updates = $driverUpdates
  $installResult = $installer.Install()

  Write-Output ("Install result code: " + $installResult.ResultCode)
  Write-Output ("Reboot required: " + $installResult.RebootRequired)

  for ($i = 0; $i -lt $driverUpdates.Count; $i++) {
    $itemResult = $installResult.GetUpdateResult($i)
    Write-Output ("Result for [" + $driverUpdates.Item($i).Title + "]: " + $itemResult.ResultCode)
  }
}
catch {
  Write-Output "Driver update install failed:"
  Write-Output $_.Exception.Message
  exit 1
}
"""
    output, _code = run_powershell(script, timeout=2400)
    return output


def rollback_notes(backup_dir: Path) -> str:
    return f"""
Rollback instructions
=====================

Current driver backup folder:
{backup_dir}

If a driver causes issues:

1. Restart Windows if the install asked for a reboot.
2. Open Device Manager.
3. Right-click the affected device.
4. Choose Properties.
5. Open the Driver tab.
6. Try Roll Back Driver first.
7. If rollback is unavailable, choose Update Driver.
8. Choose Browse my computer for drivers.
9. Point Windows to the backup folder above.

The backup was created before installation using pnputil.
Keep this folder until you confirm the PC is stable.
""".strip()


def automated_driver_update(progress: Progress | None = None) -> str:
    """Run the guarded Windows Update driver workflow."""
    sections: list[str] = []

    sections.append("=" * 80)
    sections.append("STEP 0 - SAFETY PREFLIGHT")
    sections.append("=" * 80)
    checks = preflight_safety_checks()
    sections.append(safety_report(checks))

    blockers = [c for c in checks if c.blocking]
    if blockers:
        if progress:
            progress("Driver update blocked by safety preflight.")
        sections.append("")
        sections.append("Automated driver update was not started because one or more safety checks blocked the workflow.")
        return "\n".join(sections).strip()

    sections.append("")
    sections.append("=" * 80)
    sections.append("STEP 1 - RESTORE POINT STATUS")
    sections.append("=" * 80)
    restore_output, restore_ok = create_restore_point(progress)
    sections.append(restore_output)
    sections.append(f"Restore point status: {'Created' if restore_ok else 'Unavailable'}")
    if not restore_ok:
        sections.append("Continuing only if driver backup verification succeeds.")

    sections.append("")
    sections.append("=" * 80)
    sections.append("STEP 2 - CURRENT DRIVER BACKUP")
    sections.append("=" * 80)
    export_output, backup_dir, verification = export_current_drivers(progress)
    sections.append(export_output)
    sections.append(f"\nBackup folder: {backup_dir}")

    if not verification.ok:
        if progress:
            progress("Driver update blocked because backup verification failed.")
        sections.append("")
        sections.append("=" * 80)
        sections.append("WORKFLOW BLOCKED")
        sections.append("=" * 80)
        sections.append("No drivers were installed because the current driver backup could not be verified.")
        sections.append("Fix the backup/export issue and run the workflow again.")
        return "\n".join(sections).strip()

    sections.append("")
    sections.append("=" * 80)
    sections.append("STEP 3 - WINDOWS UPDATE DRIVER INSTALL")
    sections.append("=" * 80)
    sections.append("Install source is restricted to Windows Update driver-class updates.")
    sections.append(install_windows_update_drivers(progress))

    sections.append("")
    sections.append("=" * 80)
    sections.append("STEP 4 - ROLLBACK INFORMATION")
    sections.append("=" * 80)
    sections.append(rollback_notes(backup_dir))

    if progress:
        progress("Driver update workflow complete.")

    return "\n".join(sections).strip()
