from __future__ import annotations

APP_PUBLIC_VERSION = "0.11.0"
RELEASE_CHANNEL = "Public Beta Candidate"

BETA_WARNING = """
Open Source IT Tool is currently a Public Beta Candidate.

Use it for testing and feedback before consumer release. Some workflows rely on Windows components such as winget, Windows Update, PowerShell, Device Manager, and administrator permissions. Behavior can vary by PC, policy, security software, and Windows version.

Safer defaults are enabled:
- Cleaner personal folders are review-only.
- Driver automation requires review and safety checks.
- Advanced repair tools are hidden until enabled.
- Support ZIP export is available for troubleshooting.
""".strip()

KNOWN_ISSUES = [
    {"area": "Windows Update", "severity": "Medium", "issue": "Automatic scan may fail or return warnings on managed/restricted PCs.", "workaround": "Use Check Update Health, open Windows Update manually, then scan again."},
    {"area": "winget", "severity": "Medium", "issue": "winget may be missing, sources may be broken, or output may not parse cleanly on some systems.", "workaround": "Use Repair winget Sources or repair App Installer from Microsoft Store."},
    {"area": "Drivers", "severity": "High", "issue": "Driver comparison depends on Windows Update metadata and may not match every installed device perfectly.", "workaround": "Use Review Drivers and match confidence before allowing automated driver updates."},
    {"area": "Cleaner", "severity": "Low", "issue": "Open apps can lock cache/temp files, leaving skipped items after cleanup.", "workaround": "Close browsers/apps and run Cleaner again. Skipped items are logged."},
    {"area": "PowerShell / System Tools", "severity": "Low", "issue": "Some Windows-native windows such as Settings, Device Manager, or UAC cannot be embedded inside the app.", "workaround": "These open as Windows system windows by design."},
    {"area": "EXE Reputation", "severity": "Medium", "issue": "Unsigned beta builds may trigger Windows SmartScreen or antivirus reputation prompts.", "workaround": "Use only builds from your trusted source until code signing is added."},
]


def known_issues_text() -> str:
    lines = ["Known Issues", "============", ""]
    for item in KNOWN_ISSUES:
        lines.append(f"[{item['severity']}] {item['area']}")
        lines.append(f"  Issue: {item['issue']}")
        lines.append(f"  Workaround: {item['workaround']}")
        lines.append("")
    return "\n".join(lines).strip()
