import sys

from core.admin import should_request_admin, relaunch_as_admin
from ui.main_window import run_app


if __name__ == "__main__":
    # Request elevation once at startup so update, repair, and cleanup tools
    # run in the same administrator context. Windows still shows the UAC prompt.
    if should_request_admin():
        if relaunch_as_admin():
            sys.exit(0)

    run_app()
