from __future__ import annotations

import ctypes
import os
import platform
import sys
from pathlib import Path


def is_windows() -> bool:
    return platform.system().lower() == "windows"


def is_admin() -> bool:
    """Return True when the current process has administrator rights."""
    if not is_windows():
        return False

    try:
        return bool(ctypes.windll.shell32.IsUserAnAdmin())
    except Exception:
        return False


def relaunch_as_admin() -> bool:
    """Ask Windows to relaunch this program through UAC.

    Windows still controls the approval dialog. The app can request elevation,
    but it cannot and should not bypass the user's UAC approval.
    """
    if not is_windows():
        return False

    try:
        if getattr(sys, "frozen", False):
            executable = sys.executable
            params = " ".join([_quote(arg) for arg in sys.argv[1:]])
        else:
            executable = sys.executable
            script = Path(sys.argv[0]).resolve()
            params = " ".join([_quote(str(script))] + [_quote(arg) for arg in sys.argv[1:]])

        result = ctypes.windll.shell32.ShellExecuteW(
            None,
            "runas",
            executable,
            params,
            str(Path.cwd()),
            1,
        )
        return int(result) > 32
    except Exception:
        return False


def _quote(value: str) -> str:
    value = str(value)
    if not value:
        return '""'
    if any(ch.isspace() for ch in value) or '"' in value:
        return '"' + value.replace('"', r'\"') + '"'
    return value


def should_request_admin() -> bool:
    """Central switch for startup elevation.

    Keep this in one place so a future Settings page can expose the behavior
    without touching the launcher code.
    """
    return is_windows() and not is_admin() and "--no-elevate" not in sys.argv
