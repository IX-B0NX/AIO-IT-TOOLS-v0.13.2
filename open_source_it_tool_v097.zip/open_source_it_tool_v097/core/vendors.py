from __future__ import annotations

from typing import Tuple


VENDORS = [
    ("NVIDIA", ["nvidia", "geforce", "quadro", "rtx", "gtx"], "https://www.nvidia.com/Download/index.aspx"),
    ("AMD", ["amd", "radeon", "ryzen", "adrenalin"], "https://www.amd.com/en/support/download/drivers.html"),
    ("Intel", ["intel", "arc graphics", "iris xe", "killer wi-fi", "killer wifi"], "https://www.intel.com/content/www/us/en/download-center/home.html"),
    ("Dell", ["dell", "alienware"], "https://www.dell.com/support/home/drivers"),
    ("HP", ["hewlett-packard", "hewlett packard", "hp inc", "omen by hp", " hp "], "https://support.hp.com/us-en/drivers"),
    ("Lenovo", ["lenovo", "thinkpad", "legion", "ideapad"], "https://pcsupport.lenovo.com/us/en/"),
    ("ASUS", ["asus", "asustek", "rog ", "tuf gaming"], "https://www.asus.com/support/Download-Center/"),
    ("Acer", ["acer", "predator"], "https://www.acer.com/us-en/support/drivers-and-manuals"),
    ("MSI", ["micro-star", "micro star", "msi "], "https://www.msi.com/support/download"),
    ("GIGABYTE", ["gigabyte", "aorus"], "https://www.gigabyte.com/Support"),
    ("Microsoft Surface", ["surface"], "https://support.microsoft.com/surface"),
    ("Realtek", ["realtek"], "https://www.realtek.com/Download/"),
    ("Qualcomm", ["qualcomm", "atheros", "snapdragon"], "https://www.qualcomm.com/drivers"),
    ("Broadcom", ["broadcom"], "https://www.broadcom.com/support/download-search"),
    ("Logitech", ["logitech", "logi "], "https://support.logi.com/"),
    ("Razer", ["razer"], "https://mysupport.razer.com/app/answers/detail/a_id/4166"),
    ("Corsair", ["corsair"], "https://www.corsair.com/us/en/s/downloads"),
]


def detect_vendor(*parts: str) -> Tuple[str, str]:
    text = " " + " ".join(str(p or "").lower() for p in parts) + " "
    for name, patterns, link in VENDORS:
        for pattern in patterns:
            if pattern.lower() in text:
                return name, link
    return "", ""
