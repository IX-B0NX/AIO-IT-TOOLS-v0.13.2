from __future__ import annotations

from dataclasses import dataclass, asdict
from typing import Dict


@dataclass
class UpdateRow:
    item_type: str
    name: str
    current_version: str = ""
    latest_version: str = ""
    update_available: bool = False
    update_status: str = "NO"
    source: str = ""
    vendor: str = ""
    vendor_link: str = ""
    update_link: str = ""
    notes_link: str = ""
    risk: str = "Unknown"
    confidence: str = ""
    details: str = ""
    raw_id: str = ""

    def as_dict(self) -> Dict[str, str]:
        data = asdict(self)
        data["update_available"] = "YES" if self.update_available else "NO"
        return data


@dataclass
class ToolAction:
    name: str
    category: str
    description: str
    command: str
    risk: str = "Read-only"
    requires_admin: bool = False
    confirm: bool = False
