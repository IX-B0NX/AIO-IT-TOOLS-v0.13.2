from __future__ import annotations

import json
import sys
from pathlib import Path


DEFAULT_CONFIG = {
    "scan_apps": True,
    "scan_drivers": True,
    "scan_windows_update": True,
    "show_no_updates": True,
    "vendor_links": True,
    "winget_timeout": 45,
    "driver_timeout": 60,
    "windows_update_timeout": 60,
}


def app_dir() -> Path:
    # In a PyInstaller EXE, store config next to the EXE so it persists.
    if getattr(sys, "frozen", False):
        return Path(sys.executable).resolve().parent
    return Path(__file__).resolve().parents[1]


CONFIG_PATH = app_dir() / "openupdate_aio_config.json"


class Config:
    def __init__(self) -> None:
        self.data = DEFAULT_CONFIG.copy()
        self.load()

    def load(self) -> None:
        if CONFIG_PATH.exists():
            try:
                incoming = json.loads(CONFIG_PATH.read_text(encoding="utf-8"))
                if isinstance(incoming, dict):
                    self.data.update(incoming)
            except Exception:
                pass

    def save(self) -> None:
        CONFIG_PATH.write_text(json.dumps(self.data, indent=2), encoding="utf-8")

    def get_bool(self, key: str) -> bool:
        return bool(self.data.get(key, DEFAULT_CONFIG.get(key, False)))

    def set_bool(self, key: str, value: bool) -> None:
        self.data[key] = bool(value)
        self.save()

    def get_int(self, key: str) -> int:
        try:
            return max(10, int(self.data.get(key, DEFAULT_CONFIG[key])))
        except Exception:
            return int(DEFAULT_CONFIG[key])
