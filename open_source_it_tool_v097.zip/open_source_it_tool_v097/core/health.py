from __future__ import annotations

import json
import os
import platform
import subprocess
from dataclasses import dataclass, asdict
from typing import List


@dataclass
class HealthItem:
    area: str
    status: str
    summary: str
    details: str = ""

    def as_dict(self):
        return asdict(self)


def is_windows() -> bool:
    return platform.system().lower() == "windows"


def creationflags() -> int:
    return subprocess.CREATE_NO_WINDOW if os.name == "nt" else 0


def run_powershell(script: str, timeout: int = 60) -> tuple[str, str]:
    if not is_windows():
        return "", "This health check requires Windows."

    try:
        result = subprocess.run(
            ["powershell.exe", "-NoProfile", "-ExecutionPolicy", "Bypass", "-WindowStyle", "Hidden", "-Command", script],
            capture_output=True,
            text=True,
            timeout=timeout,
            encoding="utf-8",
            errors="replace",
            creationflags=creationflags(),
        )
        out = result.stdout or ""
        if result.stderr:
            out += "\n" + result.stderr
        return out.strip(), ""
    except subprocess.TimeoutExpired:
        return "", f"PowerShell timed out after {timeout} seconds."
    except Exception as exc:
        return "", str(exc)


def _json(raw: str):
    raw = (raw or "").strip()
    if not raw:
        return None
    starts = [i for i in (raw.find("{"), raw.find("[")) if i >= 0]
    if starts:
        raw = raw[min(starts):]
    try:
        return json.loads(raw)
    except Exception:
        return None


def scan_health() -> List[HealthItem]:
    if not is_windows():
        return [HealthItem("System", "Warning", "Windows health checks are unavailable here.", "Run this on Windows for real results.")]

    script = r"""
$pending = $false
$pendingReasons = @()

$paths = @(
  "HKLM:\SOFTWARE\Microsoft\Windows\CurrentVersion\Component Based Servicing\RebootPending",
  "HKLM:\SOFTWARE\Microsoft\Windows\CurrentVersion\WindowsUpdate\Auto Update\RebootRequired",
  "HKLM:\SYSTEM\CurrentControlSet\Control\Session Manager"
)

if (Test-Path $paths[0]) { $pending = $true; $pendingReasons += "Component servicing" }
if (Test-Path $paths[1]) { $pending = $true; $pendingReasons += "Windows Update" }

try {
  $session = Get-ItemProperty $paths[2] -ErrorAction Stop
  if ($session.PendingFileRenameOperations) {
    $pending = $true
    $pendingReasons += "Pending file rename operations"
  }
} catch {}

$os = Get-CimInstance Win32_OperatingSystem
$lastBoot = $os.LastBootUpTime
$uptime = (Get-Date) - $lastBoot

$defender = $null
try { $defender = Get-MpComputerStatus } catch {}

$firewallProfiles = @()
try { $firewallProfiles = Get-NetFirewallProfile | Select-Object Name, Enabled } catch {}

$disk = Get-CimInstance Win32_LogicalDisk -Filter "DriveType=3" |
  Select-Object DeviceID, Size, FreeSpace

$battery = $null
try { $battery = Get-CimInstance Win32_Battery | Select-Object Name, EstimatedChargeRemaining, BatteryStatus } catch {}

$tpm = $null
try { $tpm = Get-Tpm | Select-Object TpmPresent, TpmReady, TpmEnabled } catch {}

$secureBoot = ""
try { $secureBoot = [string](Confirm-SecureBootUEFI) } catch { $secureBoot = "Unavailable" }

[pscustomobject]@{
  PendingReboot = $pending
  PendingReasons = $pendingReasons
  OSName = [string]$os.Caption
  OSVersion = [string]$os.Version
  LastBoot = [string]$lastBoot
  UptimeHours = [int]$uptime.TotalHours
  DefenderRealTime = if ($defender) { [string]$defender.RealTimeProtectionEnabled } else { "Unavailable" }
  DefenderLastScan = if ($defender) { [string]$defender.QuickScanEndTime } else { "" }
  FirewallProfiles = $firewallProfiles
  Disks = $disk
  Battery = $battery
  TPM = $tpm
  SecureBoot = $secureBoot
} | ConvertTo-Json -Depth 6
"""
    raw, err = run_powershell(script, timeout=90)
    if err:
        return [HealthItem("System", "Warning", "Health check failed.", err)]

    data = _json(raw) or {}
    items: List[HealthItem] = []

    pending = bool(data.get("PendingReboot"))
    reasons = data.get("PendingReasons") or []
    if isinstance(reasons, str):
        reasons = [reasons]
    items.append(HealthItem(
        "Pending Reboot",
        "Warning" if pending else "Good",
        "Restart recommended." if pending else "No pending reboot detected.",
        ", ".join(reasons) if reasons else "No pending reboot markers found.",
    ))

    items.append(HealthItem(
        "Windows",
        "Good",
        f"{data.get('OSName', 'Windows')} — version {data.get('OSVersion', 'Unknown')}",
        f"Last boot: {data.get('LastBoot', 'Unknown')}\nUptime hours: {data.get('UptimeHours', 'Unknown')}",
    ))

    defender = str(data.get("DefenderRealTime", "Unavailable"))
    items.append(HealthItem(
        "Defender",
        "Good" if defender.lower() == "true" else "Warning",
        "Real-time protection is on." if defender.lower() == "true" else "Real-time protection could not be confirmed.",
        f"RealTimeProtectionEnabled: {defender}\nLast quick scan: {data.get('DefenderLastScan', '')}",
    ))

    firewall_profiles = data.get("FirewallProfiles") or []
    if isinstance(firewall_profiles, dict):
        firewall_profiles = [firewall_profiles]
    firewall_ok = all(str(p.get("Enabled", "")).lower() == "true" for p in firewall_profiles) if firewall_profiles else False
    items.append(HealthItem(
        "Firewall",
        "Good" if firewall_ok else "Warning",
        "Firewall is enabled for detected profiles." if firewall_ok else "Firewall status could not be fully confirmed.",
        json.dumps(firewall_profiles, indent=2),
    ))

    disks = data.get("Disks") or []
    if isinstance(disks, dict):
        disks = [disks]
    for disk in disks:
        try:
            size = int(disk.get("Size") or 0)
            free = int(disk.get("FreeSpace") or 0)
            pct = int((free / size) * 100) if size else 0
        except Exception:
            pct = 0
        items.append(HealthItem(
            f"Disk {disk.get('DeviceID', '')}",
            "Warning" if pct < 15 else "Good",
            f"{pct}% free space remaining.",
            f"Size: {disk.get('Size')}\nFreeSpace: {disk.get('FreeSpace')}",
        ))

    battery = data.get("Battery")
    if battery:
        if isinstance(battery, list):
            battery = battery[0]
        charge = battery.get("EstimatedChargeRemaining", "Unknown")
        items.append(HealthItem(
            "Battery",
            "Good",
            f"Battery charge: {charge}%",
            json.dumps(battery, indent=2),
        ))
    else:
        items.append(HealthItem("Battery", "Good", "No battery detected or battery data unavailable.", ""))

    tpm = data.get("TPM")
    if tpm:
        items.append(HealthItem(
            "TPM",
            "Good" if str(tpm.get("TpmReady", "")).lower() == "true" else "Warning",
            "TPM is ready." if str(tpm.get("TpmReady", "")).lower() == "true" else "TPM is not ready or unavailable.",
            json.dumps(tpm, indent=2),
        ))

    secure_boot = str(data.get("SecureBoot", "Unavailable"))
    items.append(HealthItem(
        "Secure Boot",
        "Good" if secure_boot.lower() == "true" else "Warning",
        f"Secure Boot: {secure_boot}",
        "Unavailable can mean legacy boot mode, unsupported firmware, or insufficient permissions.",
    ))

    return items
