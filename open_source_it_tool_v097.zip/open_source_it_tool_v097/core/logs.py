from __future__ import annotations

from datetime import datetime
from pathlib import Path

from core.config import app_dir


def logs_dir() -> Path:
    path = app_dir() / "logs"
    path.mkdir(parents=True, exist_ok=True)
    return path


def write_log(prefix: str, content: str) -> Path:
    """Write command output to a timestamped text log.

    Logs are intentionally plain text so they can be attached to tickets,
    reviewed in Notepad, or deleted when running the tool from a USB drive.
    """
    safe_prefix = "".join(ch if ch.isalnum() or ch in ("-", "_") else "_" for ch in prefix).strip("_")
    stamp = datetime.now().strftime("%Y%m%d_%H%M%S")
    path = logs_dir() / f"{safe_prefix or 'log'}_{stamp}.log"
    path.write_text(content or "", encoding="utf-8", errors="replace")
    return path
