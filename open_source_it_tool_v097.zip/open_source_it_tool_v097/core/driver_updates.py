from __future__ import annotations

import json
import os
import platform
import re
import subprocess
from dataclasses import dataclass, asdict
from typing import Callable, List, Tuple

from core.vendors import detect_vendor


Progress = Callable[[str], None]


@dataclass
class DriverUpdateInfo:
    status: str
    device_name: str
    manufacturer: str = ""
    device_class: str = ""
    installed_version: str = ""
    installed_date: str = ""
    installed_inf: str = ""
    installed_provider: str = ""
    available_version: str = ""
    available_date: str = ""
    available_title: str = ""
    source: str = "Windows Update"
    match_confidence: str = "Not matched"
    update_id: str = ""
    support_link: str = ""
    vendor_link: str = ""
    details: str = ""

    def as_dict(self):
        return asdict(self)


def is_windows() -> bool:
    return platform.system().lower() == "windows"


def creationflags() -> int:
    return subprocess.CREATE_NO_WINDOW if os.name == "nt" else 0


def run_powershell(script: str, timeout: int = 45) -> Tuple[str, str]:
    if not is_windows():
        return "", "Driver update scanning requires Windows."

    try:
        result = subprocess.run(
            ["powershell.exe", "-NoProfile", "-ExecutionPolicy", "Bypass", "-WindowStyle", "Hidden", "-Command", script],
            capture_output=True,
            text=True,
            timeout=timeout,
            encoding="utf-8",
            errors="replace",
            creationflags=creationflags(),
        )
        out = result.stdout or ""
        if result.stderr:
            out += "\n" + result.stderr
        return out.strip(), ""
    except subprocess.TimeoutExpired:
        return "", f"PowerShell timed out after {timeout} seconds."
    except Exception as exc:
        return "", str(exc)


def normalize_json(raw: str):
    raw = (raw or "").strip()
    if not raw:
        return None

    starts = [i for i in (raw.find("{"), raw.find("[")) if i >= 0]
    if starts:
        raw = raw[min(starts):]

    try:
        return json.loads(raw)
    except Exception:
        return None


def as_list(value) -> list:
    if value is None:
        return []
    if isinstance(value, list):
        return value
    if isinstance(value, dict):
        return [value]
    return []


def clean(value) -> str:
    return re.sub(r"\s+", " ", str(value or "").replace("\r", " ").replace("\n", " ")).strip()


def scan_installed_driver_inventory(progress: Progress | None = None) -> list[dict]:
    if progress:
        progress("Reading installed driver versions...")

    script = r"""
$items = Get-CimInstance Win32_PnPSignedDriver -ErrorAction SilentlyContinue |
  Where-Object { $_.DeviceName } |
  Select-Object DeviceName, Manufacturer, DeviceClass, DriverVersion, DriverDate, InfName, DriverProviderName, DeviceID
$items | ConvertTo-Json -Depth 5
"""
    raw, err = run_powershell(script, timeout=35)
    if err:
        return [{
            "DeviceName": "Driver inventory unavailable",
            "Manufacturer": "",
            "DeviceClass": "",
            "DriverVersion": "",
            "DriverDate": "",
            "InfName": "",
            "DriverProviderName": "",
            "DeviceID": "",
            "Error": err,
        }]

    data = as_list(normalize_json(raw))
    cleaned = []

    for item in data:
        cleaned.append({
            "DeviceName": clean(item.get("DeviceName")),
            "Manufacturer": clean(item.get("Manufacturer")),
            "DeviceClass": clean(item.get("DeviceClass")),
            "DriverVersion": clean(item.get("DriverVersion")),
            "DriverDate": clean(item.get("DriverDate")),
            "InfName": clean(item.get("InfName")),
            "DriverProviderName": clean(item.get("DriverProviderName")),
            "DeviceID": clean(item.get("DeviceID")),
        })

    return cleaned


def scan_windows_update_driver_updates(progress: Progress | None = None) -> list[dict]:
    if progress:
        progress("Checking Windows Update for driver updates...")

    # Driver update COM objects expose additional properties on some machines.
    # Get-Prop keeps the scan stable when a property is unavailable.
    script = r"""
function Get-Prop($obj, $name) {
  try {
    $value = $obj.$name
    if ($null -eq $value) { return "" }
    return [string]$value
  } catch {
    return ""
  }
}

try {
  $session = New-Object -ComObject Microsoft.Update.Session
  $searcher = $session.CreateUpdateSearcher()
  $result = $searcher.Search("IsInstalled=0 and IsHidden=0")
  $items = @()

  for ($i = 0; $i -lt $result.Updates.Count; $i++) {
    $u = $result.Updates.Item($i)

    $cats = @()
    foreach ($cat in $u.Categories) {
      if ($cat.Name) { $cats += [string]$cat.Name }
    }

    $isDriver = $false
    if ([int]$u.Type -eq 2) { $isDriver = $true }
    foreach ($cat in $cats) {
      if ($cat -match "Driver") { $isDriver = $true }
    }
    if ($u.Title -match "driver") { $isDriver = $true }

    if ($isDriver) {
      $urls = @()
      foreach ($url in $u.MoreInfoUrls) {
        if ($url) { $urls += [string]$url }
      }

      $items += [pscustomobject]@{
        Title = [string]$u.Title
        Description = [string]$u.Description
        Categories = $cats
        LastDeploymentChangeTime = [string]$u.LastDeploymentChangeTime
        SupportUrl = [string]$u.SupportUrl
        MoreInfoUrls = $urls
        UpdateID = [string]$u.Identity.UpdateID
        DriverManufacturer = Get-Prop $u "DriverManufacturer"
        DriverClass = Get-Prop $u "DriverClass"
        DriverModel = Get-Prop $u "DriverModel"
        DriverProvider = Get-Prop $u "DriverProvider"
        DriverVerDate = Get-Prop $u "DriverVerDate"
        DriverVersion = Get-Prop $u "DriverVersion"
        DriverHardwareID = Get-Prop $u "DriverHardwareID"
      }
    }
  }

  $items | ConvertTo-Json -Depth 6
}
catch {
  @([pscustomobject]@{
    Title = "Windows Update driver scan failed"
    Description = $_.Exception.Message
    Categories = @("Error")
    LastDeploymentChangeTime = ""
    SupportUrl = ""
    MoreInfoUrls = @()
    UpdateID = ""
    DriverManufacturer = ""
    DriverClass = ""
    DriverModel = ""
    DriverProvider = ""
    DriverVerDate = ""
    DriverVersion = ""
    DriverHardwareID = ""
  }) | ConvertTo-Json -Depth 5
}
"""
    raw, err = run_powershell(script, timeout=45)
    if err:
        return [{
            "Title": "Windows Update driver scan unavailable",
            "Description": err,
            "Categories": ["Error"],
            "LastDeploymentChangeTime": "",
            "SupportUrl": "",
            "MoreInfoUrls": [],
            "UpdateID": "",
            "DriverManufacturer": "",
            "DriverClass": "",
            "DriverModel": "",
            "DriverProvider": "",
            "DriverVerDate": "",
            "DriverVersion": "",
            "DriverHardwareID": "",
        }]

    return as_list(normalize_json(raw))


def normalize_tokens(value: str) -> set[str]:
    value = re.sub(r"[^a-z0-9]+", " ", (value or "").lower())
    noise = {
        "driver", "drivers", "device", "controller", "adapter", "microsoft",
        "corporation", "inc", "llc", "windows", "update", "software", "component"
    }
    return {part for part in value.split() if len(part) > 2 and part not in noise}


def parse_version(text: str) -> str:
    text = text or ""
    match = re.search(r"\b\d+(?:\.\d+){1,5}\b", text)
    return match.group(0) if match else ""


def parse_date(text: str) -> str:
    text = text or ""
    # Handles common date fragments in update titles.
    patterns = [
        r"\b\d{4}-\d{1,2}-\d{1,2}\b",
        r"\b\d{1,2}/\d{1,2}/\d{2,4}\b",
        r"\b(?:Jan|Feb|Mar|Apr|May|Jun|Jul|Aug|Sep|Sept|Oct|Nov|Dec)[a-z]*\s+\d{1,2},?\s+\d{4}\b",
    ]
    for pattern in patterns:
        match = re.search(pattern, text, re.I)
        if match:
            return match.group(0)
    return ""


def update_text(update: dict) -> str:
    values = [
        update.get("Title", ""),
        update.get("Description", ""),
        update.get("DriverManufacturer", ""),
        update.get("DriverClass", ""),
        update.get("DriverModel", ""),
        update.get("DriverProvider", ""),
        update.get("DriverHardwareID", ""),
    ]
    return " ".join(clean(v) for v in values)


def installed_text(driver: dict) -> str:
    values = [
        driver.get("DeviceName", ""),
        driver.get("Manufacturer", ""),
        driver.get("DeviceClass", ""),
        driver.get("DriverProviderName", ""),
        driver.get("InfName", ""),
        driver.get("DeviceID", ""),
    ]
    return " ".join(clean(v) for v in values)


def match_update_to_driver(update: dict, installed: list[dict]) -> tuple[dict | None, str]:
    if not installed:
        return None, "Not matched"

    u_text = update_text(update)
    u_tokens = normalize_tokens(u_text)
    u_vendor, _ = detect_vendor(u_text)

    best = None
    best_score = 0

    for driver in installed:
        d_text = installed_text(driver)
        d_tokens = normalize_tokens(d_text)
        d_vendor, _ = detect_vendor(d_text)

        overlap = len(u_tokens.intersection(d_tokens))
        vendor_bonus = 3 if u_vendor and d_vendor and u_vendor == d_vendor else 0
        manufacturer_bonus = 2 if clean(update.get("DriverManufacturer")).lower() and clean(update.get("DriverManufacturer")).lower() in d_text.lower() else 0
        class_bonus = 1 if clean(update.get("DriverClass")).lower() and clean(update.get("DriverClass")).lower() in d_text.lower() else 0

        score = overlap + vendor_bonus + manufacturer_bonus + class_bonus
        if score > best_score:
            best = driver
            best_score = score

    if best_score >= 7:
        return best, "High"
    if best_score >= 4:
        return best, "Medium"
    if best_score >= 2:
        return best, "Low"
    return None, "Not matched"


def available_link(update: dict, vendor_link: str) -> str:
    urls = update.get("MoreInfoUrls", [])
    if isinstance(urls, str):
        urls = [urls]
    for url in urls:
        if clean(url):
            return clean(url)
    if clean(update.get("SupportUrl")):
        return clean(update.get("SupportUrl"))
    return vendor_link


def build_driver_rows(progress: Progress | None = None) -> List[DriverUpdateInfo]:
    installed = scan_installed_driver_inventory(progress)
    updates = scan_windows_update_driver_updates(progress)

    rows: List[DriverUpdateInfo] = []

    # First, show available driver updates with installed/available data side-by-side.
    for update in updates:
        title = clean(update.get("Title", ""))

        if not title:
            continue

        if "scan failed" in title.lower() or "scan unavailable" in title.lower():
            rows.append(DriverUpdateInfo(
                status="WARNING",
                device_name=title,
                source="Windows Update",
                match_confidence="Scanner warning",
                details=clean(update.get("Description", "")),
            ))
            continue

        matched, confidence = match_update_to_driver(update, installed)
        u_text = update_text(update)
        vendor, vendor_link = detect_vendor(u_text)

        if matched:
            device_name = clean(matched.get("DeviceName", "")) or clean(update.get("DriverModel", "")) or title
            manufacturer = clean(matched.get("Manufacturer", "")) or clean(update.get("DriverManufacturer", "")) or vendor
            installed_version = clean(matched.get("DriverVersion", ""))
            installed_date = clean(matched.get("DriverDate", ""))
            installed_inf = clean(matched.get("InfName", ""))
            installed_provider = clean(matched.get("DriverProviderName", ""))
            device_class = clean(matched.get("DeviceClass", "")) or clean(update.get("DriverClass", ""))
        else:
            device_name = clean(update.get("DriverModel", "")) or title
            manufacturer = clean(update.get("DriverManufacturer", "")) or vendor
            installed_version = ""
            installed_date = ""
            installed_inf = ""
            installed_provider = ""
            device_class = clean(update.get("DriverClass", ""))

        available_version = clean(update.get("DriverVersion", "")) or parse_version(title) or parse_version(clean(update.get("Description", "")))
        available_date = clean(update.get("DriverVerDate", "")) or clean(update.get("LastDeploymentChangeTime", "")) or parse_date(title)

        link = available_link(update, vendor_link)

        rows.append(DriverUpdateInfo(
            status="YES",
            device_name=device_name,
            manufacturer=manufacturer,
            device_class=device_class,
            installed_version=installed_version,
            installed_date=installed_date,
            installed_inf=installed_inf,
            installed_provider=installed_provider,
            available_version=available_version,
            available_date=available_date,
            available_title=title,
            source="Windows Update",
            match_confidence=confidence,
            update_id=clean(update.get("UpdateID", "")),
            support_link=link,
            vendor_link=vendor_link,
            details=clean(update.get("Description", "")),
        ))

    # If no driver updates are available, or Windows Update returned only a
    # warning, still show a bounded installed-driver inventory so the page does
    # not look stalled or empty.
    only_warnings = bool(rows) and all(r.status == "WARNING" for r in rows)
    if not rows or only_warnings:
        shown = 0
        for driver in installed:
            if shown >= 350:
                rows.append(DriverUpdateInfo(
                    status="WARNING",
                    device_name="Installed driver inventory truncated",
                    available_version="Showing first 350 drivers",
                    source="Installed driver inventory",
                    match_confidence="Limit reached",
                    details="The installed driver list was limited to keep the UI responsive.",
                ))
                break

            name = clean(driver.get("DeviceName", ""))
            if not name:
                continue
            text = installed_text(driver)
            vendor, vendor_link = detect_vendor(text)
            rows.append(DriverUpdateInfo(
                status="NO",
                device_name=name,
                manufacturer=clean(driver.get("Manufacturer", "")) or vendor,
                device_class=clean(driver.get("DeviceClass", "")),
                installed_version=clean(driver.get("DriverVersion", "")),
                installed_date=clean(driver.get("DriverDate", "")),
                installed_inf=clean(driver.get("InfName", "")),
                installed_provider=clean(driver.get("DriverProviderName", "")),
                available_version="No driver update detected",
                available_date="",
                source="Installed driver inventory + Windows Update",
                match_confidence="No available update",
                support_link=vendor_link,
                vendor_link=vendor_link,
                details="Installed driver inventory row. Windows Update did not report an available driver update for this device.",
            ))
            shown += 1

    return sorted(rows, key=lambda r: (r.status != "YES", r.status == "WARNING", r.device_name.lower()))
