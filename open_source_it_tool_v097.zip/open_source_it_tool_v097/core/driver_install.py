from __future__ import annotations

import os
import platform
import subprocess
from datetime import datetime
from pathlib import Path
from typing import Callable, Tuple

from core.config import app_dir


Progress = Callable[[str], None]


def is_windows() -> bool:
    return platform.system().lower() == "windows"


def creationflags() -> int:
    return subprocess.CREATE_NO_WINDOW if os.name == "nt" else 0


def run_cmd(command: list[str], timeout: int = 1800) -> Tuple[str, int]:
    try:
        result = subprocess.run(
            command,
            capture_output=True,
            text=True,
            timeout=timeout,
            encoding="utf-8",
            errors="replace",
            creationflags=creationflags(),
        )
    except subprocess.TimeoutExpired:
        return f"Timed out after {timeout} seconds:\n{' '.join(command)}", 124
    except Exception as exc:
        return f"Failed to launch command:\n{exc}", 1

    output = result.stdout or ""
    if result.stderr:
        output += "\n" + result.stderr
    return output.strip(), int(result.returncode)


def run_powershell(script: str, timeout: int = 1800) -> Tuple[str, int]:
    if not is_windows():
        return "Driver installation requires Windows.", 1

    return run_cmd(
        ["powershell.exe", "-NoProfile", "-ExecutionPolicy", "Bypass", "-WindowStyle", "Hidden", "-Command", script],
        timeout=timeout,
    )


def driver_backup_root() -> Path:
    root = app_dir() / "driver_backups"
    root.mkdir(parents=True, exist_ok=True)
    return root


def new_backup_folder() -> Path:
    stamp = datetime.now().strftime("%Y%m%d_%H%M%S")
    path = driver_backup_root() / f"drivers_{stamp}"
    path.mkdir(parents=True, exist_ok=True)
    return path


def create_restore_point(progress: Progress | None = None) -> str:
    if progress:
        progress("Creating system restore point...")

    # Restore point creation can fail if System Protection is disabled or
    # throttled. Continue with driver export and record the exact outcome.
    script = r"""
try {
  Checkpoint-Computer -Description "Open Source IT Tool - Driver Update" -RestorePointType "MODIFY_SETTINGS" -ErrorAction Stop
  Write-Output "Restore point created successfully."
}
catch {
  Write-Output "Restore point could not be created:"
  Write-Output $_.Exception.Message
  Write-Output "The driver backup step will still run before installation."
}
"""
    output, _code = run_powershell(script, timeout=300)
    return output


def export_current_drivers(progress: Progress | None = None) -> tuple[str, Path]:
    backup_dir = new_backup_folder()
    if progress:
        progress(f"Exporting current drivers to {backup_dir.name}...")

    output, code = run_cmd(
        ["pnputil", "/export-driver", "*", str(backup_dir)],
        timeout=1800,
    )

    if code != 0:
        output = (
            output
            + "\n\nDriver export did not complete successfully."
            + "\nThis usually requires Administrator mode."
        ).strip()

    return output, backup_dir


def install_windows_update_drivers(progress: Progress | None = None) -> str:
    if progress:
        progress("Installing driver updates from Windows Update...")

    # Scope is limited to official driver-class updates returned by Windows Update.
    script = r"""
try {
  $session = New-Object -ComObject Microsoft.Update.Session
  $searcher = $session.CreateUpdateSearcher()
  $result = $searcher.Search("IsInstalled=0 and IsHidden=0")

  $driverUpdates = New-Object -ComObject Microsoft.Update.UpdateColl

  for ($i = 0; $i -lt $result.Updates.Count; $i++) {
    $u = $result.Updates.Item($i)

    $isDriver = $false
    if ([int]$u.Type -eq 2) { $isDriver = $true }
    foreach ($cat in $u.Categories) {
      if ($cat.Name -match "Driver") { $isDriver = $true }
    }
    if ($u.Title -match "driver") { $isDriver = $true }

    if ($isDriver) {
      Write-Output ("Queued driver update: " + $u.Title)
      [void]$driverUpdates.Add($u)
    }
  }

  if ($driverUpdates.Count -eq 0) {
    Write-Output "No available Windows Update driver updates were found."
    exit 0
  }

  Write-Output ("Driver updates queued: " + $driverUpdates.Count)

  $downloader = $session.CreateUpdateDownloader()
  $downloader.Updates = $driverUpdates
  $downloadResult = $downloader.Download()
  Write-Output ("Download result code: " + $downloadResult.ResultCode)

  $installer = $session.CreateUpdateInstaller()
  $installer.Updates = $driverUpdates
  $installResult = $installer.Install()

  Write-Output ("Install result code: " + $installResult.ResultCode)
  Write-Output ("Reboot required: " + $installResult.RebootRequired)

  for ($i = 0; $i -lt $driverUpdates.Count; $i++) {
    $itemResult = $installResult.GetUpdateResult($i)
    Write-Output ("Result for [" + $driverUpdates.Item($i).Title + "]: " + $itemResult.ResultCode)
  }
}
catch {
  Write-Output "Driver update install failed:"
  Write-Output $_.Exception.Message
  exit 1
}
"""
    output, _code = run_powershell(script, timeout=2400)
    return output


def rollback_notes(backup_dir: Path) -> str:
    return f"""
Rollback notes
==============

Current driver backup folder:
{backup_dir}

If a driver causes issues:

1. Open Device Manager.
2. Right-click the affected device.
3. Choose Properties.
4. Open the Driver tab.
5. Try Roll Back Driver first.
6. If rollback is unavailable, choose Update Driver.
7. Choose Browse my computer for drivers.
8. Point Windows to the backup folder above.

The backup was created before installation using pnputil.
""".strip()


def automated_driver_update(progress: Progress | None = None) -> str:
    """Run the full driver-update workflow with one app confirmation."""
    sections: list[str] = []

    sections.append("=" * 80)
    sections.append("STEP 1 - RESTORE POINT")
    sections.append("=" * 80)
    sections.append(create_restore_point(progress))

    sections.append("")
    sections.append("=" * 80)
    sections.append("STEP 2 - CURRENT DRIVER BACKUP")
    sections.append("=" * 80)
    export_output, backup_dir = export_current_drivers(progress)
    sections.append(export_output)
    sections.append(f"\nBackup folder: {backup_dir}")

    sections.append("")
    sections.append("=" * 80)
    sections.append("STEP 3 - WINDOWS UPDATE DRIVER INSTALL")
    sections.append("=" * 80)
    sections.append(install_windows_update_drivers(progress))

    sections.append("")
    sections.append("=" * 80)
    sections.append("STEP 4 - ROLLBACK INFORMATION")
    sections.append("=" * 80)
    sections.append(rollback_notes(backup_dir))

    if progress:
        progress("Driver update workflow complete.")

    return "\n".join(sections).strip()
