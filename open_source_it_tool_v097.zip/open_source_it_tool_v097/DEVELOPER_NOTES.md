# Developer Notes

## v0.8.1 cleanup pass

- Removed production debug artifacts from the package.
- Added plain-text command logs under `logs/`.
- Tightened `Update Detected Apps` so it processes scanned winget rows instead of running a blind global update.
- Broadened Cleaner analysis for consumer use.
- Added a More Info tab for technical cleaner detail.
- Added cleaner targets for browser cache, crash dumps, Windows Update cache review, and personal-folder review.
- Added table repaint suppression while loading rows.
- Left driver updates as detection/manual-vendor-link only.

## Safety decisions

- Personal folders are review-only.
- Windows Update download cache is review-only until a proper service-stop workflow is added.
- Browser cache cleanup skips locked files.
- Cleaner actions are confirmation-gated.
- Package updates are limited to detected winget package IDs.


## v0.8.2 notes

- Added startup elevation through ShellExecuteW `runas`.
- Added PyInstaller `--uac-admin` flag for the portable EXE build.
- Kept UAC approval mandatory; the app requests elevation, Windows grants it.
- Replaced danger-red button treatment with warning-style action buttons.
- Added admin status badge in the header.
- Simplified some button labels for a more consumer-facing layout.


## v0.8.3 notes

- Added dashboard tab as the consumer entry point.
- Added shared `confirm_action` helper to remove generic question prompts.
- Confirmation dialogs now list specific action behavior for updater, cleaner, and toolkit flows.
- Dashboard summary is derived from the filtered scan rows and updates after scans/searches.
- Existing table and technical tabs remain available for advanced users.


## v0.8.4 notes

- Added `core/driver_updates.py`.
- Driver comparison uses installed `Win32_PnPSignedDriver` inventory and available Windows Update driver updates.
- Available driver metadata is collected from Windows Update COM properties when exposed.
- Matching is heuristic and reports High/Medium/Low confidence.
- Driver install is intentionally not wired yet. Add restore point, export current driver, and rollback guidance before enabling direct install.


## v0.8.5 notes

- Added `core/driver_install.py`.
- Added guarded automated driver workflow:
  1. restore point attempt
  2. pnputil driver export
  3. Windows Update driver install
  4. rollback notes
- Installation scope is limited to driver updates returned by the Windows Update COM search.
- Workflow uses one confirmation, then runs without additional app prompts.
- Rescan is triggered after completion to refresh the comparison table.


## v0.9 notes

- `ui/main_window.py` was refactored around sidebar navigation and `QStackedWidget`.
- `ui/glass_styles.py` was rewritten for the #D5E3E8 light theme.
- Added `core/health.py` for read-only system health checks.
- Added numeric progress signals to long-running workers.
- Kept advanced details out of the primary pages and routed them through More Info.
- Kept destructive and system-changing actions confirmation-gated.


## v0.9.1 notes

- Removed global scan button from the header to avoid cross-page action clutter.
- Added page-specific scan/action buttons.
- Updates page filters out `item_type == "Driver"` because drivers have their own workflow.
- Added `set_idle_progress()` and task-aware progress text.
- Added Windows Update scan fallback row with `ms-settings:windowsupdate`.
- Added Home card count updates.
- Kept Windows Update fallback non-destructive; it does not force service resets during normal scanning.


## v0.9.2 notes

- Added `scan_updates_only()` in `core/scanners.py`.
- Updates page no longer calls the driver inventory scanner.
- Added `scan_windows_update_fallback()` to keep Windows Update failures actionable.
- Home page now acts as a status dashboard, not a duplicate navigation surface.
- Left sidebar remains the main navigation model.


## v0.9.4 notes

Static review found the likely UI crash pattern: users could start a new worker action while the same QThread was still running, overwriting the stored worker reference. That can trigger `QThread: Destroyed while thread is still running`.

Fixes:
- Added `worker_running()` and `show_task_busy()`.
- Guarded all worker-backed actions.
- Set worker references to None in completion handlers.
- Changed progress connections to page-specific lambdas.
- Wrapped Reports/Open Folder actions.
- Made toolkit runner exception-safe and timeout-aware.


## v0.9.5 notes

- Added section-scoped progress widgets via `section_progress_widget()`.
- `set_progress()` now updates only the relevant section progress bar.
- Cleaner `_folder_size()` rewritten as bounded `os.scandir()` traversal with time limits.
- `driver_updates.py` lowered Windows Update scan timeout and caps installed inventory rows.
- PowerShell command arrays now include `-WindowStyle Hidden`.
- Disabled the interactive BAT menu action; converted commands remain available in Repair.


## v0.9.6 notes

- Copied uploaded `AIO.ico` into `assets/`.
- Added `asset_path()` helper for source and PyInstaller `_MEIPASS` lookup.
- Added `QIcon` window icon and `QPixmap` brand rendering.
- Reworked QSS to mimic a classic cleaner utility layout while retaining the app palette.
- Updated `build_exe.bat` with `--icon assets\\AIO.ico`.


## v0.9.7 notes

Root cause of the "always opens 7 Days to Die" details bug:
- `QTableWidget` sorting changes visual row order.
- `selected_update_row()` was using the visual row as an index into `filtered_rows`.
- After sorting, that index can point to the wrong app.
- Fix: store the source row index in every cell using `Qt.UserRole`, then read that index on double-click/selection.

Icon fix:
- Rebuilt `assets/AIO.ico` as a multi-size icon.
- Switched QLabel logo rendering from direct `QPixmap(ico).scaled()` to `QIcon.pixmap()`.
