@echo off
title Build Open Source IT Tool Portable EXE

if not exist .venv (
    echo Creating virtual environment...
    python -m venv .venv
)

call .venv\Scripts\activate.bat

echo Installing requirements...
python -m pip install --upgrade pip
python -m pip install -r requirements.txt

echo.
echo Building portable EXE...
python -m PyInstaller --onefile --windowed --uac-admin --name OpenSourceITTool --icon "assets\AIO.ico" main.py --add-data "assets;assets"

echo.
echo Build complete.
echo Copy this to USB:
echo dist\OpenSourceITTool.exe
pause
