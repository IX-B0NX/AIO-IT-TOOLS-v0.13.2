@echo off
title Open Source IT Tool v0.8

if not exist .venv (
    echo Creating virtual environment...
    python -m venv .venv
)

call .venv\Scripts\activate.bat

echo Installing requirements...
python -m pip install --upgrade pip
python -m pip install -r requirements.txt

echo Starting Open Source IT Tool...
python main.py

pause
