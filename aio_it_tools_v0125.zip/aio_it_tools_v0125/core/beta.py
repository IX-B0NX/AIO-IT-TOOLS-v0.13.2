from __future__ import annotations

APP_PUBLIC_VERSION = "0.12.5"
RELEASE_CHANNEL = "Public Beta Candidate"

BETA_WARNING = """
AIO IT TOOLS is currently a Public Beta Candidate.

Use it for testing and feedback before consumer release. Some workflows rely on Windows components such as winget, Windows Update, PowerShell, Device Manager, and administrator permissions. Behavior can vary by PC, policy, security software, and Windows version.

Single-EXE goal:
- Consumers should eventually receive only AIOITTools.exe from the dist folder.
- Runtime logs, support ZIPs, settings, and driver backups are created automatically.
- No installer is planned for now.

Safer defaults are enabled:
- Cleaner personal folders are review-only.
- Driver automation requires review and safety checks.
- Advanced repair tools are hidden until enabled.
- Support ZIP export is available for troubleshooting.
""".strip()

KNOWN_ISSUES = [
    {
        "area": "Windows Update policy restrictions",
        "severity": "Medium",
        "status": "Partially improved in v0.12.5",
        "issue": "Automatic scan can still fail on PCs where Windows Update is disabled, restricted by organization policy, or broken outside this app.",
        "workaround": "Use Check Update Health, Repair Windows Update Services, then open Windows Update manually if policy still blocks scanning.",
    },
    {
        "area": "winget / App Installer dependency",
        "severity": "Medium",
        "status": "Partially improved in v0.12.5",
        "issue": "winget depends on Microsoft App Installer and can still be missing, blocked, or return output formats the parser cannot fully understand.",
        "workaround": "Use Open App Installer, Repair winget Sources, then scan again.",
    },
    {
        "area": "Driver matching confidence",
        "severity": "High",
        "status": "Partially improved in v0.12.5",
        "issue": "Driver comparison depends on Windows Update metadata and may not strongly match every installed device.",
        "workaround": "Use Review Drivers and pay attention to lower-confidence warnings before automated driver updates.",
    },
    {
        "area": "Unsigned EXE reputation",
        "severity": "Medium",
        "status": "Unresolved until code signing",
        "issue": "Unsigned beta builds may trigger Windows SmartScreen or antivirus reputation prompts.",
        "workaround": "Use only builds from your trusted source until code signing is added.",
    },
    {
        "area": "Windows-only Wi-Fi password display",
        "severity": "Low",
        "status": "Improved in v0.12.5; still needs Windows admin test",
        "issue": "Wi-Fi password display depends on Windows netsh and may not show keys for every profile depending on policy/security state.",
        "workaround": "Run as administrator and verify output in Repair > Wi-Fi Profiles + Passwords.",
    },
]


def known_issues_text() -> str:
    lines = ["Known Issues", "============", ""]
    for item in KNOWN_ISSUES:
        lines.append(f"[{item['severity']}] {item['area']} — {item.get('status', 'Tracked')}")
        lines.append(f"  Issue: {item['issue']}")
        lines.append(f"  Workaround: {item['workaround']}")
        lines.append("")
    return "\n".join(lines).strip()
