# AIO IT TOOLS v0.13.1

**AIO IT TOOLS** is a portfolio-focused Windows maintenance utility created by Ruben Pacheco.

It combines app update checks, Windows Update health checks, driver review workflows, cleanup tools, repair tools, reports, runtime diagnostics, and Support ZIP export into a polished PySide6 desktop interface.

## Portfolio purpose

This project is intended to demonstrate:

- Windows desktop utility design
- PySide6 GUI development
- background worker/thread design
- Windows command integration
- safer repair workflows
- logging and diagnostics
- user-focused UI iteration
- privacy-aware support export
- practical system administration tooling

## Why the code is open

This project is intentionally kept readable and reviewable.

For a portfolio project, open source is better than code obfuscation because reviewers can inspect:

- UI architecture
- safety checks
- subprocess handling
- update/driver workflow decisions
- error handling
- project documentation

## Privacy and safety choices

AIO IT TOOLS does **not** store Wi-Fi passwords.

When Wi-Fi profile passwords are shown, they are retrieved locally from Windows `netsh` only after administrator approval. Sensitive values are redacted from Support ZIP/log output where possible.

Privacy layer:

- `core/privacy.py`
- redacts Wi-Fi key content
- redacts common password/token/key patterns
- applies redaction to Support ZIP text output
- keeps code open instead of hidden

## Features

- Home dashboard
- App update scan
- Optional winget update provider
- Windows Update health checks
- Conservative Windows Update service repair
- Driver update comparison
- Driver review and guarded automation
- Cleaner with safe defaults
- Advanced cleanup toggle
- Repair tools with advanced toggle
- Wi-Fi profiles and local password display
- Health scan
- Reports
- Runtime self-test
- Support ZIP export
- System Notes page

## Tech stack

- Python
- PySide6
- Windows command-line tools
- PowerShell integration
- PyInstaller build support

## Running from source

```bat
run_aio_it_tools.bat
```

The launcher checks for PySide6 and installs requirements if needed.

## Building the EXE

```bat
build_exe.bat
```

Expected output:

```text
dist\AIOITTools.exe
```

## Unsigned portfolio build note

This is an unsigned portfolio build. Windows may show a SmartScreen warning for unsigned executables.

For a real public release, the next step would be Authenticode code signing. For portfolio review, running from source or building locally is the recommended path.

## Optional winget provider

AIO IT TOOLS uses winget when available. If winget is missing or broken, the app still provides system diagnostics, repair guidance, and App Installer repair links.

This makes winget an optional provider rather than a hard requirement.

## System Notes

The remaining System Notes are external Windows or deployment dependencies:

- Windows Update policy restrictions
- Optional winget provider behavior
- Unsigned portfolio build reputation
- Windows-only Wi-Fi password display behavior

## Recommended portfolio screenshots

Capture these views for your portfolio:

1. Home dashboard
2. Updates page
3. Drivers page with review workflow
4. Cleaner page with advanced toggle enabled
5. Repair page with advanced toggle enabled
6. Health page
7. Reports page
8. System Notes page
