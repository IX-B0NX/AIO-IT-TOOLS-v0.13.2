from __future__ import annotations

import re
from typing import Any


REDACTION = "[REDACTED]"

SENSITIVE_PATTERNS: list[tuple[re.Pattern[str], str]] = [
    # Windows netsh Wi-Fi key output
    (re.compile(r"(?im)^(\s*Key Content\s*:\s*)(.+)$"), r"\1" + REDACTION),
    # Generic secrets/tokens/passwords in logs or support reports
    (re.compile(r"(?im)^(\s*(password|passwd|pwd|secret|token|api[_-]?key|access[_-]?key)\s*[:=]\s*)(.+)$"), r"\1" + REDACTION),
    # Bearer/API token style strings
    (re.compile(r"(?i)(bearer\s+)[A-Za-z0-9._\-+/=]{12,}"), r"\1" + REDACTION),
]


def redact_text(value: Any) -> str:
    """Return text with common sensitive values removed.

    This is not encryption. It is a portfolio-safe privacy layer for logs and
    Support ZIPs so local secrets are not accidentally shared.
    """
    text = "" if value is None else str(value)
    for pattern, replacement in SENSITIVE_PATTERNS:
        text = pattern.sub(replacement, text)
    return text


def safe_for_support_zip(value: Any) -> str:
    return redact_text(value)
