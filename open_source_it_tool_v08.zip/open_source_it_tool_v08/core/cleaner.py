from __future__ import annotations

import os
import shutil
import subprocess
import tempfile
from dataclasses import dataclass
from pathlib import Path
from typing import List, Tuple


@dataclass
class CleanerTarget:
    name: str
    path: str
    estimated_bytes: int = 0
    risk: str = "Safe"
    description: str = ""


def _folder_size(path: Path, max_items: int = 20000) -> int:
    total = 0
    count = 0
    if not path.exists():
        return 0
    for root, _dirs, files in os.walk(path, topdown=True):
        for file in files:
            try:
                total += (Path(root) / file).stat().st_size
            except OSError:
                pass
            count += 1
            if count >= max_items:
                return total
    return total


def format_bytes(num: int) -> str:
    value = float(num)
    for unit in ["B", "KB", "MB", "GB", "TB"]:
        if value < 1024:
            return f"{value:.1f} {unit}"
        value /= 1024
    return f"{value:.1f} PB"


def analyze_cleaner() -> List[CleanerTarget]:
    targets: List[CleanerTarget] = []
    user_temp = Path(tempfile.gettempdir())
    targets.append(CleanerTarget(
        "User Temp Files",
        str(user_temp),
        _folder_size(user_temp),
        "Safe",
        "Deletes files from the current user's temp folder. Locked files are skipped.",
    ))

    win_temp = Path(os.environ.get("SystemRoot", r"C:\Windows")) / "Temp"
    targets.append(CleanerTarget(
        "Windows Temp Files",
        str(win_temp),
        _folder_size(win_temp),
        "Admin",
        "Deletes Windows temp files where permissions allow. Locked files are skipped.",
    ))

    thumbnails = Path(os.environ.get("LOCALAPPDATA", "")) / "Microsoft" / "Windows" / "Explorer"
    thumb_size = 0
    if thumbnails.exists():
        for p in thumbnails.glob("thumbcache*.db"):
            try:
                thumb_size += p.stat().st_size
            except OSError:
                pass
    targets.append(CleanerTarget(
        "Thumbnail Cache",
        str(thumbnails),
        thumb_size,
        "Safe",
        "Deletes Windows thumbnail cache database files when possible.",
    ))

    crash_dumps = Path(os.environ.get("LOCALAPPDATA", "")) / "CrashDumps"
    targets.append(CleanerTarget(
        "User Crash Dumps",
        str(crash_dumps),
        _folder_size(crash_dumps),
        "Safe",
        "Deletes user-mode crash dump files.",
    ))

    return targets


def clean_folder_contents(path: str) -> Tuple[str, int]:
    folder = Path(path)
    if not folder.exists() or not folder.is_dir():
        return f"Folder not found: {path}", 0

    deleted = 0
    skipped = 0
    freed = 0

    for item in folder.iterdir():
        try:
            if item.is_file() or item.is_symlink():
                try:
                    freed += item.stat().st_size
                except OSError:
                    pass
                item.unlink()
                deleted += 1
            elif item.is_dir():
                try:
                    freed += _folder_size(item)
                except OSError:
                    pass
                shutil.rmtree(item, ignore_errors=False)
                deleted += 1
        except OSError:
            skipped += 1

    return (
        f"Cleaned: {path}\n"
        f"Deleted items: {deleted}\n"
        f"Skipped locked/protected items: {skipped}\n"
        f"Estimated freed: {format_bytes(freed)}",
        freed,
    )


def clean_user_temp() -> Tuple[str, int]:
    return clean_folder_contents(tempfile.gettempdir())


def clean_windows_temp() -> Tuple[str, int]:
    return clean_folder_contents(str(Path(os.environ.get("SystemRoot", r"C:\Windows")) / "Temp"))


def clean_thumbnail_cache() -> Tuple[str, int]:
    folder = Path(os.environ.get("LOCALAPPDATA", "")) / "Microsoft" / "Windows" / "Explorer"
    if not folder.exists():
        return "Thumbnail cache folder not found.", 0

    deleted = 0
    skipped = 0
    freed = 0
    for file in folder.glob("thumbcache*.db"):
        try:
            freed += file.stat().st_size
            file.unlink()
            deleted += 1
        except OSError:
            skipped += 1

    return (
        f"Thumbnail cache cleanup complete.\n"
        f"Deleted files: {deleted}\n"
        f"Skipped locked files: {skipped}\n"
        f"Estimated freed: {format_bytes(freed)}",
        freed,
    )


def empty_recycle_bin() -> Tuple[str, int]:
    result = subprocess.run(
        [
            "powershell", "-NoProfile", "-ExecutionPolicy", "Bypass",
            "-Command", "Clear-RecycleBin -Force -ErrorAction SilentlyContinue; Write-Output 'Recycle Bin cleanup requested.'"
        ],
        capture_output=True,
        text=True,
        encoding="utf-8",
        errors="replace",
    )
    output = result.stdout or ""
    if result.stderr:
        output += "\n" + result.stderr
    return output.strip() or "Recycle Bin cleanup requested.", 0
