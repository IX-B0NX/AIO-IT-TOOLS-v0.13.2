from __future__ import annotations

import os
import subprocess
from typing import Tuple
from core.models import UpdateRow


def creationflags() -> int:
    return subprocess.CREATE_NO_WINDOW if os.name == "nt" else 0


def run_process(command: list[str], timeout: int = 1800) -> Tuple[str, int]:
    result = subprocess.run(
        command,
        capture_output=True,
        text=True,
        timeout=timeout,
        encoding="utf-8",
        errors="replace",
        creationflags=creationflags(),
    )
    output = result.stdout or ""
    if result.stderr:
        output += "\n" + result.stderr
    return output.strip(), result.returncode


def can_update_with_winget(row: UpdateRow) -> bool:
    return row.update_status == "YES" and row.item_type == "App" and bool(row.raw_id)


def update_selected_app(row: UpdateRow) -> Tuple[str, int]:
    if not can_update_with_winget(row):
        return (
            "This item cannot be updated directly yet.\n\n"
            "Direct updating currently supports YES app updates detected by winget with a package ID.",
            1,
        )

    return run_process([
        "winget", "upgrade",
        "--id", row.raw_id,
        "--exact",
        "--accept-package-agreements",
        "--accept-source-agreements",
        "--disable-interactivity",
    ])


def update_all_safe_apps() -> Tuple[str, int]:
    return run_process([
        "winget", "upgrade",
        "--all",
        "--accept-package-agreements",
        "--accept-source-agreements",
        "--disable-interactivity",
    ])
