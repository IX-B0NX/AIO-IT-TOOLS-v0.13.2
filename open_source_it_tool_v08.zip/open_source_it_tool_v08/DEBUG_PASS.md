# Debug Pass — OpenUpdate AIO PySide v0.7.3

## Checks run

- Python syntax compile on every `.py` file
- Core scanner smoke test on the local environment
- Static review of config paths, asset paths, table rendering, link handling, and scan-complete flow

## Bugs found and fixed

### 1. Details panel stayed on "Scanning"

After a scan finished, the table updated but the Details panel could still say "Scanning" until the user selected an item.

Fixed in v0.7.3:
- Details now shows a scan summary after completion.
- Double-click still opens full row details.

### 2. Details links used QTextBrowser external handling only

HTTP links usually worked, but custom Windows links such as `ms-settings:windowsupdate` could fail from the Details panel.

Fixed in v0.7.3:
- Details and Output panes now route clicked links through the app's own handler.
- `ms-settings:` and `.msc` links use `os.startfile`.
- HTTP/HTTPS links use Qt desktop services.

### 3. Portable EXE config path was not persistent enough

The config path used the project folder logic. In a one-file PyInstaller EXE, this can point at the extracted temporary bundle instead of the EXE folder.

Fixed in v0.7.3:
- Frozen EXE config is saved next to `OpenUpdateAIO.exe`.

### 4. Portable EXE asset path needed PyInstaller awareness

The included BAT toolkit needs to resolve correctly when bundled.

Fixed in v0.7.3:
- Bundled assets resolve through `sys._MEIPASS` when running as a PyInstaller EXE.

### 5. Windows Update non-Windows fallback could show misleading NO

In the local Linux test environment, Windows Update could return a red NO row instead of a warning.

Fixed in v0.7.3:
- Non-Windows Windows Update scans now return a WARNING row.
- On Windows, normal Windows Update scan behavior remains.

### 6. Winget matching was too strict

Winget update names and Registry display names do not always match exactly. That could show one app twice: one red NO inventory row and one green YES winget row.

Improved in v0.7.3:
- Added normalized/fuzzy-ish name matching to reduce duplicate YES/NO rows.

## Still needs real Windows testing

The following require your Windows machine:

- Actual winget output parsing
- Actual Windows Update COM scan
- Actual WMI driver scan
- Toolkit BAT behavior
- PyInstaller EXE build behavior
