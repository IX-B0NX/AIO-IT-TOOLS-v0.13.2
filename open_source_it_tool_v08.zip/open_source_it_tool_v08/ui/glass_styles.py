from __future__ import annotations


APP_QSS = """
QMainWindow {
    background: qlineargradient(x1:0, y1:0, x2:1, y2:1,
        stop:0 #050816, stop:0.45 #0b1220, stop:1 #101827);
}

QFrame#GlassPanel {
    background-color: rgba(20, 28, 46, 210);
    border: 1px solid rgba(125, 155, 210, 55);
    border-radius: 24px;
}

QFrame#Sidebar {
    background-color: rgba(20, 28, 46, 190);
    border: 1px solid rgba(125, 155, 210, 45);
    border-radius: 26px;
}

QLabel#Title {
    color: #f8fafc;
    font-size: 30px;
    font-weight: 850;
}

QLabel#Subtitle {
    color: #94a3b8;
    font-size: 13px;
}

QLabel#CardTitle {
    color: #94a3b8;
    font-size: 11px;
    font-weight: 750;
    letter-spacing: 1px;
}

QLabel#CardNumber {
    color: #f8fafc;
    font-size: 32px;
    font-weight: 850;
}

QLabel {
    color: #e5edf8;
}

QPushButton {
    background-color: rgba(30, 41, 59, 210);
    border: 1px solid rgba(148, 163, 184, 70);
    border-radius: 16px;
    padding: 10px 14px;
    color: #e5edf8;
    font-weight: 700;
}

QPushButton:hover {
    background-color: rgba(51, 65, 85, 230);
    border: 1px solid rgba(56, 189, 248, 150);
}

QPushButton:pressed {
    background-color: rgba(15, 23, 42, 240);
}

QPushButton#PrimaryButton {
    background-color: #0a84ff;
    color: white;
    border: 0;
}

QPushButton#DangerButton {
    background-color: rgba(239,68,68,220);
    color: white;
    border: 0;
}

QTableWidget {
    background-color: rgba(15, 23, 42, 205);
    border: 1px solid rgba(148, 163, 184, 55);
    border-radius: 18px;
    gridline-color: rgba(148,163,184,35);
    color: #e5edf8;
    selection-background-color: rgba(14, 165, 233, 90);
    selection-color: #ffffff;
    alternate-background-color: rgba(30, 41, 59, 130);
}

QTableWidget::item {
    padding: 8px 10px;
    border: 0;
}

QHeaderView::section {
    background-color: rgba(30, 41, 59, 235);
    color: #cbd5e1;
    border: 0;
    border-right: 1px solid rgba(148,163,184,45);
    border-bottom: 1px solid rgba(148,163,184,45);
    padding: 10px;
    font-weight: 850;
}

QHeaderView::section:hover {
    background-color: rgba(51, 65, 85, 240);
}

QLineEdit {
    background-color: rgba(15, 23, 42, 210);
    border: 1px solid rgba(148, 163, 184, 55);
    border-radius: 14px;
    padding: 11px 13px;
    color: #e5edf8;
    selection-background-color: #0a84ff;
}

QLineEdit::placeholder {
    color: #64748b;
}

QTextBrowser, QTextEdit {
    background-color: rgba(15, 23, 42, 205);
    border: 1px solid rgba(148, 163, 184, 55);
    border-radius: 18px;
    padding: 12px;
    color: #e5edf8;
}

QTextBrowser a {
    color: #38bdf8;
}

QTabWidget::pane {
    border: 0;
    background: transparent;
}

QTabBar::tab {
    background: rgba(30, 41, 59, 155);
    border: 1px solid rgba(148, 163, 184, 35);
    border-radius: 14px;
    padding: 10px 16px;
    margin-right: 6px;
    color: #94a3b8;
    font-weight: 750;
}

QTabBar::tab:hover {
    background: rgba(51, 65, 85, 185);
    color: #e2e8f0;
}

QTabBar::tab:selected {
    background: rgba(14, 165, 233, 80);
    color: #38bdf8;
    border: 1px solid rgba(56, 189, 248, 130);
}

QSplitter::handle {
    background-color: rgba(148, 163, 184, 45);
    border-radius: 4px;
}

QSplitter::handle:hover {
    background-color: rgba(56, 189, 248, 120);
}

QScrollBar:vertical {
    background: transparent;
    width: 12px;
    margin: 2px;
}

QScrollBar::handle:vertical {
    background: rgba(100,116,139,150);
    border-radius: 6px;
    min-height: 30px;
}

QScrollBar::handle:vertical:hover {
    background: rgba(148,163,184,190);
}

QScrollBar:horizontal {
    background: transparent;
    height: 12px;
    margin: 2px;
}

QScrollBar::handle:horizontal {
    background: rgba(100,116,139,150);
    border-radius: 6px;
    min-width: 30px;
}

QScrollBar::handle:horizontal:hover {
    background: rgba(148,163,184,190);
}
"""
