from __future__ import annotations

import os
import sys
import traceback
import webbrowser
from pathlib import Path
from typing import List

from PySide6.QtCore import Qt, QThread, Signal, QSize, QUrl
from PySide6.QtGui import QColor, QDesktopServices
from PySide6.QtWidgets import (
    QApplication, QAbstractItemView, QFrame, QGridLayout, QHBoxLayout, QHeaderView, QLabel,
    QLineEdit, QMainWindow, QMessageBox, QPushButton, QSplitter, QStackedWidget,
    QTableWidget, QTableWidgetItem, QTabWidget, QTextBrowser, QVBoxLayout,
    QWidget, QFileDialog
)

from core.models import UpdateRow, ToolAction
from core.config import Config
from core.updater import can_update_with_winget, update_selected_app, update_all_safe_apps
from core.cleaner import analyze_cleaner, clean_user_temp, clean_windows_temp, clean_thumbnail_cache, empty_recycle_bin, format_bytes
from core.scanners import scan_all
from core.reports import export_updates_csv, export_html_report
from core.toolkit_actions import TOOL_ACTIONS, run_action
from ui.glass_styles import APP_QSS


class ScanWorker(QThread):
    progress = Signal(str)
    finished_scan = Signal(list, str)

    def run(self):
        try:
            rows = scan_all(progress=lambda msg: self.progress.emit(msg))
            self.finished_scan.emit(rows, "")
        except Exception:
            self.finished_scan.emit([], traceback.format_exc())


class ToolWorker(QThread):
    progress = Signal(str)
    finished_tool = Signal(str, str)

    def __init__(self, action: ToolAction):
        super().__init__()
        self.action = action

    def run(self):
        try:
            self.progress.emit(f"Running: {self.action.name}")
            output, _opened = run_action(self.action)
            self.finished_tool.emit(self.action.name, output or "Completed.")
        except Exception:
            self.finished_tool.emit(self.action.name, traceback.format_exc())



class UpdateWorker(QThread):
    progress = Signal(str)
    finished_update = Signal(str, str)

    def __init__(self, mode: str, row: UpdateRow | None = None):
        super().__init__()
        self.mode = mode
        self.row = row

    def run(self):
        try:
            if self.mode == "selected" and self.row:
                self.progress.emit(f"Updating: {self.row.name}")
                output, code = update_selected_app(self.row)
                title = f"Update Selected finished with exit code {code}"
            else:
                self.progress.emit("Updating all safe winget apps...")
                output, code = update_all_safe_apps()
                title = f"Update All Apps finished with exit code {code}"
            self.finished_update.emit(title, output or "No output returned.")
        except Exception:
            self.finished_update.emit("Update failed", traceback.format_exc())


class CleanerWorker(QThread):
    progress = Signal(str)
    finished_cleaner = Signal(str, str)

    def __init__(self, action: str):
        super().__init__()
        self.action = action

    def run(self):
        try:
            self.progress.emit(f"Running cleaner: {self.action}")
            if self.action == "analyze":
                targets = analyze_cleaner()
                lines = ["Cleaner Analysis", "================", ""]
                total = 0
                for target in targets:
                    total += target.estimated_bytes
                    lines.append(f"{target.name}: {format_bytes(target.estimated_bytes)}")
                    lines.append(f"  Path: {target.path}")
                    lines.append(f"  Risk: {target.risk}")
                    lines.append(f"  {target.description}")
                    lines.append("")
                lines.append(f"Total estimated recoverable: {format_bytes(total)}")
                self.finished_cleaner.emit("Cleaner Analysis", "\\n".join(lines))
            elif self.action == "user_temp":
                output, _ = clean_user_temp()
                self.finished_cleaner.emit("User Temp Cleanup", output)
            elif self.action == "windows_temp":
                output, _ = clean_windows_temp()
                self.finished_cleaner.emit("Windows Temp Cleanup", output)
            elif self.action == "thumbnails":
                output, _ = clean_thumbnail_cache()
                self.finished_cleaner.emit("Thumbnail Cache Cleanup", output)
            elif self.action == "recycle_bin":
                output, _ = empty_recycle_bin()
                self.finished_cleaner.emit("Recycle Bin Cleanup", output)
            else:
                self.finished_cleaner.emit("Cleaner", "Unknown cleaner action.")
        except Exception:
            self.finished_cleaner.emit("Cleaner failed", traceback.format_exc())


def pill_item(text: str, status: str) -> QTableWidgetItem:
    item = QTableWidgetItem(text)
    item.setTextAlignment(Qt.AlignCenter)
    item.setFlags(item.flags() & ~Qt.ItemIsEditable)

    if status == "YES":
        item.setForeground(QColor("#ffffff"))
        item.setBackground(QColor("#22c55e"))
    elif status == "NO":
        item.setForeground(QColor("#ffffff"))
        item.setBackground(QColor("#ef4444"))
    elif status == "WARNING":
        item.setForeground(QColor("#ffffff"))
        item.setBackground(QColor("#f59e0b"))
    return item


class OpenUpdateAIOWindow(QMainWindow):
    def __init__(self):
        super().__init__()
        self.setWindowTitle("Open Source IT Tool")
        self.resize(1420, 880)
        self.rows: List[UpdateRow] = []
        self.filtered_rows: List[UpdateRow] = []
        self.scan_worker: ScanWorker | None = None
        self.tool_worker: ToolWorker | None = None
        self.update_worker: UpdateWorker | None = None
        self.cleaner_worker: CleanerWorker | None = None
        self.config = Config()

        self.setStyleSheet(APP_QSS)
        self.build_ui()

    def build_ui(self):
        root = QWidget()
        self.setCentralWidget(root)
        main = QVBoxLayout(root)
        main.setContentsMargins(22, 22, 22, 22)
        main.setSpacing(16)

        header = QFrame()
        header.setObjectName("GlassPanel")
        header_layout = QHBoxLayout(header)
        header_layout.setContentsMargins(22, 18, 22, 18)

        title_box = QVBoxLayout()
        title = QLabel("Open Source IT Tool")
        title.setObjectName("Title")
        title_box.addWidget(title)
        subtitle = QLabel("created by ฿0₦Ӿ")
        subtitle.setObjectName("Subtitle")
        title_box.addWidget(subtitle)
        header_layout.addLayout(title_box)
        header_layout.addStretch()

        self.scan_btn = QPushButton("Scan Everything")
        self.scan_btn.setObjectName("PrimaryButton")
        self.scan_btn.setToolTip("Scans installed apps and drivers, then marks update status as YES or NO. No updates are installed.")
        self.scan_btn.clicked.connect(self.start_scan)
        header_layout.addWidget(self.scan_btn)

        self.update_selected_btn = QPushButton("Update Selected")
        self.update_selected_btn.setToolTip("Updates the selected app directly using winget when supported. Requires confirmation.")
        self.update_selected_btn.clicked.connect(self.update_selected)
        self.update_selected_btn.setEnabled(False)
        header_layout.addWidget(self.update_selected_btn)

        self.update_all_btn = QPushButton("Update All Apps")
        self.update_all_btn.setToolTip("Runs winget upgrade --all. This can update multiple apps and requires confirmation.")
        self.update_all_btn.clicked.connect(self.update_all_apps)
        header_layout.addWidget(self.update_all_btn)

        self.wu_toggle_btn = QPushButton()
        self.wu_toggle_btn.setToolTip("Turn Windows Update scanning on/off. It is slower than app and driver inventory, but useful for AIO checks.")
        self.wu_toggle_btn.clicked.connect(self.toggle_windows_update)
        header_layout.addWidget(self.wu_toggle_btn)

        wu_open_btn = QPushButton("Open Windows Update")
        wu_open_btn.setToolTip("Open Windows Update settings directly.")
        wu_open_btn.clicked.connect(lambda: self.open_any_link("ms-settings:windowsupdate"))
        header_layout.addWidget(wu_open_btn)

        self.update_wu_button_text()

        export_html_btn = QPushButton("Export HTML")
        export_html_btn.setToolTip("Exports the current table to a glass-style browser report.")
        export_html_btn.clicked.connect(self.export_html)
        header_layout.addWidget(export_html_btn)

        export_csv_btn = QPushButton("Export CSV")
        export_csv_btn.setToolTip("Exports the current table to CSV.")
        export_csv_btn.clicked.connect(self.export_csv)
        header_layout.addWidget(export_csv_btn)

        main.addWidget(header)

        cards = QHBoxLayout()
        self.yes_card = self.make_card("YES UPDATES", "0")
        self.no_card = self.make_card("NO UPDATES", "0")
        self.warning_card = self.make_card("WARNINGS", "0")
        self.total_card = self.make_card("TOTAL ITEMS", "0")
        cards.addWidget(self.yes_card[0])
        cards.addWidget(self.no_card[0])
        cards.addWidget(self.warning_card[0])
        cards.addWidget(self.total_card[0])
        main.addLayout(cards)

        splitter = QSplitter(Qt.Horizontal)
        main.addWidget(splitter, 1)

        left = QFrame()
        left.setObjectName("GlassPanel")
        left_layout = QVBoxLayout(left)
        left_layout.setContentsMargins(16, 16, 16, 16)
        left_layout.setSpacing(12)

        self.search = QLineEdit()
        self.search.setPlaceholderText("Search apps, drivers, vendors, versions...")
        self.search.setToolTip("Filters the full inventory table.")
        self.search.textChanged.connect(self.apply_filter)
        left_layout.addWidget(self.search)

        # Main table: keep the default view clean. Extra fields like source/confidence
        # live in the Details panel so the grid does not get crushed.
        self.table = QTableWidget(0, 7)
        self.table.setHorizontalHeaderLabels([
            "Update Status", "Type", "Name", "Current Version",
            "Latest Version", "Vendor", "Risk"
        ])

        header = self.table.horizontalHeader()
        header.setSectionsMovable(True)       # drag columns left/right
        header.setSectionsClickable(True)
        header.setStretchLastSection(False)
        header.setMinimumSectionSize(90)

        for col in range(7):
            header.setSectionResizeMode(col, QHeaderView.Interactive)

        self.table.setColumnWidth(0, 128)
        self.table.setColumnWidth(1, 92)
        self.table.setColumnWidth(2, 430)
        self.table.setColumnWidth(3, 170)
        self.table.setColumnWidth(4, 170)
        self.table.setColumnWidth(5, 150)
        self.table.setColumnWidth(6, 115)

        self.table.verticalHeader().setVisible(False)
        self.table.verticalHeader().setDefaultSectionSize(46)
        self.table.setWordWrap(False)
        self.table.setAlternatingRowColors(True)
        self.table.setSelectionBehavior(QTableWidget.SelectRows)
        self.table.setSelectionMode(QAbstractItemView.SingleSelection)
        self.table.setEditTriggers(QTableWidget.NoEditTriggers)
        self.table.setHorizontalScrollMode(QAbstractItemView.ScrollPerPixel)
        self.table.setVerticalScrollMode(QAbstractItemView.ScrollPerPixel)
        self.table.doubleClicked.connect(self.open_selected_details)
        self.table.itemSelectionChanged.connect(self.update_details_from_selection)
        left_layout.addWidget(self.table, 1)

        splitter.addWidget(left)

        right = QFrame()
        right.setObjectName("GlassPanel")
        right_layout = QVBoxLayout(right)
        right_layout.setContentsMargins(16, 16, 16, 16)

        self.tabs = QTabWidget()
        self.tabs.setMovable(True)  # drag/reorder tabs
        right_layout.addWidget(self.tabs)

        self.details = QTextBrowser()
        self.details.setOpenExternalLinks(False)
        self.details.anchorClicked.connect(self.handle_details_link)
        self.details.setHtml("<h2>Details</h2><p>Double-click an item to view details here. Links will appear in blue.</p>")
        self.tabs.addTab(self.details, "Details")

        self.toolkit_panel = QWidget()
        self.build_toolkit_tab()
        self.tabs.addTab(self.toolkit_panel, "AIO Toolkit")

        self.cleaner_panel = QWidget()
        self.build_cleaner_tab()
        self.tabs.addTab(self.cleaner_panel, "Cleaner")

        self.output = QTextBrowser()
        self.output.setOpenExternalLinks(False)
        self.output.anchorClicked.connect(self.handle_details_link)
        self.output.setHtml("<h2>Tool Output</h2><p>Toolkit output will appear here.</p>")
        self.tabs.addTab(self.output, "Output")

        splitter.addWidget(right)
        splitter.setChildrenCollapsible(False)
        splitter.setHandleWidth(10)
        splitter.setStretchFactor(0, 3)
        splitter.setStretchFactor(1, 2)
        splitter.setSizes([900, 520])

        self.status = QLabel("Ready. No updates will be installed automatically.")
        self.status.setObjectName("Subtitle")
        main.addWidget(self.status)

    def make_card(self, title: str, value: str):
        frame = QFrame()
        frame.setObjectName("GlassPanel")
        layout = QVBoxLayout(frame)
        layout.setContentsMargins(18, 14, 18, 14)
        label = QLabel(title)
        label.setObjectName("CardTitle")
        number = QLabel(value)
        number.setObjectName("CardNumber")
        layout.addWidget(label)
        layout.addWidget(number)
        return frame, number

    def build_toolkit_tab(self):
        layout = QVBoxLayout(self.toolkit_panel)
        layout.setContentsMargins(0, 0, 0, 0)
        intro = QLabel("AIO Toolkit actions converted from your batch toolkit. System-changing tools ask for confirmation.")
        intro.setObjectName("Subtitle")
        layout.addWidget(intro)

        grid = QGridLayout()
        grid.setSpacing(10)
        layout.addLayout(grid)

        for idx, action in enumerate(TOOL_ACTIONS):
            btn = QPushButton(action.name)
            btn.setToolTip(f"{action.description}\nRisk: {action.risk}" + ("\nRequires admin." if action.requires_admin else ""))
            if "System-changing" in action.risk:
                btn.setObjectName("DangerButton")
            btn.clicked.connect(lambda _checked=False, a=action: self.run_tool_action(a))
            row = idx // 2
            col = idx % 2
            grid.addWidget(btn, row, col)

        layout.addStretch()

    def start_scan(self):
        self.scan_btn.setEnabled(False)
        self.status.setText("Scanning... apps, drivers, and Windows Update rows will show YES or NO update status.")
        self.rows = []
        self.filtered_rows = []
        self.table.setRowCount(0)
        self.details.setHtml("<h2>Scanning</h2><p>Please wait. This does not install anything.</p>")

        self.scan_worker = ScanWorker()
        self.scan_worker.progress.connect(self.status.setText)
        self.scan_worker.finished_scan.connect(self.scan_done)
        self.scan_worker.start()

    def scan_done(self, rows: list, error: str):
        self.scan_btn.setEnabled(True)
        if error:
            QMessageBox.critical(self, "Scan failed", error)
            self.status.setText("Scan failed.")
            return

        self.rows = rows
        self.apply_filter()
        yes = len([r for r in self.rows if r.update_status == "YES"])
        no = len([r for r in self.rows if r.update_status == "NO"])
        warnings = len([r for r in self.rows if r.update_status == "WARNING"])
        self.details.setHtml(
            f"<div style='color:#e5edf8; font-family:Segoe UI, Arial;'>"
            f"<h1 style='color:#f8fafc;'>Scan Complete</h1>"
            f"<p>Showing <b>{len(self.filtered_rows)}</b> of <b>{len(self.rows)}</b> scanned items.</p>"
            f"<p><b style='color:#22c55e;'>YES:</b> {yes} &nbsp; "
            f"<b style='color:#ef4444;'>NO:</b> {no} &nbsp; "
            f"<b style='color:#f59e0b;'>WARNINGS:</b> {warnings}</p>"
            f"<p>Double-click any row to open its full details. No updates were installed.</p>"
            f"</div>"
        )
        self.status.setText(f"Scan complete. Showing {len(self.filtered_rows)} of {len(self.rows)} items. No updates were installed.")

    def apply_filter(self):
        q = self.search.text().lower().strip() if hasattr(self, "search") else ""
        if not q:
            self.filtered_rows = list(self.rows)
        else:
            self.filtered_rows = [
                r for r in self.rows
                if q in " ".join([
                    r.update_status, r.item_type, r.name, r.current_version,
                    r.latest_version, r.vendor, r.risk, r.source, r.confidence
                ]).lower()
            ]
        self.populate_table()
        self.update_cards()

    def populate_table(self):
        self.table.setRowCount(len(self.filtered_rows))
        for row_idx, row in enumerate(self.filtered_rows):
            values = [
                row.update_status,
                row.item_type,
                row.name,
                row.current_version or "—",
                row.latest_version or ("No update detected" if row.update_status == "NO" else "—"),
                row.vendor or "—",
                row.risk or "Unknown",
            ]
            for col, value in enumerate(values):
                if col == 0:
                    item = pill_item(value, row.update_status)
                else:
                    item = QTableWidgetItem(value)
                    item.setFlags(item.flags() & ~Qt.ItemIsEditable)
                item.setToolTip(
                    f"{row.name}\n\n"
                    f"Status: {row.update_status}\n"
                    f"Current: {row.current_version or 'Unknown'}\n"
                    f"Latest: {row.latest_version or 'No update detected'}\n"
                    f"Source: {row.source or 'Unknown'}\n"
                    f"Confidence: {row.confidence or 'Unknown'}\n\n"
                    "Double-click for full details."
                )
                self.table.setItem(row_idx, col, item)

        # Keep row height readable and avoid crushed multi-line cells.
        for r in range(self.table.rowCount()):
            self.table.setRowHeight(r, 46)

    def update_cards(self):
        yes = len([r for r in self.filtered_rows if r.update_status == "YES"])
        no = len([r for r in self.filtered_rows if r.update_status == "NO"])
        warnings = len([r for r in self.filtered_rows if r.update_status == "WARNING"])
        self.yes_card[1].setText(str(yes))
        self.no_card[1].setText(str(no))
        self.warning_card[1].setText(str(warnings))
        self.total_card[1].setText(str(len(self.filtered_rows)))

    def selected_row(self) -> UpdateRow | None:
        selected = self.table.selectionModel().selectedRows()
        if not selected:
            return None
        idx = selected[0].row()
        if 0 <= idx < len(self.filtered_rows):
            return self.filtered_rows[idx]
        return None

    def update_details_from_selection(self):
        row = self.selected_row()
        if row:
            self.details.setHtml(self.detail_html(row))
            self.update_selected_btn.setEnabled(can_update_with_winget(row))
        else:
            self.update_selected_btn.setEnabled(False)

    def open_selected_details(self):
        row = self.selected_row()
        if row:
            self.details.setHtml(self.detail_html(row))
            self.tabs.setCurrentWidget(self.details)

    def detail_html(self, row: UpdateRow) -> str:
        def esc(value: str) -> str:
            import html
            return html.escape(str(value or ""))

        def link(label: str, url: str) -> str:
            if not url:
                return "<span style='color:#94a3b8'>None detected</span>"
            safe = esc(url)
            return f"<a style='color:#38bdf8; font-weight:700;' href='{safe}'>{esc(label or url)}</a><br><span style='color:#94a3b8'>{safe}</span>"

        badge_color = "#22c55e" if row.update_status == "YES" else "#ef4444" if row.update_status == "NO" else "#f59e0b"

        return f"""
        <div style="color:#e5edf8; font-family:Segoe UI, Arial;">
        <h1 style="color:#f8fafc;">{esc(row.name)}</h1>
        <p>
          <span style="background:{badge_color}; color:white; padding:6px 12px; border-radius:999px; font-weight:800;">
            Update Status: {esc(row.update_status)}
          </span>
        </p>
        <table cellspacing="0" cellpadding="6">
          <tr><td><b>Type</b></td><td>{esc(row.item_type)}</td></tr>
          <tr><td><b>Current Version</b></td><td>{esc(row.current_version or "Unknown")}</td></tr>
          <tr><td><b>Latest Version</b></td><td>{esc(row.latest_version or "No update detected")}</td></tr>
          <tr><td><b>Vendor</b></td><td>{esc(row.vendor or "Not detected")}</td></tr>
          <tr><td><b>Risk</b></td><td>{esc(row.risk)}</td></tr>
          <tr><td><b>Source</b></td><td>{esc(row.source)}</td></tr>
          <tr><td><b>Confidence</b></td><td>{esc(row.confidence)}</td></tr>
        </table>

        <h2>Details</h2>
        <pre style="white-space:pre-wrap; background:rgba(255,255,255,.55); padding:12px; border-radius:14px;">{esc(row.details)}</pre>

        <h2>Links</h2>
        <p><b>Update / Support Link</b><br>{link("Open update/support page", row.update_link or row.vendor_link)}</p>
        <p><b>Release Notes</b><br>{link("Open release notes", row.notes_link)}</p>
        <p><b>Vendor Link</b><br>{link("Open vendor support page", row.vendor_link)}</p>

        <p style="color:#94a3b8;"><b>Safety:</b> This screen is info-only. It does not install anything.</p>
        </div>
        """



    def build_cleaner_tab(self):
        layout = QVBoxLayout(self.cleaner_panel)
        layout.setContentsMargins(0, 0, 0, 0)
        intro = QLabel("CCleaner-style maintenance tools. Analyze first, then run cleanup actions with confirmation.")
        intro.setObjectName("Subtitle")
        layout.addWidget(intro)

        grid = QGridLayout()
        grid.setSpacing(10)
        layout.addLayout(grid)

        actions = [
            ("Analyze Cleaner", "analyze", "Scans temp/cache locations and estimates recoverable space. Read-only.", False),
            ("Clean User Temp", "user_temp", "Deletes files from the current user's temp folder. Locked files are skipped.", True),
            ("Clean Windows Temp", "windows_temp", "Deletes Windows temp files where permissions allow. Admin may be required.", True),
            ("Clean Thumbnail Cache", "thumbnails", "Deletes Windows thumbnail cache files where possible.", True),
            ("Empty Recycle Bin", "recycle_bin", "Empties the Recycle Bin using Windows PowerShell.", True),
        ]

        for idx, (label, action, tip, confirm) in enumerate(actions):
            btn = QPushButton(label)
            btn.setToolTip(tip)
            if confirm:
                btn.setObjectName("DangerButton")
            btn.clicked.connect(lambda _checked=False, a=action, c=confirm, l=label: self.run_cleaner_action(a, c, l))
            grid.addWidget(btn, idx // 2, idx % 2)

        layout.addStretch()

    def update_wu_button_text(self):
        enabled = self.config.get_bool("scan_windows_update")
        self.wu_toggle_btn.setText("Windows Update: ON" if enabled else "Windows Update: OFF")

    def toggle_windows_update(self):
        current = self.config.get_bool("scan_windows_update")
        self.config.set_bool("scan_windows_update", not current)
        self.config = Config()
        self.update_wu_button_text()
        self.status.setText(
            "Windows Update scanning is ON. It will be included in the next scan."
            if self.config.get_bool("scan_windows_update")
            else "Windows Update scanning is OFF. Next scan will show it as not checked."
        )

    def open_any_link(self, target: str):
        if not target:
            return
        try:
            if target.startswith("ms-settings:") or target.endswith(".msc"):
                os.startfile(target)  # type: ignore[attr-defined]
            elif target.startswith("http://") or target.startswith("https://"):
                QDesktopServices.openUrl(QUrl(target))
            elif Path(target).exists():
                QDesktopServices.openUrl(QUrl.fromLocalFile(target))
            else:
                QDesktopServices.openUrl(QUrl(target))
        except Exception as exc:
            QMessageBox.warning(self, "Open link failed", str(exc))


    def handle_details_link(self, url: QUrl):
        target = url.toString()
        self.open_any_link(target)


    def update_selected(self):
        row = self.selected_row()
        if not row:
            QMessageBox.information(self, "No selection", "Select a YES app update first.")
            return

        if not can_update_with_winget(row):
            QMessageBox.information(
                self,
                "Not directly updateable yet",
                "Direct updating currently supports YES app updates detected by winget with a package ID."
            )
            return

        answer = QMessageBox.question(
            self,
            "Confirm update",
            f"Update this app now?\n\n{row.name}\nCurrent: {row.current_version or 'Unknown'}\nLatest: {row.latest_version or 'Unknown'}\n\nThis will run winget directly from the program.",
            QMessageBox.Yes | QMessageBox.No,
        )
        if answer != QMessageBox.Yes:
            return

        self.tabs.setCurrentWidget(self.output)
        self.output.setHtml(f"<h2>Updating {row.name}</h2><p>Running winget...</p>")
        self.update_worker = UpdateWorker("selected", row)
        self.update_worker.progress.connect(self.status.setText)
        self.update_worker.finished_update.connect(self.update_done)
        self.update_worker.start()

    def update_all_apps(self):
        yes_apps = [r for r in self.rows if can_update_with_winget(r)]
        if not yes_apps:
            QMessageBox.information(self, "No safe app updates", "No winget app updates are currently available to update directly.")
            return

        answer = QMessageBox.question(
            self,
            "Confirm update all apps",
            f"This will run winget upgrade --all and may update multiple apps.\n\nDetected direct app updates: {len(yes_apps)}\n\nContinue?",
            QMessageBox.Yes | QMessageBox.No,
        )
        if answer != QMessageBox.Yes:
            return

        self.tabs.setCurrentWidget(self.output)
        self.output.setHtml("<h2>Updating all safe apps</h2><p>Running winget upgrade --all...</p>")
        self.update_worker = UpdateWorker("all")
        self.update_worker.progress.connect(self.status.setText)
        self.update_worker.finished_update.connect(self.update_done)
        self.update_worker.start()

    def update_done(self, title: str, output: str):
        import html
        self.status.setText(title)
        self.output.setHtml(
            f"<div style='color:#e5edf8; font-family:Segoe UI, Arial;'>"
            f"<h1 style='color:#f8fafc;'>{html.escape(title)}</h1>"
            f"<pre style='white-space:pre-wrap; background:rgba(15,23,42,.55); padding:12px; border-radius:14px;'>{html.escape(output)}</pre>"
            f"<p>Recommended next step: run Scan Everything again to refresh YES/NO status.</p>"
            f"</div>"
        )

    def run_cleaner_action(self, action: str, confirm: bool, label: str):
        if confirm:
            answer = QMessageBox.question(
                self,
                "Confirm cleanup",
                f"{label}\n\nThis cleanup may delete files. Locked/protected files should be skipped.\n\nContinue?",
                QMessageBox.Yes | QMessageBox.No,
            )
            if answer != QMessageBox.Yes:
                return

        self.tabs.setCurrentWidget(self.output)
        self.output.setHtml(f"<h2>{label}</h2><p>Running...</p>")
        self.cleaner_worker = CleanerWorker(action)
        self.cleaner_worker.progress.connect(self.status.setText)
        self.cleaner_worker.finished_cleaner.connect(self.cleaner_done)
        self.cleaner_worker.start()

    def cleaner_done(self, title: str, output: str):
        import html
        self.status.setText(title)
        self.output.setHtml(
            f"<div style='color:#e5edf8; font-family:Segoe UI, Arial;'>"
            f"<h1 style='color:#f8fafc;'>{html.escape(title)}</h1>"
            f"<pre style='white-space:pre-wrap; background:rgba(15,23,42,.55); padding:12px; border-radius:14px;'>{html.escape(output)}</pre>"
            f"</div>"
        )

    def run_tool_action(self, action: ToolAction):
        if action.confirm:
            answer = QMessageBox.question(
                self,
                "Confirm action",
                f"{action.name}\n\n{action.description}\n\nRisk: {action.risk}\n\nRun this tool?",
                QMessageBox.Yes | QMessageBox.No,
            )
            if answer != QMessageBox.Yes:
                return

        self.tabs.setCurrentWidget(self.output)
        self.output.setHtml(f"<h2>{action.name}</h2><p>Running...</p>")
        self.tool_worker = ToolWorker(action)
        self.tool_worker.progress.connect(self.status.setText)
        self.tool_worker.finished_tool.connect(self.tool_done)
        self.tool_worker.start()

    def tool_done(self, name: str, output: str):
        import html
        self.status.setText(f"Finished: {name}")
        self.output.setHtml(f"<h1>{html.escape(name)}</h1><pre style='white-space:pre-wrap'>{html.escape(output)}</pre>")

    def export_html(self):
        if not self.rows:
            QMessageBox.information(self, "Nothing to export", "Run a scan first.")
            return
        path, _ = QFileDialog.getSaveFileName(self, "Export HTML report", "OpenUpdateAIO_Report.html", "HTML files (*.html)")
        if not path:
            return
        export_html_report(path, self.rows)
        QDesktopServices.openUrl(QUrl.fromLocalFile(path))

    def export_csv(self):
        if not self.rows:
            QMessageBox.information(self, "Nothing to export", "Run a scan first.")
            return
        path, _ = QFileDialog.getSaveFileName(self, "Export CSV", "OpenUpdateAIO_Updates.csv", "CSV files (*.csv)")
        if not path:
            return
        export_updates_csv(path, self.rows)
        QMessageBox.information(self, "Export complete", f"Saved to:\n{path}")


def run_app():
    app = QApplication(sys.argv)
    app.setApplicationName("Open Source IT Tool")
    app.setStyle("Fusion")
    win = OpenUpdateAIOWindow()
    win.show()
    sys.exit(app.exec())
