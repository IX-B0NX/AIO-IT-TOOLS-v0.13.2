# Open Source IT Tool v0.8

This is the patched PySide6 rebuild with dark mode default and a cleaner, draggable table.

## What this version starts

- dark iOS-inspired glassmorphism UI
- full inventory table, not only available updates
- cleaner default table columns
- draggable/reorderable table columns
- resizable table columns
- movable tabs
- dark mode default
- Windows Update scanning is visible and ON by default
- Windows Update has a header toggle
- Windows Update shows a red NO row when checked and no updates are found
- Windows Update Settings button added to the header
- top header simplified to only the tool name
- green `YES` update status
- red `NO` update status
- orange `WARNING` scan status
- double-click any row for details
- blue clickable links in the details panel
- AIO Toolkit tab
- original BAT toolkit included as a fallback
- CSV and HTML export

## Install and run

Double-click:

```text
run_open_source_it_tool.bat
```

That creates a `.venv`, installs PySide6, and starts the app.

Manual run:

```bash
python -m venv .venv
.venv\Scripts\activate
pip install -r requirements.txt
python main.py
```

## Build portable EXE

Double-click:

```text
build_exe.bat
```

Then copy this to your USB:

```text
dist\OpenSourceITTool.exe
```

## Project structure

```text
openupdate_aio_pyside_v07/
├── main.py
├── requirements.txt
├── run_open_source_it_tool.bat
├── build_exe.bat
├── core/
│   ├── config.py
│   ├── models.py
│   ├── reports.py
│   ├── scanners.py
│   ├── toolkit_actions.py
│   └── vendors.py
├── ui/
│   ├── glass_styles.py
│   └── main_window.py
├── assets/
│   ├── IT_Troubleshooting_Toolkit.bat
│   └── IT_Troubleshooting_Toolkit_README.md
└── exports/
```

## Safety

The update scanner is info-only.

It does not:

- install app updates
- install driver updates
- auto-update anything
- download installers automatically

The AIO Toolkit tab includes system repair actions. Tools that may change system/network settings show a confirmation prompt first.


## v0.7.3 debug patch

This build fixes issues found during a debug pass:

- Details panel no longer stays stuck on "Scanning" after a scan completes.
- Blue links in the Details panel now use an app-level link handler.
- `ms-settings:` links and `.msc` shortcuts open more reliably.
- Portable EXE config now saves next to the EXE.
- Bundled BAT toolkit assets resolve correctly in PyInstaller.
- Windows Update returns a warning instead of a misleading NO row when not running on Windows.
- Winget matching was improved to reduce duplicate YES/NO rows for the same app.

See `DEBUG_PASS.md` for details.


## v0.8 professional updater + cleaner direction

Program name changed to:

```text
Open Source IT Tool
created by ฿0₦Ӿ
```

New professional updater features:

- Update Selected
- Update All Apps
- Uses winget for direct app updates
- Confirmation prompts before updating
- Live output in the Output tab
- Recommended rescan after update completion

New CCleaner-style maintenance features:

- Cleaner tab
- Analyze recoverable space
- Clean user temp files
- Clean Windows temp files
- Clean thumbnail cache
- Empty Recycle Bin
- Confirmation prompts before deletion actions

Safety notes:

- Driver updates are still not installed directly.
- Direct updates currently use winget app updates only.
- Cleaner actions skip locked/protected files where possible.
- System-changing actions require confirmation.
