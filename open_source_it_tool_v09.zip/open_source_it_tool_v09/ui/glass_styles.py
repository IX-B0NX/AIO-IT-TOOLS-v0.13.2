from __future__ import annotations


APP_QSS = """
QMainWindow {
    background: #D5E3E8;
}

QWidget {
    color: #1F2A2E;
    font-family: Segoe UI, Arial, sans-serif;
}

QFrame#Sidebar {
    background-color: #F6FAFB;
    border: 1px solid #B7C8CF;
    border-radius: 28px;
}

QFrame#ContentPanel {
    background-color: rgba(246, 250, 251, 235);
    border: 1px solid #B7C8CF;
    border-radius: 28px;
}

QFrame#Card, QFrame#DashboardCard {
    background-color: #F6FAFB;
    border: 1px solid #B7C8CF;
    border-radius: 22px;
}

QLabel#AppTitle {
    color: #1F2A2E;
    font-size: 25px;
    font-weight: 900;
}

QLabel#Creator {
    color: #5F6F75;
    font-size: 12px;
    font-weight: 700;
}

QLabel#AdminBadge {
    color: #2F6F7E;
    background-color: rgba(47, 111, 126, 28);
    border: 1px solid rgba(47, 111, 126, 80);
    border-radius: 999px;
    padding: 5px 9px;
    font-size: 11px;
    font-weight: 850;
}

QLabel#PageTitle {
    color: #1F2A2E;
    font-size: 27px;
    font-weight: 900;
}

QLabel#Subtitle {
    color: #5F6F75;
    font-size: 13px;
}

QLabel#CardTitle, QLabel#DashboardBadge {
    color: #6B8F9C;
    font-size: 11px;
    font-weight: 850;
    letter-spacing: 1px;
}

QLabel#CardNumber {
    color: #1F2A2E;
    font-size: 31px;
    font-weight: 900;
}

QLabel#DashboardCardTitle {
    color: #1F2A2E;
    font-size: 20px;
    font-weight: 900;
}

QLabel#DashboardText {
    color: #5F6F75;
    font-size: 13px;
}

QPushButton {
    background-color: #F6FAFB;
    border: 1px solid #B7C8CF;
    border-radius: 16px;
    padding: 10px 14px;
    color: #1F2A2E;
    font-weight: 800;
}

QPushButton:hover {
    background-color: #EAF2F5;
    border: 1px solid #6B8F9C;
}

QPushButton:pressed {
    background-color: #D5E3E8;
}

QPushButton#PrimaryButton, QPushButton#RecommendedButton {
    background-color: #2F6F7E;
    color: white;
    border: 0;
}

QPushButton#PrimaryButton:hover, QPushButton#RecommendedButton:hover {
    background-color: #244F5A;
}

QPushButton#ActionButton {
    background-color: #EAF2F5;
    color: #1F2A2E;
    border: 1px solid #D9902F;
}

QPushButton#ActionButton:hover {
    background-color: rgba(217, 144, 47, 45);
    border: 1px solid #D9902F;
}

QPushButton#NavButton {
    background-color: transparent;
    border: 0;
    border-radius: 14px;
    padding: 12px 14px;
    color: #5F6F75;
    text-align: left;
    font-weight: 850;
}

QPushButton#NavButton:hover {
    background-color: #EAF2F5;
    color: #1F2A2E;
}

QPushButton#NavButtonActive {
    background-color: #2F6F7E;
    color: white;
    border: 0;
    border-radius: 14px;
    padding: 12px 14px;
    text-align: left;
    font-weight: 900;
}

QLineEdit {
    background-color: #FFFFFF;
    border: 1px solid #B7C8CF;
    border-radius: 14px;
    padding: 11px 13px;
    color: #1F2A2E;
}

QTableWidget {
    background-color: #FFFFFF;
    border: 1px solid #B7C8CF;
    border-radius: 16px;
    gridline-color: rgba(183, 200, 207, 90);
    color: #1F2A2E;
    selection-background-color: rgba(47, 111, 126, 55);
    selection-color: #1F2A2E;
    alternate-background-color: #F6FAFB;
}

QTableWidget::item {
    padding: 8px 10px;
}

QHeaderView::section {
    background-color: #EAF2F5;
    color: #1F2A2E;
    border: 0;
    border-right: 1px solid rgba(183, 200, 207, 80);
    border-bottom: 1px solid rgba(183, 200, 207, 80);
    padding: 10px;
    font-weight: 900;
}

QTextBrowser, QTextEdit {
    background-color: #FFFFFF;
    border: 1px solid #B7C8CF;
    border-radius: 16px;
    padding: 12px;
    color: #1F2A2E;
}

QProgressBar {
    background-color: #F6FAFB;
    border: 1px solid #B7C8CF;
    border-radius: 10px;
    height: 18px;
    text-align: center;
    color: #1F2A2E;
    font-weight: 800;
}

QProgressBar::chunk {
    background-color: #2F6F7E;
    border-radius: 9px;
}

QScrollBar:vertical {
    background: transparent;
    width: 12px;
    margin: 2px;
}

QScrollBar::handle:vertical {
    background: #B7C8CF;
    border-radius: 6px;
    min-height: 30px;
}

QScrollBar:horizontal {
    background: transparent;
    height: 12px;
    margin: 2px;
}

QScrollBar::handle:horizontal {
    background: #B7C8CF;
    border-radius: 6px;
    min-width: 30px;
}
"""
