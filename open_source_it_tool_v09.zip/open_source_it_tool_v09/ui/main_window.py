from __future__ import annotations

import html
import os
import sys
import traceback
from pathlib import Path
from typing import Callable, List

from PySide6.QtCore import Qt, QThread, Signal, QUrl
from PySide6.QtGui import QColor, QDesktopServices
from PySide6.QtWidgets import (
    QApplication, QAbstractItemView, QFileDialog, QFrame, QGridLayout,
    QHBoxLayout, QHeaderView, QLabel, QLineEdit, QMainWindow, QMessageBox,
    QProgressBar, QPushButton, QStackedWidget, QTableWidget,
    QTableWidgetItem, QTextBrowser, QVBoxLayout, QWidget
)

from core.admin import is_admin
from core.cleaner import (
    analyze_cleaner, consumer_summary, technical_details, clean_browser_cache,
    clean_crash_dumps, clean_thumbnail_cache, clean_user_temp,
    clean_windows_temp, empty_recycle_bin
)
from core.config import Config
from core.driver_install import automated_driver_update
from core.driver_updates import DriverUpdateInfo, build_driver_rows
from core.health import HealthItem, scan_health
from core.logs import write_log
from core.models import ToolAction, UpdateRow
from core.reports import export_html_report, export_updates_csv
from core.scanners import scan_all
from core.toolkit_actions import TOOL_ACTIONS, run_action
from core.updater import can_update_with_winget, update_detected_apps, update_selected_app
from ui.glass_styles import APP_QSS


def status_percent(message: str, fallback: int = 10) -> int:
    text = (message or "").lower()
    if "installed programs" in text:
        return 15
    if "winget" in text:
        return 35
    if "drivers" in text or "driver" in text:
        return 60
    if "windows update" in text:
        return 82
    if "complete" in text:
        return 100
    return fallback


class ScanWorker(QThread):
    progress = Signal(str, int)
    finished_scan = Signal(list, str)

    def run(self):
        try:
            def emit(msg: str):
                self.progress.emit(msg, status_percent(msg, 12))

            self.progress.emit("Starting PC scan...", 5)
            rows = scan_all(progress=emit)
            self.progress.emit("Scan complete.", 100)
            self.finished_scan.emit(rows, "")
        except Exception:
            self.finished_scan.emit([], traceback.format_exc())


class UpdateWorker(QThread):
    progress = Signal(str, int)
    finished_update = Signal(str, str)

    def __init__(self, mode: str, rows: list[UpdateRow] | None = None, row: UpdateRow | None = None):
        super().__init__()
        self.mode = mode
        self.rows = rows or []
        self.row = row

    def run(self):
        try:
            self.progress.emit("Preparing update...", 10)
            if self.mode == "selected" and self.row:
                self.progress.emit(f"Updating {self.row.name}...", 50)
                output, code = update_selected_app(self.row)
                title = f"Update Selected finished with exit code {code}"
            else:
                self.progress.emit("Updating detected apps...", 45)
                output, code = update_detected_apps(self.rows)
                title = f"Update Apps finished with exit code {code}"
            self.progress.emit("Update workflow complete.", 100)
            self.finished_update.emit(title, output or "No output returned.")
        except Exception:
            self.finished_update.emit("Update failed", traceback.format_exc())


class CleanerWorker(QThread):
    progress = Signal(str, int)
    finished_cleaner = Signal(str, str, str)

    def __init__(self, action: str):
        super().__init__()
        self.action = action

    def run(self):
        try:
            self.progress.emit("Preparing cleaner...", 10)
            if self.action == "analyze":
                self.progress.emit("Analyzing cleanup areas...", 45)
                targets = analyze_cleaner()
                self.progress.emit("Cleaner analysis complete.", 100)
                self.finished_cleaner.emit("Cleaner Analysis", consumer_summary(targets), technical_details(targets))
            elif self.action == "recommended":
                reports = []
                for pct, label, func in [
                    (25, "Cleaning user temp...", clean_user_temp),
                    (45, "Cleaning browser cache...", clean_browser_cache),
                    (65, "Cleaning thumbnail cache...", clean_thumbnail_cache),
                    (85, "Cleaning crash dumps...", clean_crash_dumps),
                ]:
                    self.progress.emit(label, pct)
                    output, _ = func()
                    reports.append(output)
                self.progress.emit("Recommended cleanup complete.", 100)
                self.finished_cleaner.emit("Recommended Cleanup", "\n\n".join(reports), "")
            elif self.action == "user_temp":
                self.progress.emit("Cleaning user temp...", 50)
                output, _ = clean_user_temp()
                self.progress.emit("Cleanup complete.", 100)
                self.finished_cleaner.emit("User Temp Cleanup", output, "")
            elif self.action == "windows_temp":
                self.progress.emit("Cleaning Windows temp...", 50)
                output, _ = clean_windows_temp()
                self.progress.emit("Cleanup complete.", 100)
                self.finished_cleaner.emit("Windows Temp Cleanup", output, "")
            elif self.action == "browser_cache":
                self.progress.emit("Cleaning browser cache...", 50)
                output, _ = clean_browser_cache()
                self.progress.emit("Cleanup complete.", 100)
                self.finished_cleaner.emit("Browser Cache Cleanup", output, "")
            elif self.action == "thumbnails":
                self.progress.emit("Cleaning thumbnail cache...", 50)
                output, _ = clean_thumbnail_cache()
                self.progress.emit("Cleanup complete.", 100)
                self.finished_cleaner.emit("Thumbnail Cache Cleanup", output, "")
            elif self.action == "crash_dumps":
                self.progress.emit("Cleaning crash dumps...", 50)
                output, _ = clean_crash_dumps()
                self.progress.emit("Cleanup complete.", 100)
                self.finished_cleaner.emit("Crash Dump Cleanup", output, "")
            elif self.action == "recycle_bin":
                self.progress.emit("Emptying Recycle Bin...", 50)
                output, _ = empty_recycle_bin()
                self.progress.emit("Cleanup complete.", 100)
                self.finished_cleaner.emit("Recycle Bin Cleanup", output, "")
            else:
                self.finished_cleaner.emit("Cleaner", "Unknown cleaner action.", "")
        except Exception:
            self.finished_cleaner.emit("Cleaner failed", traceback.format_exc(), "")


class DriverUpdateWorker(QThread):
    progress = Signal(str, int)
    finished_drivers = Signal(list, str)

    def run(self):
        try:
            def emit(msg: str):
                pct = 30 if "installed" in msg.lower() else 70 if "windows update" in msg.lower() else 20
                self.progress.emit(msg, pct)

            self.progress.emit("Starting driver comparison...", 5)
            rows = build_driver_rows(progress=emit)
            self.progress.emit("Driver comparison complete.", 100)
            self.finished_drivers.emit(rows, "")
        except Exception:
            self.finished_drivers.emit([], traceback.format_exc())


class DriverInstallWorker(QThread):
    progress = Signal(str, int)
    finished_install = Signal(str, str)

    def run(self):
        try:
            def emit(msg: str):
                text = (msg or "").lower()
                pct = 20 if "restore" in text else 45 if "export" in text else 75 if "install" in text else 95 if "complete" in text else 15
                self.progress.emit(msg, pct)

            self.progress.emit("Starting automated driver workflow...", 5)
            output = automated_driver_update(progress=emit)
            self.progress.emit("Driver workflow complete.", 100)
            self.finished_install.emit("Automated Driver Update Complete", output)
        except Exception:
            self.finished_install.emit("Automated Driver Update Failed", traceback.format_exc())


class ToolWorker(QThread):
    progress = Signal(str, int)
    finished_tool = Signal(str, str)

    def __init__(self, action: ToolAction):
        super().__init__()
        self.action = action

    def run(self):
        try:
            self.progress.emit(f"Running {self.action.name}...", 30)
            output, _opened = run_action(self.action)
            self.progress.emit("Tool complete.", 100)
            self.finished_tool.emit(self.action.name, output or "Completed.")
        except Exception:
            self.finished_tool.emit(self.action.name, traceback.format_exc())


class HealthWorker(QThread):
    progress = Signal(str, int)
    finished_health = Signal(list, str)

    def run(self):
        try:
            self.progress.emit("Checking system health...", 35)
            items = scan_health()
            self.progress.emit("Health check complete.", 100)
            self.finished_health.emit(items, "")
        except Exception:
            self.finished_health.emit([], traceback.format_exc())


def table_item(value: str) -> QTableWidgetItem:
    item = QTableWidgetItem(str(value or ""))
    item.setFlags(item.flags() & ~Qt.ItemIsEditable)
    return item


def pill_item(value: str, status: str) -> QTableWidgetItem:
    item = table_item(value)
    item.setTextAlignment(Qt.AlignCenter)
    if status == "YES" or status == "Good":
        item.setForeground(QColor("#ffffff"))
        item.setBackground(QColor("#2E9D64"))
    elif status == "NO":
        item.setForeground(QColor("#ffffff"))
        item.setBackground(QColor("#C94C4C"))
    else:
        item.setForeground(QColor("#ffffff"))
        item.setBackground(QColor("#D9902F"))
    return item


class OpenSourceITToolWindow(QMainWindow):
    def __init__(self):
        super().__init__()
        self.setWindowTitle("Open Source IT Tool")
        self.resize(1480, 920)

        self.config = Config()
        self.rows: List[UpdateRow] = []
        self.filtered_rows: List[UpdateRow] = []
        self.driver_rows: list[DriverUpdateInfo] = []
        self.health_items: list[HealthItem] = []
        self.last_cleaner_details = ""

        self.scan_worker: ScanWorker | None = None
        self.update_worker: UpdateWorker | None = None
        self.cleaner_worker: CleanerWorker | None = None
        self.driver_worker: DriverUpdateWorker | None = None
        self.driver_install_worker: DriverInstallWorker | None = None
        self.tool_worker: ToolWorker | None = None
        self.health_worker: HealthWorker | None = None

        self.nav_buttons: dict[str, QPushButton] = {}
        self.pages: dict[str, QWidget] = {}

        self.setStyleSheet(APP_QSS)
        self.build_ui()

    # -----------------------------
    # Layout
    # -----------------------------

    def build_ui(self):
        root = QWidget()
        self.setCentralWidget(root)
        layout = QHBoxLayout(root)
        layout.setContentsMargins(18, 18, 18, 18)
        layout.setSpacing(16)

        self.sidebar = self.build_sidebar()
        layout.addWidget(self.sidebar, 0)

        content = QFrame()
        content.setObjectName("ContentPanel")
        content_layout = QVBoxLayout(content)
        content_layout.setContentsMargins(20, 18, 20, 18)
        content_layout.setSpacing(14)

        top = QHBoxLayout()
        self.page_title = QLabel("Home")
        self.page_title.setObjectName("PageTitle")
        top.addWidget(self.page_title)
        top.addStretch()

        self.quick_scan_btn = QPushButton("Scan PC")
        self.quick_scan_btn.setObjectName("PrimaryButton")
        self.quick_scan_btn.clicked.connect(self.start_scan)
        top.addWidget(self.quick_scan_btn)
        content_layout.addLayout(top)

        progress_row = QHBoxLayout()
        self.status = QLabel("Ready.")
        self.status.setObjectName("Subtitle")
        progress_row.addWidget(self.status, 2)

        self.progress_bar = QProgressBar()
        self.progress_bar.setRange(0, 100)
        self.progress_bar.setValue(0)
        progress_row.addWidget(self.progress_bar, 1)
        content_layout.addLayout(progress_row)

        self.stack = QStackedWidget()
        content_layout.addWidget(self.stack, 1)

        for name, builder in [
            ("Home", self.build_home_page),
            ("Updates", self.build_updates_page),
            ("Drivers", self.build_drivers_page),
            ("Cleaner", self.build_cleaner_page),
            ("Health", self.build_health_page),
            ("Repair", self.build_repair_page),
            ("Reports", self.build_reports_page),
            ("More Info", self.build_more_info_page),
            ("Settings", self.build_settings_page),
        ]:
            page = builder()
            self.pages[name] = page
            self.stack.addWidget(page)

        layout.addWidget(content, 1)
        self.go_to_page("Home")

    def build_sidebar(self) -> QFrame:
        sidebar = QFrame()
        sidebar.setObjectName("Sidebar")
        sidebar.setFixedWidth(260)

        layout = QVBoxLayout(sidebar)
        layout.setContentsMargins(18, 18, 18, 18)
        layout.setSpacing(10)

        title = QLabel("Open Source IT Tool")
        title.setObjectName("AppTitle")
        title.setWordWrap(True)
        layout.addWidget(title)

        creator = QLabel("created by ฿0₦Ӿ")
        creator.setObjectName("Creator")
        layout.addWidget(creator)

        badge = QLabel("Administrator Mode: ON" if is_admin() else "Administrator Mode: LIMITED")
        badge.setObjectName("AdminBadge")
        layout.addWidget(badge)

        layout.addSpacing(10)

        for name in ["Home", "Updates", "Drivers", "Cleaner", "Health", "Repair", "Reports", "More Info", "Settings"]:
            btn = QPushButton(name)
            btn.setObjectName("NavButton")
            btn.clicked.connect(lambda _checked=False, n=name: self.go_to_page(n))
            self.nav_buttons[name] = btn
            layout.addWidget(btn)

        layout.addStretch()
        return sidebar

    def go_to_page(self, name: str):
        if name not in self.pages:
            return

        self.stack.setCurrentWidget(self.pages[name])
        self.page_title.setText(name)

        for btn_name, btn in self.nav_buttons.items():
            btn.setObjectName("NavButtonActive" if btn_name == name else "NavButton")
            btn.style().unpolish(btn)
            btn.style().polish(btn)

    def set_progress(self, message: str, percent: int):
        self.status.setText(message)
        self.progress_bar.setValue(max(0, min(100, int(percent))))

    def reset_progress(self):
        self.progress_bar.setValue(0)

    def card(self, title: str, value: str, subtitle: str = "", button: str | None = None, callback: Callable | None = None) -> QFrame:
        frame = QFrame()
        frame.setObjectName("Card")
        box = QVBoxLayout(frame)
        box.setContentsMargins(18, 16, 18, 16)
        box.setSpacing(8)

        label = QLabel(title.upper())
        label.setObjectName("CardTitle")
        box.addWidget(label)

        number = QLabel(value)
        number.setObjectName("CardNumber")
        box.addWidget(number)

        if subtitle:
            sub = QLabel(subtitle)
            sub.setObjectName("Subtitle")
            sub.setWordWrap(True)
            box.addWidget(sub)

        if button and callback:
            btn = QPushButton(button)
            btn.setObjectName("RecommendedButton")
            btn.clicked.connect(callback)
            box.addWidget(btn)

        return frame

    # -----------------------------
    # Pages
    # -----------------------------

    def build_home_page(self) -> QWidget:
        page = QWidget()
        layout = QVBoxLayout(page)
        layout.setSpacing(14)

        intro = QLabel("A guided update, cleanup, driver, and repair utility for Windows.")
        intro.setObjectName("Subtitle")
        layout.addWidget(intro)

        grid = QGridLayout()
        grid.setSpacing(12)
        layout.addLayout(grid)

        self.home_updates = self.card("Updates", "Scan", "Check apps, drivers, and Windows Update.", "Scan PC", self.start_scan)
        self.home_cleaner = self.card("Cleaner", "Analyze", "Estimate safe cleanup before deleting anything.", "Analyze Cleaner", lambda: self.run_cleaner_action("analyze", False, "Analyze Cleaner"))
        self.home_drivers = self.card("Drivers", "Review", "Compare installed and available driver versions.", "Scan Drivers", self.scan_driver_updates)
        self.home_health = self.card("Health", "Check", "Review reboot, security, firewall, disks, and system status.", "Check Health", self.start_health_scan)

        grid.addWidget(self.home_updates, 0, 0)
        grid.addWidget(self.home_cleaner, 0, 1)
        grid.addWidget(self.home_drivers, 1, 0)
        grid.addWidget(self.home_health, 1, 1)

        layout.addStretch()
        return page

    def build_updates_page(self) -> QWidget:
        page = QWidget()
        layout = QVBoxLayout(page)
        layout.setSpacing(10)

        controls = QHBoxLayout()
        self.search = QLineEdit()
        self.search.setPlaceholderText("Search apps, drivers, vendors, versions...")
        self.search.textChanged.connect(self.apply_filter)
        controls.addWidget(self.search, 1)

        update_selected = QPushButton("Update Selected")
        update_selected.setObjectName("PrimaryButton")
        update_selected.clicked.connect(self.update_selected)
        controls.addWidget(update_selected)

        update_apps = QPushButton("Update Apps")
        update_apps.clicked.connect(self.update_detected_apps)
        controls.addWidget(update_apps)

        layout.addLayout(controls)

        self.update_table = QTableWidget(0, 7)
        self.update_table.setHorizontalHeaderLabels([
            "Status", "Type", "Name", "Current Version", "Available Version", "Vendor", "Risk"
        ])
        self.setup_table(self.update_table)
        self.update_table.setColumnWidth(0, 90)
        self.update_table.setColumnWidth(1, 95)
        self.update_table.setColumnWidth(2, 420)
        self.update_table.setColumnWidth(3, 160)
        self.update_table.setColumnWidth(4, 170)
        self.update_table.doubleClicked.connect(self.show_selected_update_details)
        layout.addWidget(self.update_table, 1)

        return page

    def build_drivers_page(self) -> QWidget:
        page = QWidget()
        layout = QVBoxLayout(page)
        layout.setSpacing(10)

        controls = QHBoxLayout()
        scan = QPushButton("Scan Driver Updates")
        scan.setObjectName("PrimaryButton")
        scan.clicked.connect(self.scan_driver_updates)
        controls.addWidget(scan)

        auto = QPushButton("Auto Update Drivers")
        auto.setObjectName("ActionButton")
        auto.clicked.connect(self.auto_update_drivers)
        controls.addWidget(auto)

        details = QPushButton("More Info")
        details.clicked.connect(self.open_selected_driver_details)
        controls.addWidget(details)
        controls.addStretch()
        layout.addLayout(controls)

        note = QLabel("Driver updates use Windows Update only. The automated workflow attempts a restore point, exports current drivers, installs available driver updates, saves logs, and rescans.")
        note.setObjectName("Subtitle")
        note.setWordWrap(True)
        layout.addWidget(note)

        self.driver_table = QTableWidget(0, 9)
        self.driver_table.setHorizontalHeaderLabels([
            "Status", "Device", "Installed Version", "Installed Date",
            "Available Version", "Available Date", "Manufacturer", "Source", "Match"
        ])
        self.setup_table(self.driver_table)
        self.driver_table.setColumnWidth(0, 90)
        self.driver_table.setColumnWidth(1, 360)
        self.driver_table.doubleClicked.connect(self.open_selected_driver_details)
        layout.addWidget(self.driver_table, 1)
        return page

    def build_cleaner_page(self) -> QWidget:
        page = QWidget()
        layout = QVBoxLayout(page)
        layout.setSpacing(12)

        note = QLabel("Start with Analyze Cleaner. Review-only folders are never cleaned automatically.")
        note.setObjectName("Subtitle")
        layout.addWidget(note)

        grid = QGridLayout()
        grid.setSpacing(10)
        actions = [
            ("Analyze Cleaner", "analyze", False),
            ("Clean Recommended", "recommended", True),
            ("Clean User Temp", "user_temp", True),
            ("Clean Windows Temp", "windows_temp", True),
            ("Clean Browser Cache", "browser_cache", True),
            ("Clean Thumbnail Cache", "thumbnails", True),
            ("Clean Crash Dumps", "crash_dumps", True),
            ("Empty Recycle Bin", "recycle_bin", True),
        ]

        for idx, (label, action, confirm) in enumerate(actions):
            btn = QPushButton(label)
            btn.setObjectName("ActionButton" if confirm else "PrimaryButton")
            btn.clicked.connect(lambda _checked=False, a=action, c=confirm, l=label: self.run_cleaner_action(a, c, l))
            grid.addWidget(btn, idx // 3, idx % 3)

        layout.addLayout(grid)

        self.cleaner_summary = QTextBrowser()
        self.cleaner_summary.setHtml("<h2>Cleaner Summary</h2><p>Run Analyze Cleaner to estimate safe cleanup.</p>")
        layout.addWidget(self.cleaner_summary, 1)
        return page

    def build_health_page(self) -> QWidget:
        page = QWidget()
        layout = QVBoxLayout(page)
        layout.setSpacing(10)

        controls = QHBoxLayout()
        scan = QPushButton("Check Health")
        scan.setObjectName("PrimaryButton")
        scan.clicked.connect(self.start_health_scan)
        controls.addWidget(scan)
        controls.addStretch()
        layout.addLayout(controls)

        self.health_table = QTableWidget(0, 4)
        self.health_table.setHorizontalHeaderLabels(["Status", "Area", "Summary", "Details"])
        self.setup_table(self.health_table)
        self.health_table.setColumnWidth(0, 95)
        self.health_table.setColumnWidth(1, 160)
        self.health_table.setColumnWidth(2, 420)
        layout.addWidget(self.health_table, 1)
        return page

    def build_repair_page(self) -> QWidget:
        page = QWidget()
        layout = QVBoxLayout(page)
        layout.setSpacing(12)

        note = QLabel("Advanced repair tools. Each system-changing action explains what it will do before it runs.")
        note.setObjectName("Subtitle")
        layout.addWidget(note)

        grid = QGridLayout()
        grid.setSpacing(10)
        for idx, action in enumerate(TOOL_ACTIONS):
            btn = QPushButton(action.name)
            btn.setToolTip(f"{action.description}\nRisk: {action.risk}")
            if action.confirm or action.requires_admin:
                btn.setObjectName("ActionButton")
            btn.clicked.connect(lambda _checked=False, a=action: self.run_tool_action(a))
            grid.addWidget(btn, idx // 2, idx % 2)

        layout.addLayout(grid)
        layout.addStretch()
        return page

    def build_reports_page(self) -> QWidget:
        page = QWidget()
        layout = QVBoxLayout(page)
        layout.setSpacing(12)

        grid = QGridLayout()
        grid.setSpacing(10)

        buttons = [
            ("Export Full HTML Report", self.export_html),
            ("Export CSV", self.export_csv),
            ("Open Logs Folder", self.open_logs_folder),
            ("Open Driver Backups", self.open_driver_backups),
        ]

        for idx, (label, callback) in enumerate(buttons):
            btn = QPushButton(label)
            btn.setObjectName("PrimaryButton" if idx == 0 else "ActionButton")
            btn.clicked.connect(callback)
            grid.addWidget(btn, idx // 2, idx % 2)

        layout.addLayout(grid)

        self.report_output = QTextBrowser()
        self.report_output.setHtml("<h2>Reports</h2><p>Export reports or open saved logs.</p>")
        layout.addWidget(self.report_output, 1)
        return page

    def build_more_info_page(self) -> QWidget:
        page = QWidget()
        layout = QVBoxLayout(page)
        self.more_info = QTextBrowser()
        self.more_info.setOpenExternalLinks(False)
        self.more_info.anchorClicked.connect(self.handle_details_link)
        self.more_info.setHtml("<h2>More Info</h2><p>Technical details, raw output, and logs appear here.</p>")
        layout.addWidget(self.more_info, 1)
        return page

    def build_settings_page(self) -> QWidget:
        page = QWidget()
        layout = QVBoxLayout(page)
        layout.setSpacing(12)

        admin_text = "Administrator Mode is ON." if is_admin() else "Administrator Mode is LIMITED. Restart the app and approve UAC for full functionality."
        layout.addWidget(self.card("Admin Mode", "ON" if is_admin() else "Limited", admin_text))

        self.wu_toggle_btn = QPushButton()
        self.wu_toggle_btn.clicked.connect(self.toggle_windows_update)
        self.update_wu_button_text()
        layout.addWidget(self.wu_toggle_btn)

        info = QLabel("Theme color: #D5E3E8. Technical details are hidden by default and available in More Info.")
        info.setObjectName("Subtitle")
        info.setWordWrap(True)
        layout.addWidget(info)
        layout.addStretch()
        return page

    # -----------------------------
    # Table helpers
    # -----------------------------

    def setup_table(self, table: QTableWidget):
        header = table.horizontalHeader()
        header.setSectionsMovable(True)
        header.setMinimumSectionSize(90)
        for col in range(table.columnCount()):
            header.setSectionResizeMode(col, QHeaderView.Interactive)
        table.verticalHeader().setVisible(False)
        table.setAlternatingRowColors(True)
        table.setWordWrap(False)
        table.setSelectionBehavior(QTableWidget.SelectRows)
        table.setSelectionMode(QAbstractItemView.SingleSelection)
        table.setEditTriggers(QTableWidget.NoEditTriggers)
        table.setHorizontalScrollMode(QAbstractItemView.ScrollPerPixel)
        table.setVerticalScrollMode(QAbstractItemView.ScrollPerPixel)

    # -----------------------------
    # Scan / Updates
    # -----------------------------

    def start_scan(self):
        self.go_to_page("Updates")
        self.rows = []
        self.filtered_rows = []
        self.update_table.setRowCount(0)
        self.set_progress("Starting PC scan...", 5)
        self.quick_scan_btn.setEnabled(False)

        self.scan_worker = ScanWorker()
        self.scan_worker.progress.connect(self.set_progress)
        self.scan_worker.finished_scan.connect(self.scan_done)
        self.scan_worker.start()

    def scan_done(self, rows: list, error: str):
        self.quick_scan_btn.setEnabled(True)
        if error:
            QMessageBox.critical(self, "Scan failed", error)
            self.set_progress("Scan failed.", 0)
            return

        self.rows = rows
        self.apply_filter()
        yes = len([r for r in self.rows if r.update_status == "YES"])
        no = len([r for r in self.rows if r.update_status == "NO"])
        warnings = len([r for r in self.rows if r.update_status == "WARNING"])

        self.set_progress(f"Scan complete. Updates: {yes}, OK: {no}, Warnings: {warnings}.", 100)
        self.go_to_page("Home")

    def apply_filter(self):
        q = self.search.text().lower().strip() if hasattr(self, "search") else ""
        if not q:
            self.filtered_rows = list(self.rows)
        else:
            self.filtered_rows = [
                r for r in self.rows
                if q in " ".join([
                    r.update_status, r.item_type, r.name, r.current_version,
                    r.latest_version, r.vendor, r.risk, r.source, r.confidence
                ]).lower()
            ]
        self.populate_update_table()
        self.update_home_cards()

    def populate_update_table(self):
        self.update_table.setUpdatesEnabled(False)
        self.update_table.setSortingEnabled(False)
        self.update_table.setRowCount(len(self.filtered_rows))

        for row_idx, row in enumerate(self.filtered_rows):
            values = [
                row.update_status,
                row.item_type,
                row.name,
                row.current_version or "—",
                row.latest_version or ("No update detected" if row.update_status == "NO" else "—"),
                row.vendor or "—",
                row.risk or "Unknown",
            ]
            for col, value in enumerate(values):
                item = pill_item(value, row.update_status) if col == 0 else table_item(value)
                item.setToolTip("Double-click for More Info.")
                self.update_table.setItem(row_idx, col, item)

        for r in range(self.update_table.rowCount()):
            self.update_table.setRowHeight(r, 46)

        self.update_table.setSortingEnabled(True)
        self.update_table.setUpdatesEnabled(True)

    def selected_update_row(self) -> UpdateRow | None:
        selected = self.update_table.selectionModel().selectedRows()
        if not selected:
            return None
        idx = selected[0].row()
        if 0 <= idx < len(self.filtered_rows):
            return self.filtered_rows[idx]
        return None

    def update_selected(self):
        row = self.selected_update_row()
        if not row:
            QMessageBox.information(self, "No selection", "Select a YES app update first.")
            return

        if not can_update_with_winget(row):
            QMessageBox.information(self, "Not available", "Direct updating currently supports YES app updates detected by winget.")
            return

        if not self.confirm_action(
            "Confirm App Update",
            f"Selected app: {row.name}\nCurrent: {row.current_version or 'Unknown'}\nAvailable: {row.latest_version or 'Unknown'}",
            [
                "run winget for this exact package ID",
                f"use package ID: {row.raw_id}",
                "show progress and save a log",
                "rescan after the update is complete",
            ],
            "Update App",
        ):
            return

        self.go_to_page("More Info")
        self.set_more_info("<h2>Updating App</h2><p>Running winget...</p>")
        self.set_progress("Preparing app update...", 10)

        self.update_worker = UpdateWorker("selected", row=row)
        self.update_worker.progress.connect(self.set_progress)
        self.update_worker.finished_update.connect(self.update_done)
        self.update_worker.start()

    def update_detected_apps(self):
        yes_apps = [r for r in self.rows if can_update_with_winget(r)]
        if not yes_apps:
            QMessageBox.information(self, "No app updates", "No winget app updates are currently available to update directly.")
            return

        if not self.confirm_action(
            "Confirm App Updates",
            f"Detected app updates ready to process: {len(yes_apps)}",
            [
                "update only the app rows detected in the current scan",
                "run one winget update command per detected package ID",
                "show progress and save a log",
                "rescan after updates complete",
            ],
            "Update Apps",
        ):
            return

        self.go_to_page("More Info")
        self.set_more_info("<h2>Updating Apps</h2><p>Processing detected app updates...</p>")
        self.set_progress("Preparing app updates...", 10)

        self.update_worker = UpdateWorker("detected", rows=yes_apps)
        self.update_worker.progress.connect(self.set_progress)
        self.update_worker.finished_update.connect(self.update_done)
        self.update_worker.start()

    def update_done(self, title: str, output: str):
        log_path = write_log("update", f"{title}\n\n{output}")
        self.set_progress(f"{title}. Log: {log_path.name}", 100)
        self.set_more_info(
            f"<h2>{html.escape(title)}</h2>"
            f"<pre>{html.escape(output)}</pre>"
            f"<p>Log saved: {html.escape(str(log_path))}</p>"
        )
        self.start_scan()

    def show_selected_update_details(self):
        row = self.selected_update_row()
        if not row:
            return
        self.set_more_info(self.update_detail_html(row))
        self.go_to_page("More Info")

    def update_detail_html(self, row: UpdateRow) -> str:
        def link(label: str, url: str) -> str:
            if not url:
                return "No link detected"
            safe = html.escape(url)
            return f"<a href='{safe}'>{html.escape(label)}</a><br><span>{safe}</span>"

        color = "#2E9D64" if row.update_status == "YES" else "#C94C4C" if row.update_status == "NO" else "#D9902F"
        return f"""
        <h1>{html.escape(row.name)}</h1>
        <p><span style="background:{color}; color:white; padding:6px 12px; border-radius:999px; font-weight:800;">{html.escape(row.update_status)}</span></p>
        <h2>Version</h2>
        <p><b>Current:</b> {html.escape(row.current_version or 'Unknown')}<br>
        <b>Available:</b> {html.escape(row.latest_version or 'No update detected')}</p>
        <h2>Details</h2>
        <pre>{html.escape(row.details or '')}</pre>
        <h2>Links</h2>
        <p>{link('Open update/support page', row.update_link or row.vendor_link)}</p>
        <p>{link('Release notes', row.notes_link)}</p>
        """

    # -----------------------------
    # Drivers
    # -----------------------------

    def scan_driver_updates(self):
        self.go_to_page("Drivers")
        self.driver_table.setRowCount(0)
        self.set_progress("Starting driver comparison...", 5)

        self.driver_worker = DriverUpdateWorker()
        self.driver_worker.progress.connect(self.set_progress)
        self.driver_worker.finished_drivers.connect(self.driver_scan_done)
        self.driver_worker.start()

    def driver_scan_done(self, rows: list, error: str):
        if error:
            QMessageBox.critical(self, "Driver scan failed", error)
            self.set_progress("Driver scan failed.", 0)
            return

        self.driver_rows = rows
        self.populate_driver_table()
        yes = len([r for r in rows if r.status == "YES"])
        no = len([r for r in rows if r.status == "NO"])
        warnings = len([r for r in rows if r.status == "WARNING"])
        self.set_progress(f"Driver scan complete. Updates: {yes}, OK: {no}, Warnings: {warnings}.", 100)
        self.update_home_cards()

    def populate_driver_table(self):
        self.driver_table.setUpdatesEnabled(False)
        self.driver_table.setSortingEnabled(False)
        self.driver_table.setRowCount(len(self.driver_rows))

        for row_idx, row in enumerate(self.driver_rows):
            values = [
                row.status, row.device_name, row.installed_version or "—",
                row.installed_date or "—", row.available_version or "—",
                row.available_date or "—", row.manufacturer or "—",
                row.source or "—", row.match_confidence or "—",
            ]
            for col, value in enumerate(values):
                item = pill_item(value, row.status) if col == 0 else table_item(value)
                item.setToolTip("Double-click for More Info.")
                self.driver_table.setItem(row_idx, col, item)

        for r in range(self.driver_table.rowCount()):
            self.driver_table.setRowHeight(r, 46)

        self.driver_table.setSortingEnabled(True)
        self.driver_table.setUpdatesEnabled(True)

    def selected_driver_row(self):
        selected = self.driver_table.selectionModel().selectedRows()
        if not selected:
            return None
        idx = selected[0].row()
        if 0 <= idx < len(self.driver_rows):
            return self.driver_rows[idx]
        return None

    def open_selected_driver_details(self):
        row = self.selected_driver_row()
        if not row:
            QMessageBox.information(self, "No driver selected", "Select a driver row first.")
            return
        self.set_more_info(self.driver_detail_html(row))
        self.go_to_page("More Info")

    def driver_detail_html(self, row: DriverUpdateInfo) -> str:
        def link(label: str, url: str) -> str:
            if not url:
                return "No link detected"
            safe = html.escape(url)
            return f"<a href='{safe}'>{html.escape(label)}</a><br><span>{safe}</span>"

        return f"""
        <h1>{html.escape(row.device_name)}</h1>
        <h2>Installed Driver</h2>
        <p><b>Version:</b> {html.escape(row.installed_version or 'Unknown')}<br>
        <b>Date available to this PC:</b> {html.escape(row.installed_date or 'Unknown')}<br>
        <b>INF:</b> {html.escape(row.installed_inf or 'Unknown')}<br>
        <b>Provider:</b> {html.escape(row.installed_provider or 'Unknown')}</p>
        <h2>Available Driver</h2>
        <p><b>Version:</b> {html.escape(row.available_version or 'Unknown')}<br>
        <b>Date available:</b> {html.escape(row.available_date or 'Unknown')}<br>
        <b>Title:</b> {html.escape(row.available_title or 'No update detected')}<br>
        <b>Match:</b> {html.escape(row.match_confidence or 'Unknown')}</p>
        <h2>Links</h2>
        <p>{link('Open support link', row.support_link)}</p>
        <p>{link('Open vendor fallback', row.vendor_link)}</p>
        <h2>Notes</h2>
        <pre>{html.escape(row.details or '')}</pre>
        """

    def auto_update_drivers(self):
        if not self.confirm_action(
            "Confirm Driver Update Workflow",
            "This will run the guarded driver workflow with one approval.",
            [
                "attempt to create a Windows restore point",
                "export currently installed drivers to driver_backups",
                "install only driver updates reported by Windows Update",
                "save a log and rollback notes",
                "rescan driver versions after completion",
            ],
            "Start Driver Update",
        ):
            return

        self.go_to_page("More Info")
        self.set_more_info("<h2>Automated Driver Update</h2><p>Starting workflow...</p>")
        self.set_progress("Starting automated driver workflow...", 5)

        self.driver_install_worker = DriverInstallWorker()
        self.driver_install_worker.progress.connect(self.set_progress)
        self.driver_install_worker.finished_install.connect(self.driver_install_done)
        self.driver_install_worker.start()

    def driver_install_done(self, title: str, output: str):
        log_path = write_log("driver_update", f"{title}\n\n{output}")
        self.set_more_info(
            f"<h2>{html.escape(title)}</h2>"
            f"<pre>{html.escape(output)}</pre>"
            f"<p>Log saved: {html.escape(str(log_path))}</p>"
        )
        self.set_progress(f"{title}. Log: {log_path.name}", 100)
        self.scan_driver_updates()

    # -----------------------------
    # Cleaner
    # -----------------------------

    def run_cleaner_action(self, action: str, confirm: bool, label: str):
        if confirm:
            details = {
                "recommended": [
                    "clean user temp files",
                    "clean supported browser cache",
                    "clean thumbnail cache",
                    "clean crash dumps",
                    "skip locked or protected files",
                    "save a cleanup log",
                ],
                "user_temp": ["delete current-user temporary files", "skip locked files", "save a cleanup log"],
                "windows_temp": ["delete Windows temp files where allowed", "skip protected files", "save a cleanup log"],
                "browser_cache": ["delete supported browser cache folders", "skip locked browser files", "save a cleanup log"],
                "thumbnails": ["delete Windows thumbnail cache files", "let Windows recreate thumbnails later", "save a cleanup log"],
                "crash_dumps": ["delete user-mode crash dump files", "skip protected files", "save a cleanup log"],
                "recycle_bin": ["empty the Recycle Bin", "remove files currently stored there", "save a cleanup log"],
            }.get(action, ["run selected cleanup", "save a cleanup log"])

            if not self.confirm_action(f"Confirm {label}", f"Cleanup action: {label}", details, "Run Cleanup"):
                return

        self.go_to_page("Cleaner")
        self.set_progress(f"Starting {label}...", 5)
        self.cleaner_summary.setHtml(f"<h2>{html.escape(label)}</h2><p>Running...</p>")

        self.cleaner_worker = CleanerWorker(action)
        self.cleaner_worker.progress.connect(self.set_progress)
        self.cleaner_worker.finished_cleaner.connect(self.cleaner_done)
        self.cleaner_worker.start()

    def cleaner_done(self, title: str, output: str, details: str = ""):
        log_content = output if not details else f"{output}\n\n--- TECHNICAL DETAILS ---\n\n{details}"
        log_path = write_log("cleaner", log_content)

        self.cleaner_summary.setHtml(
            f"<h2>{html.escape(title)}</h2>"
            f"<pre>{html.escape(output)}</pre>"
            f"<p>Log saved: {html.escape(str(log_path))}</p>"
        )

        if details:
            self.set_more_info(
                f"<h2>Cleaner More Info</h2>"
                f"<pre>{html.escape(details)}</pre>"
            )

        self.set_progress(f"{title} complete. Log: {log_path.name}", 100)

    # -----------------------------
    # Health
    # -----------------------------

    def start_health_scan(self):
        self.go_to_page("Health")
        self.health_table.setRowCount(0)
        self.set_progress("Checking system health...", 10)

        self.health_worker = HealthWorker()
        self.health_worker.progress.connect(self.set_progress)
        self.health_worker.finished_health.connect(self.health_done)
        self.health_worker.start()

    def health_done(self, items: list, error: str):
        if error:
            QMessageBox.critical(self, "Health check failed", error)
            self.set_progress("Health check failed.", 0)
            return
        self.health_items = items
        self.populate_health_table()
        warnings = len([i for i in items if i.status != "Good"])
        self.set_progress(f"Health check complete. Warnings: {warnings}.", 100)
        self.update_home_cards()

    def populate_health_table(self):
        self.health_table.setRowCount(len(self.health_items))
        for idx, item in enumerate(self.health_items):
            values = [item.status, item.area, item.summary, item.details]
            for col, value in enumerate(values):
                table_item_obj = pill_item(value, item.status) if col == 0 else table_item(value)
                self.health_table.setItem(idx, col, table_item_obj)
            self.health_table.setRowHeight(idx, 46)

    # -----------------------------
    # Toolkit / Reports / Settings
    # -----------------------------

    def run_tool_action(self, action: ToolAction):
        if action.confirm:
            details = [
                action.description,
                f"risk level: {action.risk}",
                "run the selected toolkit action",
                "show progress and save a toolkit log",
            ]
            if action.requires_admin:
                details.insert(1, "use Administrator permissions when elevated")
            if not self.confirm_action(f"Confirm {action.name}", f"Toolkit action: {action.name}", details, "Run Tool"):
                return

        self.go_to_page("More Info")
        self.set_more_info(f"<h2>{html.escape(action.name)}</h2><p>Running...</p>")
        self.set_progress(f"Running {action.name}...", 25)

        self.tool_worker = ToolWorker(action)
        self.tool_worker.progress.connect(self.set_progress)
        self.tool_worker.finished_tool.connect(self.tool_done)
        self.tool_worker.start()

    def tool_done(self, name: str, output: str):
        log_path = write_log("toolkit", f"{name}\n\n{output}")
        self.set_more_info(
            f"<h2>{html.escape(name)}</h2>"
            f"<pre>{html.escape(output)}</pre>"
            f"<p>Log saved: {html.escape(str(log_path))}</p>"
        )
        self.set_progress(f"Finished: {name}. Log: {log_path.name}", 100)

    def export_html(self):
        if not self.rows:
            QMessageBox.information(self, "Nothing to export", "Run a scan first.")
            return
        path, _ = QFileDialog.getSaveFileName(self, "Export HTML report", "OpenSourceITTool_Report.html", "HTML files (*.html)")
        if not path:
            return
        export_html_report(path, self.rows)
        self.report_output.setHtml(f"<h2>Report Saved</h2><p>{html.escape(path)}</p>")
        QDesktopServices.openUrl(QUrl.fromLocalFile(path))

    def export_csv(self):
        if not self.rows:
            QMessageBox.information(self, "Nothing to export", "Run a scan first.")
            return
        path, _ = QFileDialog.getSaveFileName(self, "Export CSV", "OpenSourceITTool_Updates.csv", "CSV files (*.csv)")
        if not path:
            return
        export_updates_csv(path, self.rows)
        self.report_output.setHtml(f"<h2>CSV Saved</h2><p>{html.escape(path)}</p>")

    def open_logs_folder(self):
        path = Path("logs").resolve()
        path.mkdir(exist_ok=True)
        QDesktopServices.openUrl(QUrl.fromLocalFile(str(path)))

    def open_driver_backups(self):
        path = Path("driver_backups").resolve()
        path.mkdir(exist_ok=True)
        QDesktopServices.openUrl(QUrl.fromLocalFile(str(path)))

    def update_wu_button_text(self):
        enabled = self.config.get_bool("scan_windows_update")
        self.wu_toggle_btn.setText("Windows Update scanning: ON" if enabled else "Windows Update scanning: OFF")

    def toggle_windows_update(self):
        current = self.config.get_bool("scan_windows_update")
        self.config.set_bool("scan_windows_update", not current)
        self.config = Config()
        self.update_wu_button_text()
        self.set_progress("Windows Update setting changed.", 0)

    # -----------------------------
    # Shared helpers
    # -----------------------------

    def confirm_action(self, title: str, summary: str, action_details: list[str], confirm_label: str = "Continue") -> bool:
        lines = [summary.strip(), "", "This action will:"]
        lines.extend([f"• {item}" for item in action_details])
        lines.extend(["", "Choose Continue only if this is what you want to do."])

        box = QMessageBox(self)
        box.setIcon(QMessageBox.Warning)
        box.setWindowTitle(title)
        box.setText("Review before continuing")
        box.setInformativeText("\n".join(lines))
        box.setStandardButtons(QMessageBox.Cancel)
        continue_btn = box.addButton(confirm_label, QMessageBox.AcceptRole)
        box.setDefaultButton(QMessageBox.Cancel)
        box.exec()
        return box.clickedButton() == continue_btn

    def set_more_info(self, html_text: str):
        self.more_info.setHtml(
            "<div style='font-family:Segoe UI, Arial; color:#1F2A2E;'>"
            + html_text +
            "</div>"
        )

    def handle_details_link(self, url: QUrl):
        target = url.toString()
        try:
            if target.startswith("ms-settings:") or target.endswith(".msc"):
                os.startfile(target)  # type: ignore[attr-defined]
            elif target.startswith("http://") or target.startswith("https://"):
                QDesktopServices.openUrl(QUrl(target))
            elif Path(target).exists():
                QDesktopServices.openUrl(QUrl.fromLocalFile(target))
            else:
                QDesktopServices.openUrl(QUrl(target))
        except Exception as exc:
            QMessageBox.warning(self, "Open link failed", str(exc))

    def update_home_cards(self):
        # Home cards are intentionally simple. Detailed counts stay in each page.
        if not hasattr(self, "home_updates"):
            return


def run_app():
    app = QApplication(sys.argv)
    app.setApplicationName("Open Source IT Tool")
    app.setStyle("Fusion")
    win = OpenSourceITToolWindow()
    win.show()
    sys.exit(app.exec())
