# Open Source IT Tool v0.9

created by ฿0₦Ӿ

Professional Windows update, cleanup, and IT maintenance utility.

## Main features

- Dark glass desktop interface
- Full app/driver/update inventory
- Green YES for available updates
- Red NO for no update detected
- Orange WARNING for scanner issues
- Direct app updating through winget
- Update Selected
- Update Detected Apps
- Consumer-friendly Cleaner tab
- More Info tab for technical cleanup details
- AIO Toolkit tab with repair and diagnostic actions
- Logs saved under `logs/`
- CSV and HTML report export

## Cleaner design

The Cleaner tab shows a consumer-friendly summary first.

It separates results into:

- Safe cleanup estimate
- Review-only storage
- Browser and privacy cache
- Windows cleanup
- Diagnostics cleanup
- Personal file review

The More Info tab shows:

- full paths
- risk labels
- cleanup status
- estimated size
- notes for each target

## Direct update behavior

Direct updates currently support winget app updates only.

`Update Selected` updates the selected YES app row when it has a winget package ID.

`Update Detected Apps` processes only the winget app updates detected in the current scan. It does not blindly run a full package-manager update against items that were not shown in the table.

## Run

```text
run_open_source_it_tool.bat
```

## Build portable EXE

```text
build_exe.bat
```

Output:

```text
dist\OpenSourceITTool.exe
```

## Developer notes

- Keep destructive actions behind confirmation prompts.
- Keep driver updates conservative until official vendor/OEM update flows are added.
- Keep review-only locations separate from cleanable locations.
- Avoid cleaning personal folders automatically.
- Keep logs plain text for support workflows.


## v0.8.2 admin and consumer UI pass

- Startup now requests Administrator mode on Windows.
- The packaged EXE build uses a UAC admin manifest.
- The app cannot bypass UAC; Windows still requires approval.
- Header now shows Administrator Mode status.
- Removed harsh red cleanup buttons and replaced them with warning-styled action buttons.
- Renamed some UI buttons for consumers:
  - Scan PC
  - Update Apps
  - Windows Update
  - Report
- Cleaner wording is more consumer-friendly while keeping More Info for technical details.


## v0.8.3 consumer UI and confirmation pass

- Added Home dashboard with large action cards:
  - Update Apps
  - Clean PC
  - Check Health
  - Repair Tools
- Added plain-English dashboard status after scanning.
- Added custom confirmation dialogs for updates, cleanup, and toolkit actions.
- Confirmation dialogs now explain exactly what will happen before the action runs.
- Generic question-mark prompts have been replaced with review-style confirmation text.
- Cleaner still provides a simple summary first and deeper technical detail in More Info.


## v0.8.4 refined driver update comparison

- Added a dedicated Driver Updates tab.
- Added Scan Driver Updates action.
- Shows installed driver version and installed driver date.
- Shows available driver version and available driver date when Windows Update reports one.
- Shows match confidence between installed device and available driver update.
- Shows installed INF/provider, update ID, source, and support/vendor links in Details.
- Driver installation is still disabled until rollback/restore-point handling is added.


## v0.8.5 automated driver update workflow

- Added Driver Updates tab if it was not already present in the UI build.
- Added Scan Driver Updates.
- Added Auto Update Drivers.
- Runs with one confirmation, then automates the workflow.
- Attempts to create a restore point.
- Exports current installed drivers to `driver_backups/`.
- Installs only driver updates reported by Windows Update.
- Saves a plain-text driver update log.
- Shows rollback notes after the workflow finishes.
- Automatically refreshes the Driver Updates comparison after completion.

The workflow uses official Windows Update driver updates only. It does not scrape driver websites or download unknown installers.


## v0.9 UI refactor

- Replaced dark mode with the #D5E3E8 light theme.
- Replaced top-tab clutter with left sidebar navigation.
- Added dedicated pages:
  - Home
  - Updates
  - Drivers
  - Cleaner
  - Health
  - Repair
  - Reports
  - More Info
  - Settings
- Home is now a guided dashboard instead of a raw table.
- Technical details are hidden by default and shown in More Info.
- Added progress bars with percentages for:
  - PC scans
  - app updates
  - cleaner analysis and cleanup
  - driver comparison
  - automated driver update workflow
  - health checks
  - toolkit actions
- Added Health page with pending reboot, Defender, firewall, disk, battery, TPM, and Secure Boot checks.
