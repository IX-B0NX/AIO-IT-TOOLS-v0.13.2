from __future__ import annotations

import sys
from pathlib import Path

from PySide6.QtGui import QIcon
from PySide6.QtWidgets import QApplication

from core.admin import relaunch_as_admin_if_needed
from core.config import asset_path, ensure_runtime_dirs
from core.diagnostics import install_global_exception_hook, log_event
from ui.main_window import MainWindow, validate_main_window_export


def main() -> int:
    # Runtime folders must be created after imports are loaded, not at module top
    # before the helper has been imported.
    ensure_runtime_dirs()
    install_global_exception_hook()

    # Request admin up front on Windows so elevated tools can run from the app.
    relaunch_as_admin_if_needed()

    app = QApplication(sys.argv)
    app.setApplicationName("AIO IT TOOLS")
    app.setOrganizationName("AIO IT TOOLS")

    icon_path = asset_path("AIO.ico")
    if icon_path.exists():
        app.setWindowIcon(QIcon(str(icon_path)))

    if not validate_main_window_export():
        raise RuntimeError("MainWindow export validation failed.")

    window = MainWindow()
    window.show()

    log_event("APP_START", "AIO IT TOOLS started.")
    return app.exec()


if __name__ == "__main__":
    raise SystemExit(main())
