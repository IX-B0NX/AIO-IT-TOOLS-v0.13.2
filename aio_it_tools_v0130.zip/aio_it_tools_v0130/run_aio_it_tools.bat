@echo off
setlocal
cd /d "%~dp0"

echo Starting AIO IT TOOLS from source...
echo.

python -c "import PySide6" >nul 2>&1
if errorlevel 1 (
    echo PySide6 is not installed for this Python environment.
    echo Installing requirements first...
    echo.
    python -m pip install -r requirements.txt
    if errorlevel 1 (
        echo.
        echo Failed to install requirements.
        echo Open a Command Prompt in this folder and run:
        echo python -m pip install -r requirements.txt
        echo.
        pause
        exit /b 1
    )
)

python main.py
if errorlevel 1 (
    echo.
    echo AIO IT TOOLS exited with an error.
    echo If this continues, use Reports > Export Support ZIP after a successful launch,
    echo or send the traceback shown above.
    echo.
)
pause
