from __future__ import annotations

import json
import os
import sys
from pathlib import Path
from typing import Any


APP_NAME = "AIO IT TOOLS"
APP_FOLDER_NAME = "AIOITTools"


DEFAULTS: dict[str, Any] = {
    "scan_registry_apps": True,
    "scan_winget": True,
    "scan_windows_update": True,
    "scan_apps": True,
    "scan_drivers": True,
    "show_no_updates": True,
    "vendor_links": True,
    "show_beta_warning": True,
    "winget_timeout": 45,
    "driver_timeout": 60,
    "windows_update_timeout": 60,
}

# Backward-compatible alias used by older modules/docs.
DEFAULT_CONFIG = DEFAULTS


def is_frozen() -> bool:
    return bool(getattr(sys, "frozen", False))


def executable_dir() -> Path:
    """Folder beside the compiled EXE, or project root while running source."""
    if is_frozen():
        return Path(sys.executable).resolve().parent
    return Path(__file__).resolve().parents[1]


def bundled_dir() -> Path:
    """Read-only bundled asset root for PyInstaller onefile/onedir and source mode."""
    meipass = getattr(sys, "_MEIPASS", None)
    if meipass:
        return Path(meipass)
    return Path(__file__).resolve().parents[1]


def app_data_dir() -> Path:
    """Writable per-user app data. Falls back beside EXE/source if AppData is unavailable."""
    if os.name == "nt":
        base = os.environ.get("LOCALAPPDATA") or os.environ.get("APPDATA")
        if base:
            path = Path(base) / APP_FOLDER_NAME
            path.mkdir(parents=True, exist_ok=True)
            return path

    path = executable_dir() / "runtime"
    path.mkdir(parents=True, exist_ok=True)
    return path


def app_dir() -> Path:
    """
    Writable runtime root.

    Source/dev mode: project folder, so development ZIPs remain easy to inspect.
    Frozen EXE mode: LocalAppData/AIOITTools, so consumers can receive one EXE only.
    """
    if is_frozen():
        return app_data_dir()
    return executable_dir()


def asset_path(*parts: str) -> Path:
    """Resolve bundled assets in source mode or PyInstaller _MEIPASS."""
    return bundled_dir().joinpath("assets", *parts)


def runtime_path(*parts: str) -> Path:
    path = app_dir().joinpath(*parts)
    path.parent.mkdir(parents=True, exist_ok=True)
    return path


def ensure_runtime_dirs() -> None:
    for name in ["logs", "support_zips", "driver_backups"]:
        (app_dir() / name).mkdir(parents=True, exist_ok=True)


def config_path() -> Path:
    ensure_runtime_dirs()
    return app_dir() / "settings.json"


# Backward-compatible constant for source/dev mode. In frozen mode use config_path().
CONFIG_PATH = config_path()


class Config:
    def __init__(self):
        ensure_runtime_dirs()
        self.path = config_path()
        self.data = DEFAULTS.copy()
        self.load()

    def load(self):
        if not self.path.exists():
            self.save()
            return
        try:
            loaded = json.loads(self.path.read_text(encoding="utf-8"))
            if isinstance(loaded, dict):
                self.data.update(loaded)
        except Exception:
            self.data = DEFAULTS.copy()
            self.save()

    def save(self):
        ensure_runtime_dirs()
        self.path.write_text(json.dumps(self.data, indent=2), encoding="utf-8")

    def get_bool(self, key: str) -> bool:
        return bool(self.data.get(key, DEFAULTS.get(key, False)))

    def set_bool(self, key: str, value: bool) -> None:
        self.data[key] = bool(value)
        self.save()

    def get_int(self, key: str) -> int:
        try:
            return max(10, int(self.data.get(key, DEFAULTS.get(key, 10))))
        except Exception:
            return int(DEFAULTS.get(key, 10))

    def set(self, key: str, value):
        self.data[key] = value
        self.save()



def runtime_self_test() -> str:
    """Create and remove small test files in runtime folders."""
    ensure_runtime_dirs()
    lines = [
        "Runtime Self-Test",
        "=================",
        "",
        f"Frozen EXE mode: {is_frozen()}",
        f"Executable/source folder: {executable_dir()}",
        f"Bundled asset folder: {bundled_dir()}",
        f"Writable runtime folder: {app_dir()}",
        f"Config path: {config_path()}",
        "",
    ]

    for folder_name in ["logs", "support_zips", "driver_backups"]:
        folder = app_dir() / folder_name
        lines.append(f"{folder_name}: {folder}")
        try:
            folder.mkdir(parents=True, exist_ok=True)
            test_file = folder / ".runtime_write_test"
            test_file.write_text("ok", encoding="utf-8")
            ok = test_file.read_text(encoding="utf-8") == "ok"
            test_file.unlink(missing_ok=True)
            lines.append(f"  Writable: {'YES' if ok else 'NO'}")
        except Exception as exc:
            lines.append(f"  Writable: NO — {exc}")

    icon = asset_path("AIO.ico")
    lines.extend([
        "",
        f"Bundled icon path: {icon}",
        f"Bundled icon exists: {icon.exists()}",
    ])
    return "\n".join(lines)
