from __future__ import annotations

APP_PUBLIC_VERSION = "0.13.0"
RELEASE_CHANNEL = "Gold Master Candidate"

BETA_WARNING = """
AIO IT TOOLS is ready for final validation.

This build uses safer defaults:
- Cleaner personal folders are review-only.
- Driver automation requires review and high-confidence matches.
- Advanced tools remain hidden until enabled.
- Support ZIP export is available for troubleshooting.
""".strip()

KNOWN_ISSUES = [
    {
        "area": "Windows Update policy restrictions",
        "severity": "Notice",
        "status": "External Windows/policy dependency",
        "issue": "Automatic scan can still fail on PCs where Windows Update is disabled, restricted by organization policy, or broken outside this app.",
        "workaround": "Use Check Update Health, Repair Windows Update Services, then open Windows Update manually if policy still blocks scanning.",
    },
    {
        "area": "winget / App Installer dependency",
        "severity": "Notice",
        "status": "External Microsoft App Installer dependency",
        "issue": "winget depends on Microsoft App Installer and can still be missing, blocked, or return output formats the parser cannot fully understand.",
        "workaround": "Use Open App Installer, Repair winget Sources, then scan again.",
    },
    {
        "area": "Unsigned EXE reputation",
        "severity": "Notice",
        "status": "Resolvable with code signing",
        "issue": "Unsigned builds may trigger Windows SmartScreen or antivirus reputation prompts.",
        "workaround": "Use builds from a trusted source until code signing is added.",
    },
    {
        "area": "Windows-only Wi-Fi password display",
        "severity": "Notice",
        "status": "External Windows/netsh behavior",
        "issue": "Wi-Fi password display depends on Windows netsh and may not show keys for every profile depending on policy/security state.",
        "workaround": "Run as administrator and verify output in Repair > Wi-Fi Profiles + Passwords.",
    },
]


def known_issues_text() -> str:
    lines = ["System Notes", "============", ""]
    for item in KNOWN_ISSUES:
        lines.append(f"[{item['severity']}] {item['area']} — {item.get('status', 'Tracked')}")
        lines.append(f"  Note: {item['issue']}")
        lines.append(f"  Action: {item['workaround']}")
        lines.append("")
    return "\n".join(lines).strip()
