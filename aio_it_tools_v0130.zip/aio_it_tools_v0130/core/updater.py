from __future__ import annotations

import shutil
import subprocess
from typing import Callable, Iterable, Tuple

from core.models import UpdateRow
from core.process_utils import run_hidden
from core.update_history import log_update_event


Progress = Callable[[str, int], None]


def winget_available() -> bool:
    return shutil.which("winget") is not None


def explain_update_failure(output: str, code: int) -> str:
    text = (output or "").lower()

    if code == 0:
        return "Command completed successfully."
    if code == 124 or "timed out" in text:
        return "The update command timed out. The installer or package source may be busy. Try again later."
    if "requires administrator" in text or "access is denied" in text or "0x80070005" in text:
        return "The update appears to need administrator permission or elevated installer access."
    if "no installed package found" in text or "no package found" in text or "not found" in text:
        return "winget could not match this package. The app may have been removed, renamed, or installed outside winget."
    if "source" in text and ("failed" in text or "error" in text or "not configured" in text):
        return "winget sources may be broken. Use Repair winget Sources, then scan again."
    if "network" in text or "internet" in text or "connection" in text:
        return "Network or package-source connectivity may have failed."
    if "installer failed" in text or "installation failed" in text:
        return "The app installer reported a failure. Review the installer output in More Info."
    if "cancel" in text or "aborted" in text:
        return "The update was cancelled or aborted by the installer."
    return "The update command returned a non-zero exit code. Review the output for package-specific details."


def run_process(command: list[str], timeout: int = 1800) -> Tuple[str, int]:
    if not command:
        return "No command was provided.", 1

    if command[0].lower() == "winget" and not winget_available():
        return (
            "winget was not found.\n\n"
            "Install or repair App Installer from Microsoft Store, then scan again.",
            1,
        )

    try:
        result = run_hidden(
            command,
            shell=False,
            timeout=timeout,
        )
    except subprocess.TimeoutExpired:
        return f"Command timed out after {timeout} seconds:\n{' '.join(command)}", 124
    except FileNotFoundError:
        return f"Command not found: {command[0]}", 1
    except Exception as exc:
        return f"Command failed before launch:\n{exc}", 1

    output = result.stdout or ""
    if result.stderr:
        output += "\n" + result.stderr
    return output.strip(), int(result.returncode)


def can_update_with_winget(row: UpdateRow) -> bool:
    return row.update_status == "YES" and row.item_type == "App" and bool(row.raw_id)


def update_command_for_row(row: UpdateRow) -> list[str]:
    return [
        "winget",
        "upgrade",
        "--id", row.raw_id,
        "--exact",
        "--accept-package-agreements",
        "--accept-source-agreements",
        "--disable-interactivity",
    ]


def update_selected_app(row: UpdateRow, progress: Progress | None = None) -> Tuple[str, int]:
    if not can_update_with_winget(row):
        message = (
            "This item cannot be updated directly yet.\n\n"
            "Direct updating currently supports YES app updates detected by winget with a package ID."
        )
        log_update_event("selected", row.name, row.raw_id, row.current_version, row.latest_version, "blocked", 1, message, message)
        return message, 1

    if progress:
        progress(f"Updating {row.name}...", 40)

    output, code = run_process(update_command_for_row(row))
    explanation = explain_update_failure(output, code)
    status = "success" if code == 0 else "failed"

    log_update_event(
        "selected",
        row.name,
        row.raw_id,
        row.current_version,
        row.latest_version,
        status,
        code,
        explanation,
        output,
    )

    final = [
        f"App: {row.name}",
        f"Package ID: {row.raw_id}",
        f"Current: {row.current_version or 'Unknown'}",
        f"Available: {row.latest_version or 'Unknown'}",
        "",
        output or "No output returned.",
        "",
        f"Exit code: {code}",
        f"Explanation: {explanation}",
    ]
    return "\n".join(final).strip(), code


def update_detected_apps(rows: Iterable[UpdateRow], progress: Progress | None = None) -> Tuple[str, int]:
    updateable = [row for row in rows if can_update_with_winget(row)]

    if not updateable:
        return "No detected winget app updates are available to process.", 1

    final_lines: list[str] = []
    highest_code = 0

    for index, row in enumerate(updateable, start=1):
        pct = 10 + int((index - 1) / max(1, len(updateable)) * 80)
        if progress:
            progress(f"Updating {row.name} ({index}/{len(updateable)})...", pct)

        final_lines.append("=" * 80)
        final_lines.append(f"[{index}/{len(updateable)}] {row.name}")
        final_lines.append(f"Package ID: {row.raw_id}")
        final_lines.append(f"Current: {row.current_version or 'Unknown'}")
        final_lines.append(f"Latest: {row.latest_version or 'Unknown'}")
        final_lines.append("-" * 80)

        output, code = run_process(update_command_for_row(row))
        explanation = explain_update_failure(output, code)
        highest_code = max(highest_code, code)

        log_update_event(
            "detected",
            row.name,
            row.raw_id,
            row.current_version,
            row.latest_version,
            "success" if code == 0 else "failed",
            code,
            explanation,
            output,
        )

        final_lines.append(output or "No output returned.")
        final_lines.append(f"Exit code: {code}")
        final_lines.append(f"Explanation: {explanation}")
        final_lines.append("")

    if progress:
        progress("App update workflow complete.", 100)

    return "\n".join(final_lines).strip(), highest_code
