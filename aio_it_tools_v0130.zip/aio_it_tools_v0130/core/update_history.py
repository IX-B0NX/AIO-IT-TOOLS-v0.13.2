from __future__ import annotations

import json
from datetime import datetime
from pathlib import Path
from typing import Any

from core.config import app_dir


def history_path() -> Path:
    path = app_dir() / "logs"
    path.mkdir(parents=True, exist_ok=True)
    return path / "update_history.jsonl"


def log_update_event(
    action: str,
    name: str,
    package_id: str = "",
    current: str = "",
    latest: str = "",
    status: str = "",
    exit_code: int | None = None,
    explanation: str = "",
    output: str = "",
) -> None:
    entry: dict[str, Any] = {
        "timestamp": datetime.now().isoformat(timespec="seconds"),
        "action": action,
        "name": name,
        "package_id": package_id,
        "current": current,
        "latest": latest,
        "status": status,
        "exit_code": exit_code,
        "explanation": explanation,
        "output_excerpt": (output or "")[:4000],
    }
    with history_path().open("a", encoding="utf-8", errors="replace") as f:
        f.write(json.dumps(entry, ensure_ascii=False, default=str) + "\n")


def read_update_history(limit: int = 50) -> list[dict[str, Any]]:
    path = history_path()
    if not path.exists():
        return []

    rows: list[dict[str, Any]] = []
    for line in path.read_text(encoding="utf-8", errors="replace").splitlines():
        line = line.strip()
        if not line:
            continue
        try:
            rows.append(json.loads(line))
        except json.JSONDecodeError:
            continue
    return rows[-limit:]


def history_as_text(limit: int = 50) -> str:
    rows = read_update_history(limit)
    if not rows:
        return "No app update history has been recorded yet."

    lines = [
        "App Update History",
        "==================",
        "",
    ]
    for item in reversed(rows):
        lines.append(f"{item.get('timestamp', '')} | {item.get('status', '')} | {item.get('name', '')}")
        if item.get("package_id"):
            lines.append(f"  Package ID: {item.get('package_id')}")
        if item.get("current") or item.get("latest"):
            lines.append(f"  Version: {item.get('current') or 'Unknown'} -> {item.get('latest') or 'Unknown'}")
        if item.get("exit_code") is not None:
            lines.append(f"  Exit code: {item.get('exit_code')}")
        if item.get("explanation"):
            lines.append(f"  Explanation: {item.get('explanation')}")
        lines.append("")
    return "\n".join(lines).strip()
