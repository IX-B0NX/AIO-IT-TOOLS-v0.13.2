from __future__ import annotations

import csv
import html
from datetime import datetime
from pathlib import Path
from typing import Iterable, List

from core.models import UpdateRow


def export_updates_csv(path: str | Path, rows: Iterable[UpdateRow]) -> None:
    fields = list(UpdateRow(item_type="", name="").as_dict().keys())
    with open(path, "w", newline="", encoding="utf-8") as f:
        writer = csv.DictWriter(f, fieldnames=fields)
        writer.writeheader()
        for row in rows:
            writer.writerow(row.as_dict())


def export_html_report(path: str | Path, rows: List[UpdateRow]) -> None:
    def esc(value: str) -> str:
        return html.escape(str(value or ""))

    def link(url: str) -> str:
        if not url:
            return ""
        safe = esc(url)
        return f'<a href="{safe}">{safe}</a>'

    yes = len([r for r in rows if r.update_status == "YES"])
    no = len([r for r in rows if r.update_status == "NO"])
    warnings = len([r for r in rows if r.update_status == "WARNING"])

    body_rows = []
    for row in rows:
        cls = row.update_status.lower()
        body_rows.append(
            "<tr>"
            f'<td><span class="badge {cls}">{esc(row.update_status)}</span></td>'
            f"<td>{esc(row.item_type)}</td>"
            f"<td>{esc(row.name)}</td>"
            f"<td>{esc(row.current_version)}</td>"
            f"<td>{esc(row.latest_version)}</td>"
            f"<td>{esc(row.vendor)}</td>"
            f"<td>{esc(row.risk)}</td>"
            f"<td>{esc(row.confidence)}</td>"
            f"<td>{link(row.update_link or row.vendor_link)}</td>"
            "</tr>"
        )

    doc = f"""<!doctype html>
<html>
<head>
<meta charset="utf-8">
<title>AIO IT TOOLS Report</title>
<style>
body {{ font-family: Segoe UI, Arial, sans-serif; background: linear-gradient(135deg,#e8f0ff,#f8fbff); margin: 24px; color: #172033; }}
.card {{ background: rgba(255,255,255,.72); border: 1px solid rgba(255,255,255,.8); border-radius: 18px; padding: 18px; margin: 16px 0; box-shadow: 0 18px 45px rgba(31,38,135,.16); }}
table {{ width: 100%; border-collapse: collapse; background: rgba(255,255,255,.78); border-radius: 16px; overflow: hidden; }}
th,td {{ padding: 10px; border-bottom: 1px solid rgba(30,41,59,.08); text-align: left; vertical-align: top; font-size: 13px; }}
th {{ color: #475569; }}
.badge {{ display:inline-block; min-width: 56px; text-align:center; border-radius: 999px; padding: 4px 10px; color:white; font-weight:700; }}
.yes {{ background:#22c55e; }}
.no {{ background:#ef4444; }}
.warning {{ background:#f59e0b; }}
a {{ color:#0a84ff; font-weight:600; }}
</style>
</head>
<body>
<h1>AIO IT TOOLS Report</h1>
<p>Generated {esc(datetime.now().strftime("%Y-%m-%d %H:%M:%S"))}. Info-only. No updates were installed.</p>
<div class="card">
<b>Summary</b><br>
YES updates: {yes}<br>
NO updates: {no}<br>
Warnings: {warnings}<br>
Total rows: {len(rows)}
</div>
<div class="card">
<table>
<thead><tr><th>Status</th><th>Type</th><th>Name</th><th>Current</th><th>Latest</th><th>Vendor</th><th>Risk</th><th>Confidence</th><th>Link</th></tr></thead>
<tbody>{''.join(body_rows)}</tbody>
</table>
</div>
</body>
</html>"""
    Path(path).write_text(doc, encoding="utf-8")
