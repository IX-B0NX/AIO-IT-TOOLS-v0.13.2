from __future__ import annotations

import os
import platform
import subprocess
import sys
from pathlib import Path
from typing import List, Tuple

from core.models import ToolAction
from core.process_utils import run_hidden


def app_root() -> Path:
    # In a PyInstaller build, bundled assets live under sys._MEIPASS.
    if getattr(sys, "frozen", False) and hasattr(sys, "_MEIPASS"):
        return Path(sys._MEIPASS)
    return Path(__file__).resolve().parents[1]


def toolkit_bat_path() -> Path:
    return app_root() / "assets" / "IT_Troubleshooting_Toolkit.bat"


TOOL_ACTIONS: List[ToolAction] = [
    ToolAction(
        name="Original BAT Toolkit Info",
        category="Original Toolkit",
        description="The old interactive BAT menu is not launched inside the app because it can open a console and hang. Use the converted Repair tools below.",
        command='cmd /c echo Original BAT menu disabled in app. Use the converted Repair tools instead.',
        risk="Read-only",
        requires_admin=False,
        confirm=False,
    ),
    ToolAction(
        name="System Quick-Look",
        category="Diagnostics",
        description="Shows IP configuration, adapter information, boot time, and system summary.",
        command='cmd /c "hostname & echo. & ipconfig & echo. & systeminfo | findstr /B /C:\\"OS Name\\" /C:\\"OS Version\\" /C:\\"System Boot Time\\""',
        risk="Read-only",
    ),
    ToolAction(
        name="Flush DNS",
        category="Network",
        description="Clears the local DNS resolver cache. Useful when websites resolve incorrectly.",
        command="ipconfig /flushdns",
        risk="Safe repair",
        confirm=True,
    ),
    ToolAction(
        name="Network Refresher",
        category="Network",
        description="Releases/renews IP, flushes DNS, and resets Winsock. A reboot may be needed.",
        command='cmd /c "ipconfig /release & ipconfig /renew & ipconfig /flushdns & netsh winsock reset"',
        risk="System-changing",
        requires_admin=True,
        confirm=True,
    ),
    ToolAction(
        name="SFC Scan",
        category="Repair",
        description="Runs System File Checker to verify and repair protected Windows files.",
        command="sfc /scannow",
        risk="Safe repair",
        requires_admin=True,
        confirm=True,
    ),
    ToolAction(
        name="DISM RestoreHealth",
        category="Repair",
        description="Repairs the Windows component store. Often used before or after SFC.",
        command="DISM /Online /Cleanup-Image /RestoreHealth",
        risk="Safe repair",
        requires_admin=True,
        confirm=True,
    ),
    ToolAction(
        name="Drive SMART Status",
        category="Diagnostics",
        description="Reads physical disk health status through PowerShell.",
        command='powershell -NoProfile -Command "Get-PhysicalDisk | Select FriendlyName,HealthStatus,OperationalStatus,Size | Format-Table -AutoSize"',
        risk="Read-only",
    ),
    ToolAction(
        name="Battery Report",
        category="Reports",
        description="Generates a Windows battery report HTML file.",
        command='cmd /c "powercfg /batteryreport /output %USERPROFILE%\\Desktop\\battery-report.html"',
        risk="Read-only report",
    ),
    ToolAction(
        name="Explorer Refresh",
        category="Repair",
        description="Restarts Windows Explorer to fix taskbar or desktop UI hangs.",
        command='cmd /c "taskkill /f /im explorer.exe & start explorer.exe"',
        risk="Safe repair",
        confirm=True,
    ),
    ToolAction(
        name="Windows Update Settings",
        category="Shortcuts",
        description="Opens Windows Update settings.",
        command="ms-settings:windowsupdate",
        risk="Shortcut",
    ),
    ToolAction(
        name="Device Manager",
        category="Shortcuts",
        description="Opens Device Manager.",
        command="devmgmt.msc",
        risk="Shortcut",
    ),
    ToolAction(
        name="Wi-Fi Profiles + Passwords",
        category="Diagnostics",
        description="Lists saved Wi-Fi profiles and reveals saved passwords when running as administrator.",
        command="netsh wlan show profiles",
        risk="Read-only",
    ),
]


def _creationflags() -> int:
    return subprocess.CREATE_NO_WINDOW if os.name == "nt" else 0


def _timeout_for(action: ToolAction, default: int = 120) -> int:
    name = (action.name or "").lower()
    if "sfc" in name or "dism" in name:
        return 3600
    if "original bat" in name:
        return 3600
    if "network" in name:
        return 420
    return default


def run_action(action: ToolAction, timeout: int = 120) -> Tuple[str, bool]:
    """Return output, opened_external.

    Keep repair actions stable. Command failures are returned as readable text
    instead of escaping into the UI thread.
    """
    try:
        action_name = (action.name or "").lower()
        if "wi-fi profiles" in action_name or "wifi profiles" in action_name:
            output, _code = show_wifi_profiles_with_passwords()
            return output, False

        if action.command.startswith("ms-settings:") or action.command.endswith(".msc"):
            if hasattr(os, "startfile"):
                os.startfile(action.command)  # type: ignore[attr-defined]
                return f"Opened {action.command}", True
            return f"Shortcut is Windows-only: {action.command}", False

        result = run_hidden(
            action.command,
            shell=True,
            timeout=_timeout_for(action, timeout),
        )
        output = result.stdout or ""
        if result.stderr:
            output += "\n" + result.stderr
        output = output.strip() or "Command completed with no output."
        return output + f"\n\nExit code: {result.returncode}", False

    except subprocess.TimeoutExpired:
        return f"Timed out while running: {action.name}", False
    except Exception as exc:
        return f"Could not run {action.name}.\n\n{exc}", False



def show_wifi_profiles_with_passwords() -> tuple[str, int]:
    """Show saved Wi-Fi profiles and passwords on the local PC.

    This uses Windows netsh. It is intended for local repair/recovery only and
    runs inside the app output/log path.
    """
    from core.admin import is_admin
    from core.process_utils import run_hidden

    if platform.system().lower() != "windows":
        return "Wi-Fi password display requires Windows netsh.", 1

    if not is_admin():
        return (
            "Administrator mode is required to reveal saved Wi-Fi passwords.\n"
            "Restart AIO IT TOOLS as administrator, then run this repair tool again.",
            1,
        )

    try:
        profiles_result = run_hidden(["netsh", "wlan", "show", "profiles"], timeout=60)
    except Exception as exc:
        return f"Could not read Wi-Fi profiles: {exc}", 1

    output = (profiles_result.stdout or "") + ("\n" + profiles_result.stderr if profiles_result.stderr else "")
    profile_names: list[str] = []

    for line in output.splitlines():
        if "All User Profile" in line and ":" in line:
            name = line.split(":", 1)[1].strip()
            if name:
                profile_names.append(name)

    if not profile_names:
        return output.strip() or "No saved Wi-Fi profiles and passwords were found.", int(profiles_result.returncode)

    lines = [
        "Saved Wi-Fi Profiles + Passwords",
        "===================================",
        "",
        "Passwords are shown only because the app is running with administrator rights.",
        "",
    ]

    for name in profile_names:
        lines.append(f"Profile: {name}")
        lines.append("-" * (9 + len(name)))
        try:
            detail_result = run_hidden(["netsh", "wlan", "show", "profile", f"name={name}", "key=clear"], timeout=60)
            detail = (detail_result.stdout or "") + ("\n" + detail_result.stderr if detail_result.stderr else "")
            wanted = []
            for detail_line in detail.splitlines():
                stripped = detail_line.strip()
                if (
                    stripped.startswith("SSID name")
                    or stripped.startswith("Authentication")
                    or stripped.startswith("Cipher")
                    or stripped.startswith("Security key")
                    or stripped.startswith("Key Content")
                ):
                    wanted.append(stripped)
            if wanted:
                lines.extend(wanted)
                if not any("Key Content" in item for item in wanted):
                    lines.append("Key Content: not returned by Windows for this profile.")
            else:
                lines.append(detail.strip() or "No details returned.")
        except Exception as exc:
            lines.append(f"Could not read this profile: {exc}")
        lines.append("")

    return "\n".join(lines).strip(), 0
