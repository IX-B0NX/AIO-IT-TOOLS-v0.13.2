from __future__ import annotations

import os
import tempfile
import time
from dataclasses import dataclass, field
from pathlib import Path
from typing import Iterable, List, Tuple

from core.process_utils import run_hidden


@dataclass
class CleanerTarget:
    category: str
    name: str
    path: str
    estimated_bytes: int = 0
    risk: str = "Safe"
    action: str = "Review"
    description: str = ""
    cleanup_key: str = ""
    safe_to_clean: bool = False
    personal_file_area: bool = False


@dataclass
class CleanupStats:
    root: str
    deleted_files: int = 0
    deleted_dirs: int = 0
    skipped_items: int = 0
    freed_bytes: int = 0
    deleted_examples: list[str] = field(default_factory=list)
    skipped_examples: list[str] = field(default_factory=list)

    def remember_deleted(self, path: Path):
        if len(self.deleted_examples) < 40:
            self.deleted_examples.append(str(path))

    def remember_skipped(self, path: Path, reason: str):
        self.skipped_items += 1
        if len(self.skipped_examples) < 40:
            self.skipped_examples.append(f"{path} — {reason}")

    def report(self, title: str) -> str:
        lines = [
            title,
            "=" * len(title),
            "",
            f"Root: {self.root}",
            f"Deleted files: {self.deleted_files}",
            f"Deleted folders: {self.deleted_dirs}",
            f"Skipped locked/protected items: {self.skipped_items}",
            f"Estimated freed: {format_bytes(self.freed_bytes)}",
            "",
        ]

        if self.deleted_examples:
            lines.append("Deleted examples:")
            lines.extend(f"- {item}" for item in self.deleted_examples)
            lines.append("")

        if self.skipped_examples:
            lines.append("Skipped examples:")
            lines.extend(f"- {item}" for item in self.skipped_examples)
            lines.append("")

        lines.append("Note: locked files, protected files, and files recreated by Windows/apps can remain after cleanup.")
        return "\n".join(lines).strip()


SAFE_RECOMMENDED_KEYS = {"user_temp", "browser_cache", "thumbnails", "crash_dumps"}
ADVANCED_KEYS = {"windows_temp", "recycle_bin"}
PERSONAL_FOLDER_NAMES = {"Downloads", "Desktop", "Documents", "Pictures", "Videos", "Music"}


def _folder_size(path: Path, max_items: int = 6000, max_seconds: float = 2.5) -> int:
    """Estimate folder size with hard caps so Cleaner analysis cannot hang."""
    total = 0
    count = 0
    start = time.monotonic()

    try:
        if not path or str(path) in {"", "."} or not path.exists() or not path.is_dir():
            return 0
    except OSError:
        return 0

    stack = [path]
    while stack and count < max_items:
        if time.monotonic() - start > max_seconds:
            return total

        current = stack.pop()
        try:
            with os.scandir(current) as entries:
                for entry in entries:
                    try:
                        if entry.is_dir(follow_symlinks=False):
                            name = entry.name.lower()
                            if name.startswith("$") or name in {"system volume information", "$recycle.bin"}:
                                continue
                            stack.append(Path(entry.path))
                        elif entry.is_file(follow_symlinks=False):
                            total += entry.stat(follow_symlinks=False).st_size
                            count += 1
                            if count >= max_items:
                                return total
                    except OSError:
                        continue
        except OSError:
            continue

    return total


def format_bytes(num: int) -> str:
    value = float(max(0, num))
    for unit in ["B", "KB", "MB", "GB", "TB"]:
        if value < 1024:
            return f"{value:.1f} {unit}"
        value /= 1024
    return f"{value:.1f} PB"


def _env_path(var: str, *parts: str) -> Path:
    base = os.environ.get(var, "")
    if not base:
        return Path("__missing_env__") / var
    return Path(base).joinpath(*parts)


def _is_missing_path(path: Path) -> bool:
    return "__missing_env__" in path.parts


def _user_personal_roots() -> list[Path]:
    user = os.environ.get("USERPROFILE", "")
    if not user:
        return []
    base = Path(user)
    return [base / name for name in PERSONAL_FOLDER_NAMES]


def is_personal_file_area(path: str | Path) -> bool:
    try:
        resolved = Path(path).resolve()
    except Exception:
        resolved = Path(path)

    for root in _user_personal_roots():
        try:
            root_resolved = root.resolve()
            if resolved == root_resolved or root_resolved in resolved.parents:
                return True
        except Exception:
            continue

    return False


def _existing_targets(targets: Iterable[CleanerTarget]) -> List[CleanerTarget]:
    return list(targets)


def browser_cache_targets() -> List[CleanerTarget]:
    local = os.environ.get("LOCALAPPDATA", "")
    roaming = os.environ.get("APPDATA", "")
    targets: List[CleanerTarget] = []
    candidates = []

    if local:
        local_path = Path(local)
        candidates.extend([
            ("Google Chrome Cache", local_path / "Google" / "Chrome" / "User Data" / "Default" / "Cache" / "Cache_Data"),
            ("Microsoft Edge Cache", local_path / "Microsoft" / "Edge" / "User Data" / "Default" / "Cache" / "Cache_Data"),
            ("Brave Cache", local_path / "BraveSoftware" / "Brave-Browser" / "User Data" / "Default" / "Cache" / "Cache_Data"),
        ])

    if roaming:
        roaming_path = Path(roaming)
        candidates.append(("Opera Cache", roaming_path / "Opera Software" / "Opera Stable" / "Cache" / "Cache_Data"))
        firefox_profiles = roaming_path / "Mozilla" / "Firefox" / "Profiles"
        if firefox_profiles.exists():
            for profile in firefox_profiles.iterdir():
                if profile.is_dir():
                    candidates.append((f"Firefox Cache ({profile.name})", profile / "cache2"))

    for name, path in candidates:
        targets.append(CleanerTarget(
            category="Browser & Privacy",
            name=name,
            path=str(path),
            estimated_bytes=_folder_size(path),
            risk="Safe",
            action="Cleanable",
            description="Browser cache files. Open browsers may lock some files.",
            cleanup_key="browser_cache",
            safe_to_clean=True,
        ))

    return targets


def analyze_cleaner() -> List[CleanerTarget]:
    user_temp = Path(tempfile.gettempdir())
    windows_root = Path(os.environ.get("SystemRoot", r"C:\Windows"))

    downloads = _env_path("USERPROFILE", "Downloads")
    desktop = _env_path("USERPROFILE", "Desktop")
    documents = _env_path("USERPROFILE", "Documents")

    targets: List[CleanerTarget] = [
        CleanerTarget(
            "Windows Cleanup",
            "User Temp Files",
            str(user_temp),
            _folder_size(user_temp),
            "Safe",
            "Cleanable",
            "Temporary files created by apps and installers. Locked files are skipped.",
            "user_temp",
            True,
        ),
        CleanerTarget(
            "Windows Cleanup",
            "Windows Temp Files",
            str(windows_root / "Temp"),
            _folder_size(windows_root / "Temp"),
            "Admin",
            "Advanced Cleanable",
            "System temp files. Admin rights may be required. This is not part of Clean Recommended.",
            "windows_temp",
            False,
        ),
        CleanerTarget(
            "Windows Cleanup",
            "Windows Update Download Cache",
            str(windows_root / "SoftwareDistribution" / "Download"),
            _folder_size(windows_root / "SoftwareDistribution" / "Download"),
            "Admin",
            "Review Only",
            "Downloaded update cache. Cleanup should stop update services first, so this is review-only.",
            "",
            False,
        ),
        CleanerTarget(
            "Windows Cleanup",
            "Thumbnail Cache",
            str(_env_path("LOCALAPPDATA", "Microsoft", "Windows", "Explorer")),
            _folder_size(_env_path("LOCALAPPDATA", "Microsoft", "Windows", "Explorer")),
            "Safe",
            "Cleanable",
            "Windows thumbnail databases. Explorer may recreate them later.",
            "thumbnails",
            True,
        ),
        CleanerTarget(
            "Diagnostics Cleanup",
            "User Crash Dumps",
            str(_env_path("LOCALAPPDATA", "CrashDumps")),
            _folder_size(_env_path("LOCALAPPDATA", "CrashDumps")),
            "Safe",
            "Cleanable",
            "Crash dump files created when applications fail.",
            "crash_dumps",
            True,
        ),
        CleanerTarget(
            "Downloads Review",
            "Downloads Folder",
            str(downloads),
            _folder_size(downloads, max_items=3500, max_seconds=1.8),
            "Personal",
            "Review Only",
            "Size estimate only. Cleaner never deletes Downloads automatically.",
            "",
            False,
            True,
        ),
        CleanerTarget(
            "Personal File Review",
            "Desktop Folder",
            str(desktop),
            _folder_size(desktop, max_items=2500, max_seconds=1.5),
            "Personal",
            "Review Only",
            "Size estimate only. Cleaner never deletes Desktop files automatically.",
            "",
            False,
            True,
        ),
        CleanerTarget(
            "Personal File Review",
            "Documents Folder",
            str(documents),
            _folder_size(documents, max_items=3500, max_seconds=1.8),
            "Personal",
            "Review Only",
            "Size estimate only. Cleaner never deletes Documents automatically.",
            "",
            False,
            True,
        ),
    ]

    targets.extend(browser_cache_targets())
    return _existing_targets(targets)


def _targets_for_action(action: str, targets: List[CleanerTarget]) -> List[CleanerTarget]:
    if action == "recommended":
        return [t for t in targets if t.cleanup_key in SAFE_RECOMMENDED_KEYS and t.safe_to_clean]
    if action == "recycle_bin":
        return [CleanerTarget(
            "Windows Cleanup",
            "Recycle Bin",
            "Recycle Bin",
            0,
            "Advanced",
            "Advanced Cleanable",
            "Empties the Windows Recycle Bin. This is separate from personal-folder cleanup.",
            "recycle_bin",
            False,
        )]
    return [t for t in targets if t.cleanup_key == action]


def cleaner_action_preview(action: str) -> str:
    targets = analyze_cleaner()
    selected = _targets_for_action(action, targets)
    estimated = sum(t.estimated_bytes for t in selected)

    lines = [
        "Cleaner Preview",
        "===============",
        "",
        f"Selected action: {action}",
        f"Estimated cleanup: {format_bytes(estimated)}",
        "",
        "Included categories:",
    ]

    if selected:
        for target in selected:
            lines.append(
                f"- {target.category} / {target.name}: {format_bytes(target.estimated_bytes)} "
                f"[{target.action}; risk: {target.risk}]"
            )
    else:
        lines.append("- No matching cleanup targets were found.")

    lines.extend([
        "",
        "Safety rules:",
        "- Downloads, Desktop, Documents, Pictures, Videos, and Music are review-only and are never deleted automatically.",
        "- Locked files and protected files are skipped.",
        "- Missing folders are skipped.",
        "- A cleanup log is saved after the action.",
    ])

    if action in ADVANCED_KEYS:
        lines.extend([
            "",
            "Advanced cleanup notice:",
            "- This action is outside Clean Recommended.",
            "- Administrator mode may be required.",
        ])

    return "\n".join(lines)


def consumer_summary(targets: List[CleanerTarget]) -> str:
    groups: dict[str, int] = {}
    safe_cleanable = 0
    advanced_cleanable = 0
    review = 0

    for target in targets:
        groups[target.category] = groups.get(target.category, 0) + target.estimated_bytes
        if target.safe_to_clean:
            safe_cleanable += target.estimated_bytes
        elif target.cleanup_key in ADVANCED_KEYS:
            advanced_cleanable += target.estimated_bytes
        else:
            review += target.estimated_bytes

    lines = [
        "Cleaner Summary",
        "===============",
        "",
        f"Clean Recommended estimate: {format_bytes(safe_cleanable)}",
        f"Advanced cleanup estimate: {format_bytes(advanced_cleanable)}",
        f"Review-only storage found: {format_bytes(review)}",
        "",
        "Exact category summary:",
    ]

    for target in targets:
        lines.append(
            f"- {target.category} / {target.name}: {format_bytes(target.estimated_bytes)} "
            f"({target.action}, risk: {target.risk})"
        )

    lines.extend([
        "",
        "What this means:",
        "- Clean Recommended only targets temp/cache/crash-dump areas.",
        "- Personal folders are measured only and are not deleted automatically.",
        "- Advanced cleanup actions must be enabled separately in the Cleaner page.",
        "- Some files may be skipped if they are locked by running apps.",
        "",
        "Open the More Info tab for paths, risk labels, cleanup keys, and technical details.",
    ])

    return "\n".join(lines)


def technical_details(targets: List[CleanerTarget]) -> str:
    lines = [
        "Cleaner Technical Details",
        "=========================",
        "",
    ]

    for target in targets:
        lines.append(f"[{target.category}] {target.name}")
        lines.append(f"  Size: {format_bytes(target.estimated_bytes)}")
        lines.append(f"  Risk: {target.risk}")
        lines.append(f"  Action: {target.action}")
        lines.append(f"  Safe to clean automatically: {'Yes' if target.safe_to_clean else 'No'}")
        lines.append(f"  Personal file area: {'Yes' if target.personal_file_area else 'No'}")
        lines.append(f"  Path: {target.path}")
        lines.append(f"  Cleanup key: {target.cleanup_key or 'review-only'}")
        lines.append(f"  Notes: {target.description}")
        lines.append("")

    return "\n".join(lines).strip()


def _refuse_if_personal_folder(path: Path) -> str | None:
    if is_personal_file_area(path):
        return (
            f"Refused cleanup for personal file area: {path}\n"
            "Cleaner does not automatically delete Downloads, Desktop, Documents, Pictures, Videos, or Music."
        )
    return None


def _delete_file(path: Path, stats: CleanupStats):
    try:
        try:
            stats.freed_bytes += path.stat().st_size
        except OSError:
            pass
        path.unlink()
        stats.deleted_files += 1
        stats.remember_deleted(path)
    except OSError as exc:
        stats.remember_skipped(path, str(exc))


def _delete_dir_tree(path: Path, stats: CleanupStats, max_items: int = 25000, max_seconds: float = 60.0):
    start = time.monotonic()
    touched = 0

    for root, dirs, files in os.walk(path, topdown=False):
        if touched >= max_items or time.monotonic() - start > max_seconds:
            stats.remember_skipped(Path(root), "cleanup safety limit reached")
            return

        root_path = Path(root)

        for file_name in files:
            if touched >= max_items:
                stats.remember_skipped(root_path / file_name, "cleanup safety item limit reached")
                return
            _delete_file(root_path / file_name, stats)
            touched += 1

        for dir_name in dirs:
            candidate = root_path / dir_name
            try:
                candidate.rmdir()
                stats.deleted_dirs += 1
                stats.remember_deleted(candidate)
            except OSError as exc:
                stats.remember_skipped(candidate, str(exc))
            touched += 1

    try:
        path.rmdir()
        stats.deleted_dirs += 1
        stats.remember_deleted(path)
    except OSError:
        pass


def clean_folder_contents(path: str) -> Tuple[str, int]:
    folder = Path(path)
    if _is_missing_path(folder):
        return f"Folder path is unavailable in this Windows profile: {path}", 0
    if not folder.exists() or not folder.is_dir():
        return f"Folder not found: {path}", 0

    refusal = _refuse_if_personal_folder(folder)
    if refusal:
        return refusal, 0

    stats = CleanupStats(root=str(folder))

    try:
        entries = list(folder.iterdir())
    except OSError as exc:
        return f"Could not read folder: {path}\n{exc}", 0

    for item in entries:
        try:
            if item.is_symlink():
                _delete_file(item, stats)
            elif item.is_file():
                _delete_file(item, stats)
            elif item.is_dir():
                _delete_dir_tree(item, stats)
        except OSError as exc:
            stats.remember_skipped(item, str(exc))

    return stats.report(f"Cleanup Report: {folder.name}"), stats.freed_bytes


def clean_user_temp() -> Tuple[str, int]:
    return clean_folder_contents(tempfile.gettempdir())


def clean_windows_temp() -> Tuple[str, int]:
    return clean_folder_contents(str(Path(os.environ.get("SystemRoot", r"C:\Windows")) / "Temp"))


def clean_thumbnail_cache() -> Tuple[str, int]:
    folder = _env_path("LOCALAPPDATA", "Microsoft", "Windows", "Explorer")
    if not folder.exists():
        return "Thumbnail cache folder not found.", 0

    refusal = _refuse_if_personal_folder(folder)
    if refusal:
        return refusal, 0

    stats = CleanupStats(root=str(folder))

    for file in folder.glob("thumbcache*.db"):
        _delete_file(file, stats)

    return stats.report("Thumbnail Cache Cleanup Report"), stats.freed_bytes


def clean_crash_dumps() -> Tuple[str, int]:
    return clean_folder_contents(str(_env_path("LOCALAPPDATA", "CrashDumps")))


def clean_browser_cache() -> Tuple[str, int]:
    targets = [t for t in browser_cache_targets() if t.path and Path(t.path).exists()]
    if not targets:
        return "No browser cache folders were found.", 0

    reports: list[str] = []
    total = 0

    for target in targets:
        report, freed = clean_folder_contents(target.path)
        total += freed
        reports.append(f"{target.name}\n{'-' * len(target.name)}\n{report}")

    reports.append(f"Total estimated freed: {format_bytes(total)}")
    return "\n\n".join(reports), total


def empty_recycle_bin() -> Tuple[str, int]:
    try:
        result = run_hidden(
            [
                "powershell", "-NoProfile", "-ExecutionPolicy", "Bypass", "-WindowStyle", "Hidden",
                "-Command", "Clear-RecycleBin -Force -ErrorAction SilentlyContinue; Write-Output 'Recycle Bin cleanup requested.'"
            ],
            timeout=180,
        )
        output = result.stdout or ""
        if result.stderr:
            output += "\n" + result.stderr
        return output.strip() or "Recycle Bin cleanup requested.", 0
    except FileNotFoundError:
        return "Recycle Bin cleanup requires Windows PowerShell.", 0
    except Exception as exc:
        return f"Recycle Bin cleanup could not run: {exc}", 0


def clean_recommended() -> Tuple[str, int]:
    """Run only the recommended safe cleanup set."""
    reports = []
    total = 0

    for label, func in [
        ("User Temp", clean_user_temp),
        ("Browser Cache", clean_browser_cache),
        ("Thumbnail Cache", clean_thumbnail_cache),
        ("Crash Dumps", clean_crash_dumps),
    ]:
        output, freed = func()
        total += freed
        reports.append(f"{label}\n{'=' * len(label)}\n{output}")

    reports.append("")
    reports.append(f"Total estimated freed by Clean Recommended: {format_bytes(total)}")
    reports.append("Personal folders were not cleaned.")
    return "\n\n".join(reports), total
