from __future__ import annotations

import platform
import shutil
from dataclasses import dataclass

from core.process_utils import run_hidden


@dataclass
class UpdateHealthItem:
    name: str
    status: str
    message: str

    def line(self) -> str:
        return f"[{self.status.upper()}] {self.name}: {self.message}"


def is_windows() -> bool:
    return platform.system().lower() == "windows"


def winget_health() -> UpdateHealthItem:
    path = shutil.which("winget")
    if not path:
        return UpdateHealthItem(
            "winget",
            "warning",
            "winget was not found. Install or repair App Installer from Microsoft Store, then scan again.",
        )

    try:
        result = run_hidden(["winget", "--version"], timeout=20)
        version = (result.stdout or result.stderr or "").strip()
        if result.returncode == 0:
            return UpdateHealthItem("winget", "good", f"Available at {path}. Version: {version or 'unknown'}")
        return UpdateHealthItem("winget", "warning", f"winget returned exit code {result.returncode}: {version}")
    except Exception as exc:
        return UpdateHealthItem("winget", "warning", f"winget could not run: {exc}")


def winget_source_health() -> UpdateHealthItem:
    if not shutil.which("winget"):
        return UpdateHealthItem("winget sources", "warning", "winget is not available, so sources could not be checked.")

    try:
        result = run_hidden(["winget", "source", "list"], timeout=45)
        output = ((result.stdout or "") + "\n" + (result.stderr or "")).strip()
        lower = output.lower()
        if result.returncode == 0 and ("winget" in lower or "msstore" in lower):
            return UpdateHealthItem("winget sources", "good", "winget sources responded successfully.")
        if result.returncode == 0:
            return UpdateHealthItem("winget sources", "warning", "winget source list completed, but expected sources were not clearly detected.")
        return UpdateHealthItem("winget sources", "warning", f"winget source list returned exit code {result.returncode}. {output[:500]}")
    except Exception as exc:
        return UpdateHealthItem("winget sources", "warning", f"winget sources could not be checked: {exc}")


def repair_winget_sources() -> str:
    if not shutil.which("winget"):
        return (
            "winget was not found.\n\n"
            "Repair path:\n"
            "1. Open Microsoft Store.\n"
            "2. Search for App Installer.\n"
            "3. Install or update App Installer.\n"
            "4. Restart this app and scan again."
        )

    lines = ["winget Source Repair", "====================", ""]
    for command in [
        ["winget", "source", "reset", "--force"],
        ["winget", "source", "update"],
    ]:
        lines.append("> " + " ".join(command))
        try:
            result = run_hidden(command, timeout=180)
            output = ((result.stdout or "") + "\n" + (result.stderr or "")).strip()
            lines.append(output or "No output returned.")
            lines.append(f"Exit code: {result.returncode}")
        except Exception as exc:
            lines.append(f"Command failed: {exc}")
        lines.append("")
    return "\n".join(lines).strip()


def windows_update_service_health() -> UpdateHealthItem:
    if not is_windows():
        return UpdateHealthItem("Windows Update services", "warning", "Windows Update checks require Windows.")

    script = r"""
$names = 'wuauserv','bits','cryptsvc','trustedinstaller'
$services = Get-Service -Name $names -ErrorAction SilentlyContinue |
  Select-Object Name, Status, StartType
if ($null -eq $services) {
  Write-Output 'No Windows Update services were returned.'
  exit 1
}
$services | ForEach-Object { "$($_.Name):$($_.Status):$($_.StartType)" }
"""
    try:
        result = run_hidden(
            ["powershell.exe", "-NoProfile", "-ExecutionPolicy", "Bypass", "-WindowStyle", "Hidden", "-Command", script],
            timeout=30,
        )
        output = ((result.stdout or "") + "\n" + (result.stderr or "")).strip()
        lower = output.lower()
        if result.returncode == 0 and "wuauserv" in lower and "bits" in lower:
            if ":running:" in lower:
                return UpdateHealthItem("Windows Update services", "good", output)
            return UpdateHealthItem("Windows Update services", "warning", output + "\nOne or more update services may not be running.")
        return UpdateHealthItem("Windows Update services", "warning", output or "Windows Update service check returned no output.")
    except Exception as exc:
        return UpdateHealthItem("Windows Update services", "warning", f"Windows Update services could not be checked: {exc}")


def update_health_items() -> list[UpdateHealthItem]:
    return [
        winget_health(),
        winget_source_health(),
        windows_update_service_health(),
        UpdateHealthItem(
            "Manual Windows Update fallback",
            "info",
            "If automatic scanning fails, open Settings > Windows Update and check manually.",
        ),
    ]


def update_health_report() -> str:
    items = update_health_items()
    lines = [
        "Update Health Check",
        "===================",
        "",
    ]
    lines.extend(item.line() for item in items)
    lines.extend([
        "",
        "Recommended fixes:",
        "- If winget is missing, install or repair App Installer from Microsoft Store.",
        "- If winget sources are broken, use Repair winget Sources.",
        "- If Windows Update services are restricted, open Windows Update Settings and check manually.",
    ])
    return "\n".join(lines)



def repair_windows_update_services() -> str:
    """Attempt a conservative Windows Update service repair.

    This only starts required services and reports status. It does not delete
    update caches, reset components, or change policy settings.
    """
    if not is_windows():
        return "Windows Update service repair requires Windows."

    script = r"""
$names = 'wuauserv','bits','cryptsvc','trustedinstaller'
$lines = @()
foreach ($name in $names) {
  try {
    $svc = Get-Service -Name $name -ErrorAction Stop
    $lines += "Before: $($svc.Name) = $($svc.Status) / StartType=$($svc.StartType)"

    if ($svc.Status -ne 'Running') {
      try {
        Start-Service -Name $name -ErrorAction Stop
        Start-Sleep -Milliseconds 700
        $svc = Get-Service -Name $name -ErrorAction Stop
        $lines += "Started: $($svc.Name) = $($svc.Status)"
      } catch {
        $lines += "Could not start $name: $($_.Exception.Message)"
      }
    }
  } catch {
    $lines += "Missing or inaccessible service $name: $($_.Exception.Message)"
  }
}

$lines += ""
$lines += "Final service state:"
Get-Service -Name $names -ErrorAction SilentlyContinue | ForEach-Object {
  $lines += "$($_.Name): $($_.Status) / StartType=$($_.StartType)"
}
$lines -join "`n"
"""
    try:
        result = run_hidden(
            ["powershell.exe", "-NoProfile", "-ExecutionPolicy", "Bypass", "-WindowStyle", "Hidden", "-Command", script],
            timeout=90,
        )
        output = ((result.stdout or "") + "\n" + (result.stderr or "")).strip()
        if not output:
            output = "Windows Update service repair completed with no output."
        return (
            "Windows Update Service Repair\n"
            "=============================\n\n"
            "Conservative repair only: attempted to start Windows Update-related services.\n"
            "No update cache reset was performed.\n\n"
            f"{output}\n\nExit code: {result.returncode}"
        )
    except Exception as exc:
        return f"Windows Update service repair could not run: {exc}"



def open_app_installer_store() -> str:
    """Open App Installer store page if Windows URI handling is available."""
    import os

    uri = "ms-windows-store://pdp/?ProductId=9NBLGGH4NNS1"
    if not is_windows():
        return "Opening App Installer requires Windows Microsoft Store."

    try:
        os.startfile(uri)  # type: ignore[attr-defined]
        return (
            "Opened Microsoft Store App Installer page.\n\n"
            "Install or update App Installer, then restart AIO IT TOOLS and run Check Update Health again."
        )
    except Exception as exc:
        return (
            "Could not open Microsoft Store automatically.\n\n"
            "Manual fix:\n"
            "1. Open Microsoft Store.\n"
            "2. Search for App Installer.\n"
            "3. Install or update it.\n"
            "4. Restart AIO IT TOOLS.\n\n"
            f"Error: {exc}"
        )


def winget_self_check_report() -> str:
    items = [winget_health(), winget_source_health()]
    lines = [
        "winget Self-Check",
        "=================",
        "",
    ]
    lines.extend(item.line() for item in items)
    lines.extend([
        "",
        "Fix order:",
        "1. If winget is missing, install/update App Installer from Microsoft Store.",
        "2. If winget exists but sources fail, run Repair winget Sources.",
        "3. Restart AIO IT TOOLS and scan again.",
    ])
    return "\n".join(lines)
