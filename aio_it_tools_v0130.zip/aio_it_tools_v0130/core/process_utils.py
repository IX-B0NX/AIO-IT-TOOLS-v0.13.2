from __future__ import annotations

import os
import subprocess
from typing import Sequence


def creation_flags() -> int:
    return subprocess.CREATE_NO_WINDOW if os.name == "nt" else 0


def startup_info():
    if os.name != "nt":
        return None
    info = subprocess.STARTUPINFO()
    info.dwFlags |= subprocess.STARTF_USESHOWWINDOW
    info.wShowWindow = 0
    return info


def run_hidden(
    command: str | Sequence[str],
    *,
    shell: bool = False,
    timeout: int = 300,
    cwd: str | None = None,
) -> subprocess.CompletedProcess:
    """Run a process without opening a visible console window on Windows."""
    return subprocess.run(
        command,
        shell=shell,
        cwd=cwd,
        capture_output=True,
        text=True,
        timeout=timeout,
        encoding="utf-8",
        errors="replace",
        creationflags=creation_flags(),
        startupinfo=startup_info(),
    )
