from __future__ import annotations

import json
from pathlib import Path
from typing import Any

from core.config import app_dir
from core.models import UpdateRow


def preferences_path() -> Path:
    return app_dir() / "ignored_updates.json"


def ignore_key(row: UpdateRow) -> str:
    source = (row.source or row.item_type or "").strip().lower()
    package_id = (row.raw_id or row.update_link or "").strip().lower()
    name = (row.name or "").strip().lower()
    latest = (row.latest_version or "").strip().lower()

    if package_id:
        return f"{source}|{package_id}"
    return f"{source}|{name}|{latest}"


def load_ignored_updates() -> dict[str, Any]:
    path = preferences_path()
    if not path.exists():
        return {}
    try:
        data = json.loads(path.read_text(encoding="utf-8"))
        return data if isinstance(data, dict) else {}
    except Exception:
        return {}


def save_ignored_updates(data: dict[str, Any]) -> None:
    preferences_path().write_text(json.dumps(data, indent=2, default=str), encoding="utf-8")


def is_update_ignored(row: UpdateRow) -> bool:
    return ignore_key(row) in load_ignored_updates()


def add_ignored_update(row: UpdateRow) -> str:
    data = load_ignored_updates()
    key = ignore_key(row)
    data[key] = {
        "name": row.name,
        "item_type": row.item_type,
        "source": row.source,
        "package_id": row.raw_id,
        "latest_version": row.latest_version,
    }
    save_ignored_updates(data)
    return key


def clear_ignored_updates() -> int:
    data = load_ignored_updates()
    count = len(data)
    save_ignored_updates({})
    return count


def ignored_updates_text() -> str:
    data = load_ignored_updates()
    if not data:
        return "No ignored updates are currently saved."

    lines = [
        "Ignored Updates",
        "===============",
        "",
    ]
    for key, value in data.items():
        if isinstance(value, dict):
            lines.append(f"- {value.get('name', key)}")
            if value.get("package_id"):
                lines.append(f"  Package ID: {value.get('package_id')}")
            if value.get("latest_version"):
                lines.append(f"  Ignored version: {value.get('latest_version')}")
        else:
            lines.append(f"- {key}")
    return "\n".join(lines)
