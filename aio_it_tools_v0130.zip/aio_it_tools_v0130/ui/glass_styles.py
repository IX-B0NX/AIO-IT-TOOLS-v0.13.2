from __future__ import annotations


APP_QSS = """
QMainWindow {
    background: #D5E3E8;
}

QWidget {
    color: #1F2A2E;
    font-family: Segoe UI, Arial, sans-serif;
    font-size: 12px;
}

QFrame#Sidebar {
    background-color: #4F5F65;
    border: 0;
    border-radius: 0;
}

QFrame#ContentPanel {
    background-color: #F6FAFB;
    border: 1px solid #B7C8CF;
    border-radius: 0;
}

QFrame#TopHeader {
    background-color: #46545A;
    border: 0;
    border-bottom: 1px solid #3B474C;
}

QFrame#PageBar {
    background-color: #F6FAFB;
    border: 0;
    border-bottom: 1px solid #B7C8CF;
}

QFrame#Card, QFrame#DashboardCard {
    background-color: #FFFFFF;
    border: 1px solid #B7C8CF;
    border-radius: 2px;
}

QLabel#HeaderLogo {
    background: transparent;
}

QLabel#HeaderTitle {
    color: #FFFFFF;
    font-size: 22px;
    font-weight: 900;
}

QLabel#HeaderSubtext {
    color: #D5E3E8;
    font-size: 11px;
    font-weight: 600;
}

QLabel#HeaderBadge {
    color: #FFFFFF;
    background-color: #2F6F7E;
    border: 1px solid rgba(255,255,255,60);
    border-radius: 2px;
    padding: 6px 10px;
    font-weight: 850;
}

QLabel#AppTitle {
    color: #FFFFFF;
    font-size: 16px;
    font-weight: 900;
}

QLabel#Creator {
    color: #D5E3E8;
    font-size: 10px;
    font-weight: 700;
}

QLabel#AdminBadge {
    color: #FFFFFF;
    background-color: rgba(213, 227, 232, 35);
    border: 1px solid rgba(213, 227, 232, 70);
    border-radius: 2px;
    padding: 5px 8px;
    font-size: 10px;
    font-weight: 850;
}

QLabel#PageTitle {
    color: #1F2A2E;
    font-size: 21px;
    font-weight: 900;
}

QLabel#Subtitle {
    color: #5F6F75;
    font-size: 12px;
}

QLabel#ProgressIdle {
    color: #6B8F9C;
    font-size: 11px;
    font-weight: 750;
}

QLabel#CardTitle, QLabel#DashboardBadge {
    color: #2F6F7E;
    font-size: 11px;
    font-weight: 900;
}

QLabel#CardNumber {
    color: #1F2A2E;
    font-size: 30px;
    font-weight: 900;
}

QLabel#DashboardCardTitle {
    color: #1F2A2E;
    font-size: 18px;
    font-weight: 900;
}

QLabel#DashboardText {
    color: #5F6F75;
    font-size: 12px;
}

QPushButton {
    background-color: #EEF5F7;
    border: 1px solid #B7C8CF;
    border-radius: 2px;
    padding: 9px 13px;
    color: #1F2A2E;
    font-weight: 800;
}

QPushButton:hover {
    background-color: #D5E3E8;
    border: 1px solid #6B8F9C;
}

QPushButton:pressed {
    background-color: #B7C8CF;
}

QPushButton#PrimaryButton, QPushButton#RecommendedButton {
    background-color: #2F6F7E;
    color: #FFFFFF;
    border: 1px solid #244F5A;
}

QPushButton#PrimaryButton:hover, QPushButton#RecommendedButton:hover {
    background-color: #244F5A;
}


QFrame#SectionHeader {
    background-color: transparent;
    border: 0;
}

QLabel#SectionTitle {
    color: #1F2A2E;
    font-size: 17px;
    font-weight: 900;
}

QPushButton#SecondaryButton {
    background-color: #EEF5F7;
    color: #1F2A2E;
    border: 1px solid #B7C8CF;
}

QPushButton#SecondaryButton:hover {
    background-color: #D5E3E8;
    border: 1px solid #6B8F9C;
}


QPushButton#ActionButton {
    background-color: #F6FAFB;
    color: #1F2A2E;
    border: 1px solid #D9902F;
}

QPushButton#ActionButton:hover {
    background-color: rgba(217, 144, 47, 45);
    border: 1px solid #D9902F;
}

QPushButton#NavButton {
    background-color: transparent;
    border: 0;
    border-radius: 0;
    padding: 16px 14px;
    color: #FFFFFF;
    text-align: left;
    font-weight: 800;
    font-size: 13px;
}

QPushButton#NavButton:hover {
    background-color: rgba(213, 227, 232, 35);
    color: #FFFFFF;
}

QPushButton#NavButtonActive {
    background-color: #2F6F7E;
    color: #FFFFFF;
    border: 0;
    border-radius: 0;
    padding: 16px 14px;
    text-align: left;
    font-weight: 900;
    font-size: 13px;
}

QLineEdit {
    background-color: #FFFFFF;
    border: 1px solid #B7C8CF;
    border-radius: 2px;
    padding: 9px 11px;
    color: #1F2A2E;
}

QTableWidget {
    background-color: #FFFFFF;
    border: 1px solid #B7C8CF;
    border-radius: 0;
    gridline-color: rgba(183, 200, 207, 110);
    color: #1F2A2E;
    selection-background-color: rgba(47, 111, 126, 70);
    selection-color: #1F2A2E;
    alternate-background-color: #F6FAFB;
}

QTableWidget::item {
    padding: 6px 8px;
}

QHeaderView::section {
    background-color: #EEF5F7;
    color: #1F2A2E;
    border: 0;
    border-right: 1px solid rgba(183, 200, 207, 110);
    border-bottom: 1px solid rgba(183, 200, 207, 110);
    padding: 8px;
    font-weight: 900;
}

QTextBrowser, QTextEdit {
    background-color: #FFFFFF;
    border: 1px solid #B7C8CF;
    border-radius: 0;
    padding: 12px;
    color: #1F2A2E;
}

QProgressBar {
    background-color: #F6FAFB;
    border: 1px solid #B7C8CF;
    border-radius: 0;
    height: 16px;
    text-align: right;
    padding-right: 4px;
    color: #1F2A2E;
    font-weight: 900;
}

QProgressBar::chunk {
    background-color: #6FC7A0;
    border-radius: 0;
}

QScrollBar:vertical {
    background: #EEF5F7;
    width: 13px;
    margin: 0;
}

QScrollBar::handle:vertical {
    background: #B7C8CF;
    border-radius: 0;
    min-height: 30px;
}

QScrollBar:horizontal {
    background: #EEF5F7;
    height: 13px;
    margin: 0;
}

QScrollBar::handle:horizontal {
    background: #B7C8CF;
    border-radius: 0;
    min-width: 30px;
}


QCheckBox {
    color: #1F2A2E;
    font-weight: 800;
    spacing: 8px;
}

QCheckBox::indicator {
    width: 16px;
    height: 16px;
}

QCheckBox::indicator:unchecked {
    background-color: #FFFFFF;
    border: 1px solid #B7C8CF;
}

QCheckBox::indicator:checked {
    background-color: #2F6F7E;
    border: 1px solid #244F5A;
}



QLabel#BetaBadge {
    color: #1F2A2E;
    background-color: #F3C75F;
    border: 1px solid #D9902F;
    border-radius: 2px;
    padding: 6px 10px;
    font-weight: 900;
}

QFrame#BetaBanner {
    background-color: #FFF4D8;
    border: 1px solid #D9902F;
    border-radius: 2px;
}

QLabel#BetaTitle {
    color: #1F2A2E;
    font-size: 16px;
    font-weight: 900;
}

QLabel#BetaText {
    color: #4F5F65;
    font-size: 12px;
    font-weight: 700;
}




QPushButton[enabledAdvanced="true"] {
    background-color: #F3C75F;
    border: 1px solid #D9902F;
    color: #1F2A2E;
    font-weight: 900;
}

QPushButton[enabledAdvanced="true"]:hover {
    background-color: #F6D57C;
    border: 1px solid #C97E20;
}

QPushButton[enabledAdvanced="true"]:pressed {
    background-color: #E6B84F;
    border: 1px solid #B96F16;
}

QPushButton[enabledAdvanced="false"] {
    background-color: #FFFFFF;
}

QFrame#ReleaseBanner, QFrame#BetaBanner {
    background-color: transparent;
    border: none;
}

QLabel#ReleaseBadge, QLabel#BetaBadge {
    background-color: transparent;
    border: none;
    color: #4F5F65;
    padding: 0px;
}

"""
