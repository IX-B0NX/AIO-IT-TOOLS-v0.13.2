# AIO IT TOOLS v0.13.0

created by ฿0₦Ӿ

Professional Windows update, cleanup, and IT maintenance utility.

## Main features

- Dark glass desktop interface
- Full app/driver/update inventory
- Green YES for available updates
- Red NO for no update detected
- Orange WARNING for scanner issues
- Direct app updating through winget
- Update Selected
- Update Detected Apps
- Consumer-friendly Cleaner tab
- More Info tab for technical cleanup details
- AIO Toolkit tab with repair and diagnostic actions
- Logs saved under `logs/`
- CSV and HTML report export

## Cleaner design

The Cleaner tab shows a consumer-friendly summary first.

It separates results into:

- Safe cleanup estimate
- Review-only storage
- Browser and privacy cache
- Windows cleanup
- Diagnostics cleanup
- Personal file review

The More Info tab shows:

- full paths
- risk labels
- cleanup status
- estimated size
- notes for each target

## Direct update behavior

Direct updates currently support winget app updates only.

`Update Selected` updates the selected YES app row when it has a winget package ID.

`Update Detected Apps` processes only the winget app updates detected in the current scan. It does not blindly run a full package-manager update against items that were not shown in the table.

## Run

```text
run_aio_it_tools.bat
```

## Build portable EXE

```text
build_exe.bat
```

Output:

```text
dist\AIOITTools.exe
```

## Developer notes

- Keep destructive actions behind confirmation prompts.
- Keep driver updates conservative until official vendor/OEM update flows are added.
- Keep review-only locations separate from cleanable locations.
- Avoid cleaning personal folders automatically.
- Keep logs plain text for support workflows.


## v0.8.2 admin and consumer UI pass

- Startup now requests Administrator mode on Windows.
- The packaged EXE build uses a UAC admin manifest.
- The app cannot bypass UAC; Windows still requires approval.
- Header now shows Administrator Mode status.
- Removed harsh red cleanup buttons and replaced them with warning-styled action buttons.
- Renamed some UI buttons for consumers:
  - Scan PC
  - Update Apps
  - Windows Update
  - Report
- Cleaner wording is more consumer-friendly while keeping More Info for technical details.


## v0.8.3 consumer UI and confirmation pass

- Added Home dashboard with large action cards:
  - Update Apps
  - Clean PC
  - Check Health
  - Repair Tools
- Added plain-English dashboard status after scanning.
- Added custom confirmation dialogs for updates, cleanup, and toolkit actions.
- Confirmation dialogs now explain exactly what will happen before the action runs.
- Generic question-mark prompts have been replaced with review-style confirmation text.
- Cleaner still provides a simple summary first and deeper technical detail in More Info.


## v0.8.4 refined driver update comparison

- Added a dedicated Driver Updates tab.
- Added Scan Driver Updates action.
- Shows installed driver version and installed driver date.
- Shows available driver version and available driver date when Windows Update reports one.
- Shows match confidence between installed device and available driver update.
- Shows installed INF/provider, update ID, source, and support/vendor links in Details.
- Driver installation is still disabled until rollback/restore-point handling is added.


## v0.8.5 automated driver update workflow

- Added Driver Updates tab if it was not already present in the UI build.
- Added Scan Driver Updates.
- Added Auto Update Drivers.
- Runs with one confirmation, then automates the workflow.
- Attempts to create a restore point.
- Exports current installed drivers to `driver_backups/`.
- Installs only driver updates reported by Windows Update.
- Saves a plain-text driver update log.
- Shows rollback notes after the workflow finishes.
- Automatically refreshes the Driver Updates comparison after completion.

The workflow uses official Windows Update driver updates only. It does not scrape driver websites or download unknown installers.


## v0.9 UI refactor

- Replaced dark mode with the #D5E3E8 light theme.
- Replaced top-tab clutter with left sidebar navigation.
- Added dedicated pages:
  - Home
  - Updates
  - Drivers
  - Cleaner
  - Health
  - Repair
  - Reports
  - More Info
  - Settings
- Home is now a guided dashboard instead of a raw table.
- Technical details are hidden by default and shown in More Info.
- Added progress bars with percentages for:
  - PC scans
  - app updates
  - cleaner analysis and cleanup
  - driver comparison
  - automated driver update workflow
  - health checks
  - toolkit actions
- Added Health page with pending reboot, Defender, firewall, disk, battery, TPM, and Secure Boot checks.


## v0.9.1 UI and scan refinement

- Removed the global Scan PC button from the top of every page.
- Added dedicated action buttons inside the pages where they belong.
- Updates page now shows app and Windows Update rows only.
- Driver rows stay in the Drivers page.
- Progress bar now uses task-specific wording.
- Idle progress text appears when a task has not started and disappears once a task begins.
- Windows Update scan fallback now gives a useful manual-review row instead of a vague unavailable result.
- Home cards now update with simple counts after scans.


## v0.9.2 UI and scanner refinement

- Home was changed to a CCleaner-style status page instead of duplicating sidebar actions.
- Removed the global Scan PC button from the top area.
- Added page-specific scan/action buttons.
- Updates page uses an app/Windows Update-only scanner.
- Driver inventory and comparison stay in the Drivers page.
- Progress status is task-specific and includes idle text when nothing has started.
- Windows Update scan fallback now returns an actionable manual-review row with a Windows Update Settings link instead of a vague unavailable result.


## v0.9.4 stability review

- Fixed the most likely crash source: starting the same QThread task twice.
- Added guards so scans, updates, cleaner tasks, health checks, driver workflows, and repair tools cannot overwrite a running worker.
- Made progress labels task-specific across pages.
- Fixed app update completion progress label.
- Hardened report export and folder-opening actions.
- Hardened repair/toolkit action runner so command failures return readable output instead of bubbling exceptions.
- Increased timeouts for long repair commands like SFC and DISM.
- Hardened Recycle Bin cleanup when PowerShell is unavailable.


## v0.9.5 section progress and stability pass

- Replaced the shared global progress bar with separate progress bars per section.
- Added dedicated progress bars for Home, Updates, Drivers, Cleaner, Health, and Repair.
- Cleaner analysis is now bounded by item count and time so it should not hang/crash while scanning large folders.
- Missing environment paths no longer accidentally scan the current folder.
- Browser cache analysis skips missing environment roots cleanly.
- Driver scan uses shorter Windows Update timeouts.
- Driver results are bounded so huge driver inventories do not overload the table.
- PowerShell commands now request hidden windows where possible.
- The old interactive BAT menu is disabled inside the app to avoid external console windows and hangs.


## v0.9.6 CCleaner-inspired UI pass

- Added `assets/AIO.ico`.
- App window now uses the uploaded icon.
- PyInstaller build uses the uploaded icon for the EXE.
- Added a CCleaner-inspired dark left navigation rail.
- Added a CCleaner-inspired top product header.
- Kept the requested color palette, including `#D5E3E8`.
- Made cards, tables, buttons, and progress bars more rectangular and utility-style.
- Logo is shown in the top-left brand area and product header.


## v0.9.7 table routing and icon sharpness fix

- Fixed Updates double-click/details routing after table sorting.
- Each table item now stores its real data index with `Qt.UserRole`.
- Driver table details use the same stable row-index fix.
- Rebuilt the uploaded icon into a multi-size ICO.
- Added `AIO_original.ico` for reference and regenerated `AIO.ico`.
- Added `AIO_256.png`.
- Logo rendering now uses `QIcon.pixmap()` instead of scaling the ICO directly.


## v0.9.8 crash logging and diagnostics

- Added `core/diagnostics.py`.
- Added global Python exception hook.
- Added thread exception hook.
- Added Qt message handler.
- Added last-action tracking.
- Added per-action diagnostic logs.
- Added system snapshot logging.
- Added Support ZIP export in Reports.
- Support ZIP includes diagnostics, logs, system snapshot, project metadata, and last-action data.
- Worker thread exceptions now write diagnostics before returning readable output to the UI.


## v0.9.9 UI consistency and workflow cleanup

- Removed build-environment smoke logs and support ZIPs from the final package.
- Added consistent section headers to major pages.
- Standardized primary, secondary, and warning button roles.
- Made Reports, Cleaner, Updates, Drivers, Health, and Repair page wording more consistent.
- Standardized More Info output formatting for updates, drivers, and repair actions.
- Improved confirmation dialog wording.
- Preserved the CCleaner-inspired visual style and `#D5E3E8` palette.


## v0.10.0 stability release

- Feature freeze stability pass.
- Added `core/process_utils.py` for hidden process execution.
- Reduced visible PowerShell/CMD window behavior where possible.
- Hardened non-admin handling for driver updates, advanced repair tools, Windows temp cleanup, and Recycle Bin cleanup.
- Added long-task heartbeat logging so stalled scans are easier to diagnose.
- Improved Windows Update fallback messaging with service status when available.
- Lowered Windows Update scan timeouts to reduce apparent stalls.
- Cleaned generated smoke logs and support ZIPs out of the final package.
- Preserved diagnostics and Support ZIP export from v0.9.8.
- Preserved UI consistency cleanup from v0.9.9.


## v0.10.1 cleaner safety pass

- Added preview-before-delete for all cleanup actions.
- Cleaner confirmations now include exact category estimates and safety rules.
- Clean Recommended only cleans safe temp/cache/crash-dump areas.
- Personal folders are review-only and blocked from automatic cleanup:
  - Downloads
  - Desktop
  - Documents
  - Pictures
  - Videos
  - Music
- Added advanced cleanup toggle for Windows Temp and Recycle Bin actions.
- Improved cleanup reports with deleted file counts, deleted folder counts, skipped locked/protected items, estimated freed space, and examples.
- Reworked folder deletion to skip locked files cleanly instead of failing an entire cleanup path.
- Cleaner analysis now labels safe, advanced, personal, and review-only categories more clearly.
- Cleaner logs now include the action preview when available.


## v0.10.2 driver safety pass

- Auto driver updates are disabled by default.
- Added Review Drivers step before installation can be enabled.
- Added review checkbox that must be checked before automated driver updates run.
- Added driver safety preflight checks:
  - administrator mode
  - pending reboot
  - laptop battery / power state
  - Windows Update-only install scope
- Automated driver workflow now blocks if:
  - administrator mode is unavailable
  - a reboot is already pending
  - laptop battery is below the safety threshold
  - current driver backup verification fails
- Driver backup verification now checks for exported INF files.
- Restore point outcome is logged clearly.
- Rollback instructions are written into the workflow output.
- Driver update source remains limited to Windows Update driver-class updates.
- Driver scan timeout and failure messages are clearer.
- Match confidence wording is clearer in Driver details.


## v0.10.3 Windows Update and app update pass

- Added update health check for winget, winget sources, and Windows Update services.
- Added Repair winget Sources action.
- Added app update history log.
- Added Update History button in Updates.
- Added Ignore Selected update option.
- Added Ignored Updates view.
- Ignored YES updates are hidden from future scan results.
- Improved winget availability checks before scanning.
- Improved winget source-warning messages.
- Improved Windows Update manual fallback details with service health.
- Added clearer update failure explanations.
- Added per-app progress for detected app updates.
- App update workflow still rescans automatically after completion.
- Improved no-update messages after scans.


## v0.11.0 final validation candidate

- Added Gold Master Candidate status in the app window and header.
- Added beta warning popup on startup.
- Added Home beta banner and basic onboarding/test flow.
- Added Known Issues page.
- Added Export Support ZIP emphasis for troubleshooting.
- Added safer beta defaults:
  - advanced repair tools hidden until enabled
  - low-risk repair tools shown separately
  - driver automation still review-gated
  - cleaner advanced actions still gated
- Added Clear Ignored Updates action.
- Added beta metadata module: `core/beta.py`.
- Updated diagnostics version to 0.11.0.


## v0.12.0 single-EXE distribution polish

- Renamed the app to **AIO IT TOOLS**.
- Replaced the application/build icon with the new provided `.ico`.
- Updated PyInstaller build output to `dist\AIOITTools.exe`.
- Updated `build_exe.bat` for one-file, windowed, admin-requesting EXE builds.
- Added `AIOITTools.spec` for repeatable PyInstaller builds.
- Added `DISTRIBUTION.md` with consumer single-EXE guidance.
- Runtime folders are created automatically:
  - logs
  - support_zips
  - driver_backups
- Frozen EXE runtime data is written to `%LOCALAPPDATA%\AIOITTools`.
- Source/dev mode still writes runtime files beside the project for easier debugging.
- Known Issues were triaged:
  - safe improvements were made where possible
  - unresolved/risky items remain tracked in the Known Issues page
  - single-EXE runtime behavior was added as a beta item to monitor
- No installer is included or planned for this stage.


## v0.12.1 EXE build validation pass

- Fixed startup crash:
  - `NameError: name 'ensure_runtime_dirs' is not defined`
- Rewrote `main.py` so runtime folder creation happens inside `main()` after imports are loaded.
- Validated `core.config.ensure_runtime_dirs()` and `core.config.asset_path()` imports.
- Kept single-EXE distribution target:
  - `dist\AIOITTools.exe`
- Kept runtime data target for frozen EXE mode:
  - `%LOCALAPPDATA%\AIOITTools`
- Cleaned generated logs/build/dist/support folders before packaging.

Recommended local test:
1. Run `run_aio_it_tools.bat` from source mode.
2. Run `build_exe.bat`.
3. Launch `dist\AIOITTools.exe`.
4. Confirm icon, UAC prompt, startup beta warning, logs, support ZIP, and driver backup folder behavior.


## v0.12.2 EXE launch validation and beta bugfix pass

- Fixed startup import error:
  - `ImportError: cannot import name 'relaunch_as_admin_if_needed' from 'core.admin'`
- Added `relaunch_as_admin_if_needed()` wrapper to `core/admin.py`.
- Improved `run_aio_it_tools.bat`:
  - checks for PySide6
  - installs requirements when PySide6 is missing
  - gives clearer source-run failure guidance
- Improved `build_exe.bat`:
  - verifies `dist\AIOITTools.exe` exists
  - gives clearer failure guidance
  - prints the final EXE test checklist
- Updated Known Issues with source-mode dependency tracking.
- Bumped diagnostics/beta version to 0.12.2.

Recommended test:
1. Run `run_aio_it_tools.bat`.
2. Confirm the app opens.
3. Run `build_exe.bat`.
4. Run `dist\AIOITTools.exe`.
5. Confirm UAC, icon, beta warning, runtime logs, Support ZIP, and clean restart.


## v0.12.3 source launch fix pass

- Fixed startup import error:
  - `ImportError: cannot import name 'MainWindow' from 'ui.main_window'`
- Added a stable public `MainWindow` export alias in `ui/main_window.py`.
- Added `validate_main_window_export()` so future smoke checks can verify the launcher target exists.
- Updated `main.py` to import and validate the window export before constructing the app window.
- Bumped diagnostics/beta version to 0.12.3.

Recommended test:
1. Run `run_aio_it_tools.bat`.
2. Confirm the app opens.
3. If source launch works, run `build_exe.bat`.
4. Test `dist\AIOITTools.exe`.


## v0.12.4 UI controls, health storage, Wi-Fi, and Known Issues cleanup

- Fixed checkbox/toggle handlers that did not respond because PySide6 passes a state argument:
  - Cleaner advanced cleanup toggle
  - Repair advanced tools toggle
  - Driver review checkbox state handler
- Updated Health storage display target:
  - GB available
  - MB available below it
- Added local admin Wi-Fi profile/password display in Repair:
  - uses Windows `netsh wlan show profile name=<profile> key=clear`
  - requires administrator mode
  - output stays local inside the app/log flow
- Cleaned Known Issues:
  - removed items already fixed in previous builds
  - kept unresolved/platform-dependent items
  - added Wi-Fi password display as new admin/Windows test item
- Bumped diagnostics/beta version to 0.12.4.

Recommended test:
1. Run `run_aio_it_tools.bat`.
2. Test all checkbox toggles:
   - Cleaner advanced cleanup
   - Repair advanced tools
   - Driver review checkbox
3. Run Health scan and verify storage formatting.
4. Run Repair > Wi-Fi Profiles + Passwords as admin.


## v0.12.5 Known Issues fix attempt pass

Attempted safe fixes for the current Known Issues list.

Fix attempts added:
- Windows Update:
  - Added Repair Windows Update Services.
  - This conservatively starts Windows Update-related services only.
  - It does not delete update cache or reset Windows Update components.
- winget:
  - Added Open App Installer helper.
  - Added winget self-check report.
  - Existing Repair winget Sources remains available.
- Drivers:
  - Review page now calls out lower-confidence driver matches more clearly.
- Runtime folders / single EXE:
  - Added Runtime Self-Test in Reports.
  - Verifies logs, support_zips, driver_backups, config path, and bundled icon path.
- Wi-Fi passwords:
  - Added Windows-only guard.
  - Added clearer output when Windows does not return Key Content.

Known Issues cleanup:
- Removed fixed UI/source launch items.
- Removed single-EXE runtime folder item as a standalone issue because Runtime Self-Test now covers it.
- Kept only unresolved or platform-dependent issues.


## v0.12.6 toggle reliability and Known Issues fix pass

- Fixed Driver review checkbox/toggle behavior by using `QCheckBox.toggled(bool)` directly.
- Fixed Repair advanced tools toggle behavior by using `QCheckBox.toggled(bool)` directly.
- Kept Cleaner advanced toggle on the same reliable pattern.
- Advanced Repair buttons now store a base tooltip and refresh cleanly when toggled.
- Driver automation now blocks lower-confidence driver matches instead of listing driver confidence as a Known Issue.
- Known Issues cleaned from 5 items to 4 items:
  - Windows Update policy restrictions
  - winget / App Installer dependency
  - Unsigned EXE reputation
  - Windows-only Wi-Fi password display

Driver safety behavior:
- Lower-confidence driver matches are shown for review.
- Automated driver updates are disabled if any available driver row is lower-confidence.
- Users should review those manually through Windows Update Optional Updates.


## v0.13.0 Gold Master UI polish and bug pass

- Removed final-validation/beta subtext from the main UI.
- Cleaned Home text and removed startup notice clutter.
- Changed Known Issues page to System Notes.
- Enabled advanced buttons now fill with the same gold/yellow shade used by their outline.
- Cleaner, Repair, and Driver advanced controls use a consistent dynamic button state.
- Driver automation remains blocked when lower-confidence driver matches exist.
- Ran a static bug pass:
  - verified toggle signal wiring
  - verified dynamic button styling
  - verified known issue/system note count
  - verified version metadata
  - verified syntax compilation
- Remaining System Notes are not app bugs; they are external platform/deployment dependencies.
