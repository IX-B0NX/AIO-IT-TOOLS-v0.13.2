@echo off
setlocal
cd /d "%~dp0"

echo Building AIO IT TOOLS single EXE...
echo Expected consumer output: dist\AIOITTools.exe
echo.

python -m pip install --upgrade pip
if errorlevel 1 goto fail

python -m pip install -r requirements.txt
if errorlevel 1 goto fail

python -m pip install pyinstaller
if errorlevel 1 goto fail

if exist build rmdir /s /q build
if exist dist rmdir /s /q dist
if exist AIOITTools.spec del AIOITTools.spec

pyinstaller ^
  --noconfirm ^
  --clean ^
  --onefile ^
  --windowed ^
  --uac-admin ^
  --name "AIOITTools" ^
  --icon "assets\AIO_IT_TOOLS.ico" ^
  --add-data "assets;assets" ^
  main.py

if errorlevel 1 goto fail

if not exist "dist\AIOITTools.exe" (
    echo.
    echo Build finished but dist\AIOITTools.exe was not found.
    goto fail
)

echo.
echo Build complete.
echo Consumer EXE:
echo dist\AIOITTools.exe
echo.
echo Next test:
echo 1. Run dist\AIOITTools.exe
echo 2. Confirm UAC prompt
echo 3. Confirm icon
echo 4. Confirm beta warning
echo 5. Export Support ZIP from Reports
echo.
pause
exit /b 0

:fail
echo.
echo EXE build failed.
echo Check the error above. Common fixes:
echo - Install Python 3.11 or newer
echo - Run this script from the project folder
echo - Check internet connection for pip installs
echo - Try: python -m pip install -r requirements.txt
echo.
pause
exit /b 1
