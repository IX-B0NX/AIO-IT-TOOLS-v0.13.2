# Open Source IT Tool v0.9.9

created by ฿0₦Ӿ

Professional Windows update, cleanup, and IT maintenance utility.

## Main features

- Dark glass desktop interface
- Full app/driver/update inventory
- Green YES for available updates
- Red NO for no update detected
- Orange WARNING for scanner issues
- Direct app updating through winget
- Update Selected
- Update Detected Apps
- Consumer-friendly Cleaner tab
- More Info tab for technical cleanup details
- AIO Toolkit tab with repair and diagnostic actions
- Logs saved under `logs/`
- CSV and HTML report export

## Cleaner design

The Cleaner tab shows a consumer-friendly summary first.

It separates results into:

- Safe cleanup estimate
- Review-only storage
- Browser and privacy cache
- Windows cleanup
- Diagnostics cleanup
- Personal file review

The More Info tab shows:

- full paths
- risk labels
- cleanup status
- estimated size
- notes for each target

## Direct update behavior

Direct updates currently support winget app updates only.

`Update Selected` updates the selected YES app row when it has a winget package ID.

`Update Detected Apps` processes only the winget app updates detected in the current scan. It does not blindly run a full package-manager update against items that were not shown in the table.

## Run

```text
run_open_source_it_tool.bat
```

## Build portable EXE

```text
build_exe.bat
```

Output:

```text
dist\OpenSourceITTool.exe
```

## Developer notes

- Keep destructive actions behind confirmation prompts.
- Keep driver updates conservative until official vendor/OEM update flows are added.
- Keep review-only locations separate from cleanable locations.
- Avoid cleaning personal folders automatically.
- Keep logs plain text for support workflows.


## v0.8.2 admin and consumer UI pass

- Startup now requests Administrator mode on Windows.
- The packaged EXE build uses a UAC admin manifest.
- The app cannot bypass UAC; Windows still requires approval.
- Header now shows Administrator Mode status.
- Removed harsh red cleanup buttons and replaced them with warning-styled action buttons.
- Renamed some UI buttons for consumers:
  - Scan PC
  - Update Apps
  - Windows Update
  - Report
- Cleaner wording is more consumer-friendly while keeping More Info for technical details.


## v0.8.3 consumer UI and confirmation pass

- Added Home dashboard with large action cards:
  - Update Apps
  - Clean PC
  - Check Health
  - Repair Tools
- Added plain-English dashboard status after scanning.
- Added custom confirmation dialogs for updates, cleanup, and toolkit actions.
- Confirmation dialogs now explain exactly what will happen before the action runs.
- Generic question-mark prompts have been replaced with review-style confirmation text.
- Cleaner still provides a simple summary first and deeper technical detail in More Info.


## v0.8.4 refined driver update comparison

- Added a dedicated Driver Updates tab.
- Added Scan Driver Updates action.
- Shows installed driver version and installed driver date.
- Shows available driver version and available driver date when Windows Update reports one.
- Shows match confidence between installed device and available driver update.
- Shows installed INF/provider, update ID, source, and support/vendor links in Details.
- Driver installation is still disabled until rollback/restore-point handling is added.


## v0.8.5 automated driver update workflow

- Added Driver Updates tab if it was not already present in the UI build.
- Added Scan Driver Updates.
- Added Auto Update Drivers.
- Runs with one confirmation, then automates the workflow.
- Attempts to create a restore point.
- Exports current installed drivers to `driver_backups/`.
- Installs only driver updates reported by Windows Update.
- Saves a plain-text driver update log.
- Shows rollback notes after the workflow finishes.
- Automatically refreshes the Driver Updates comparison after completion.

The workflow uses official Windows Update driver updates only. It does not scrape driver websites or download unknown installers.


## v0.9 UI refactor

- Replaced dark mode with the #D5E3E8 light theme.
- Replaced top-tab clutter with left sidebar navigation.
- Added dedicated pages:
  - Home
  - Updates
  - Drivers
  - Cleaner
  - Health
  - Repair
  - Reports
  - More Info
  - Settings
- Home is now a guided dashboard instead of a raw table.
- Technical details are hidden by default and shown in More Info.
- Added progress bars with percentages for:
  - PC scans
  - app updates
  - cleaner analysis and cleanup
  - driver comparison
  - automated driver update workflow
  - health checks
  - toolkit actions
- Added Health page with pending reboot, Defender, firewall, disk, battery, TPM, and Secure Boot checks.


## v0.9.1 UI and scan refinement

- Removed the global Scan PC button from the top of every page.
- Added dedicated action buttons inside the pages where they belong.
- Updates page now shows app and Windows Update rows only.
- Driver rows stay in the Drivers page.
- Progress bar now uses task-specific wording.
- Idle progress text appears when a task has not started and disappears once a task begins.
- Windows Update scan fallback now gives a useful manual-review row instead of a vague unavailable result.
- Home cards now update with simple counts after scans.


## v0.9.2 UI and scanner refinement

- Home was changed to a CCleaner-style status page instead of duplicating sidebar actions.
- Removed the global Scan PC button from the top area.
- Added page-specific scan/action buttons.
- Updates page uses an app/Windows Update-only scanner.
- Driver inventory and comparison stay in the Drivers page.
- Progress status is task-specific and includes idle text when nothing has started.
- Windows Update scan fallback now returns an actionable manual-review row with a Windows Update Settings link instead of a vague unavailable result.


## v0.9.4 stability review

- Fixed the most likely crash source: starting the same QThread task twice.
- Added guards so scans, updates, cleaner tasks, health checks, driver workflows, and repair tools cannot overwrite a running worker.
- Made progress labels task-specific across pages.
- Fixed app update completion progress label.
- Hardened report export and folder-opening actions.
- Hardened repair/toolkit action runner so command failures return readable output instead of bubbling exceptions.
- Increased timeouts for long repair commands like SFC and DISM.
- Hardened Recycle Bin cleanup when PowerShell is unavailable.


## v0.9.5 section progress and stability pass

- Replaced the shared global progress bar with separate progress bars per section.
- Added dedicated progress bars for Home, Updates, Drivers, Cleaner, Health, and Repair.
- Cleaner analysis is now bounded by item count and time so it should not hang/crash while scanning large folders.
- Missing environment paths no longer accidentally scan the current folder.
- Browser cache analysis skips missing environment roots cleanly.
- Driver scan uses shorter Windows Update timeouts.
- Driver results are bounded so huge driver inventories do not overload the table.
- PowerShell commands now request hidden windows where possible.
- The old interactive BAT menu is disabled inside the app to avoid external console windows and hangs.


## v0.9.6 CCleaner-inspired UI pass

- Added `assets/AIO.ico`.
- App window now uses the uploaded icon.
- PyInstaller build uses the uploaded icon for the EXE.
- Added a CCleaner-inspired dark left navigation rail.
- Added a CCleaner-inspired top product header.
- Kept the requested color palette, including `#D5E3E8`.
- Made cards, tables, buttons, and progress bars more rectangular and utility-style.
- Logo is shown in the top-left brand area and product header.


## v0.9.7 table routing and icon sharpness fix

- Fixed Updates double-click/details routing after table sorting.
- Each table item now stores its real data index with `Qt.UserRole`.
- Driver table details use the same stable row-index fix.
- Rebuilt the uploaded icon into a multi-size ICO.
- Added `AIO_original.ico` for reference and regenerated `AIO.ico`.
- Added `AIO_256.png`.
- Logo rendering now uses `QIcon.pixmap()` instead of scaling the ICO directly.


## v0.9.8 crash logging and diagnostics

- Added `core/diagnostics.py`.
- Added global Python exception hook.
- Added thread exception hook.
- Added Qt message handler.
- Added last-action tracking.
- Added per-action diagnostic logs.
- Added system snapshot logging.
- Added Support ZIP export in Reports.
- Support ZIP includes diagnostics, logs, system snapshot, project metadata, and last-action data.
- Worker thread exceptions now write diagnostics before returning readable output to the UI.


## v0.9.9 UI consistency and workflow cleanup

- Removed build-environment smoke logs and support ZIPs from the final package.
- Added consistent section headers to major pages.
- Standardized primary, secondary, and warning button roles.
- Made Reports, Cleaner, Updates, Drivers, Health, and Repair page wording more consistent.
- Standardized More Info output formatting for updates, drivers, and repair actions.
- Improved confirmation dialog wording.
- Preserved the CCleaner-inspired visual style and `#D5E3E8` palette.
