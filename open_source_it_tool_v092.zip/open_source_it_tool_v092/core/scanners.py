from __future__ import annotations

import csv
import json
import os
import platform
import re
import subprocess
from dataclasses import dataclass
from typing import Callable, Dict, List, Tuple

from core.config import Config
from core.models import UpdateRow
from core.vendors import detect_vendor


Progress = Callable[[str], None]


def is_windows() -> bool:
    return platform.system().lower() == "windows"


def creationflags() -> int:
    return subprocess.CREATE_NO_WINDOW if os.name == "nt" else 0


def run_cmd(args: List[str], timeout: int) -> Tuple[str, bool, str]:
    try:
        result = subprocess.run(
            args,
            capture_output=True,
            text=True,
            timeout=timeout,
            encoding="utf-8",
            errors="replace",
            creationflags=creationflags(),
        )
        out = result.stdout or ""
        if result.stderr:
            out += "\n" + result.stderr
        return out.strip(), False, ""
    except subprocess.TimeoutExpired:
        return "", True, f"Timed out after {timeout} seconds"
    except FileNotFoundError:
        return "", False, f"{args[0]} was not found"
    except Exception as exc:
        return "", False, str(exc)


def run_powershell(script: str, timeout: int) -> Tuple[str, bool, str]:
    if not is_windows():
        return "", False, "Not running on Windows"
    return run_cmd(
        ["powershell.exe", "-NoProfile", "-ExecutionPolicy", "Bypass", "-Command", script],
        timeout=timeout,
    )


def clean(value) -> str:
    return re.sub(r"\s+", " ", str(value or "").replace("\r", " ").replace("\n", " ")).strip()


def normalize_json(raw: str):
    raw = (raw or "").strip()
    if not raw:
        return None
    starts = [i for i in (raw.find("{"), raw.find("[")) if i >= 0]
    if starts:
        raw = raw[min(starts):]
    try:
        return json.loads(raw)
    except json.JSONDecodeError:
        return None


def as_list(value) -> list:
    if value is None:
        return []
    if isinstance(value, list):
        return value
    if isinstance(value, dict):
        return [value]
    return []


def risk_for(row: UpdateRow) -> str:
    text = " ".join([row.item_type, row.name, row.details, row.latest_version]).lower()
    if row.update_status == "WARNING":
        return "Warning"
    if re.search(r"security|cve|vulnerability|critical|defender|malware|exploit|cumulative", text):
        return "Security"
    if re.search(r"firmware|bios|uefi|microcode", text):
        return "Firmware"
    if row.item_type.lower() == "driver" or "driver" in text:
        return "Driver"
    if re.search(r"fix|bug|crash|stability|performance|reliability|quality", text):
        return "Stability"
    if re.search(r"feature|new|added|introduces", text):
        return "Feature"
    return "Unknown"


def warning_row(name: str, details: str, source: str) -> UpdateRow:
    return UpdateRow(
        item_type="Warning",
        name=name,
        current_version="N/A",
        latest_version="N/A",
        update_available=False,
        update_status="WARNING",
        source=source,
        risk="Warning",
        confidence="Scanner warning",
        details=details,
    )


# -------------------------
# Programs
# -------------------------

def scan_installed_programs(progress: Progress | None, config: Config) -> List[UpdateRow]:
    if progress:
        progress("Reading installed programs...")

    if not is_windows():
        return [warning_row("Installed program scan unavailable", "This scan requires Windows.", "Registry")]

    rows: List[UpdateRow] = []

    try:
        import winreg

        hives = [
            (winreg.HKEY_LOCAL_MACHINE, r"Software\Microsoft\Windows\CurrentVersion\Uninstall"),
            (winreg.HKEY_LOCAL_MACHINE, r"Software\WOW6432Node\Microsoft\Windows\CurrentVersion\Uninstall"),
            (winreg.HKEY_CURRENT_USER, r"Software\Microsoft\Windows\CurrentVersion\Uninstall"),
        ]

        seen = set()
        for hive, subkey in hives:
            try:
                root = winreg.OpenKey(hive, subkey)
                count = winreg.QueryInfoKey(root)[0]
            except OSError:
                continue

            for i in range(count):
                try:
                    child_name = winreg.EnumKey(root, i)
                    child = winreg.OpenKey(root, child_name)

                    def q(name: str) -> str:
                        try:
                            return clean(winreg.QueryValueEx(child, name)[0])
                        except OSError:
                            return ""

                    name = q("DisplayName")
                    if not name or q("SystemComponent") == "1":
                        continue

                    version = q("DisplayVersion")
                    publisher = q("Publisher")
                    key = (name.lower(), version.lower(), publisher.lower())
                    if key in seen:
                        continue
                    seen.add(key)

                    vendor, vendor_link = detect_vendor(name, publisher)
                    row = UpdateRow(
                        item_type="App",
                        name=name,
                        current_version=version,
                        latest_version="",
                        update_available=False,
                        update_status="NO",
                        source="Registry",
                        vendor=vendor,
                        vendor_link=vendor_link,
                        confidence="Installed app inventory. No update detected yet.",
                        details=f"Publisher: {publisher}\nInstall date: {q('InstallDate')}\nRegistry key: {child_name}",
                    )
                    rows.append(row)
                except OSError:
                    continue

        return sorted(rows, key=lambda r: r.name.lower())

    except Exception as exc:
        return [warning_row("Installed program scan failed", str(exc), "Registry")]


def parse_winget_upgrade_table(raw: str) -> Dict[str, UpdateRow]:
    lines = [line.rstrip() for line in (raw or "").splitlines() if line.strip()]
    header_idx = -1
    for i, line in enumerate(lines):
        if re.match(r"^Name\s+Id\s+Version\s+Available\s+Source", line):
            header_idx = i
            break
    if header_idx < 0:
        return {}

    dash_idx = -1
    for i in range(header_idx + 1, len(lines)):
        if re.match(r"^-{2,}", lines[i]):
            dash_idx = i
            break
    if dash_idx < 0:
        return {}

    matches = list(re.finditer(r"-+", lines[dash_idx]))
    if len(matches) < 5:
        return {}

    starts = [m.start() for m in matches]

    def col(line: str, start: int, end: int | None = None) -> str:
        if len(line) <= start:
            return ""
        if end is None or end > len(line):
            return line[start:].strip()
        return line[start:end].strip()

    updates = {}
    for line in lines[dash_idx + 1:]:
        if re.search(r"\bupgrades?\s+available\b", line, re.I):
            break
        name = col(line, starts[0], starts[1])
        package_id = col(line, starts[1], starts[2])
        current = col(line, starts[2], starts[3])
        latest = col(line, starts[3], starts[4])
        source = col(line, starts[4], None)
        if not name or not latest:
            continue

        vendor, vendor_link = detect_vendor(name, package_id)
        row = UpdateRow(
            item_type="App",
            name=name,
            current_version=current,
            latest_version=latest,
            update_available=True,
            update_status="YES",
            source=source or "winget",
            vendor=vendor,
            vendor_link=vendor_link,
            confidence="Update detected by winget.",
            raw_id=package_id,
            details=f"Package ID: {package_id}\nSource: {source or 'winget'}",
        )
        row.risk = risk_for(row)
        updates[name.lower()] = row
        if package_id:
            updates[package_id.lower()] = row
    return updates


def apply_winget_updates(rows: List[UpdateRow], progress: Progress | None, config: Config) -> List[UpdateRow]:
    if not config.get_bool("scan_apps"):
        return rows

    if progress:
        progress("Checking app updates with winget...")

    raw, timed_out, err = run_cmd(
        ["winget", "upgrade", "--accept-source-agreements", "--disable-interactivity"],
        timeout=config.get_int("winget_timeout"),
    )

    if timed_out:
        rows.append(warning_row("winget scan timed out", err, "winget"))
        return rows
    if err:
        rows.append(warning_row("winget scan unavailable", err, "winget"))
        return rows

    updates = parse_winget_upgrade_table(raw)

    def norm_name(value: str) -> str:
        value = re.sub(r"[^a-z0-9]+", " ", (value or "").lower())
        noise = {"microsoft", "corporation", "inc", "llc", "ltd", "app", "application"}
        return " ".join([p for p in value.split() if p not in noise])

    # Mark matching installed apps YES. Leave everything else NO.
    matched_update_names = set()
    for row in rows:
        if row.item_type != "App":
            continue

        candidates = [row.name.lower(), norm_name(row.name)]
        found_key = None

        for candidate in candidates:
            if candidate in updates:
                found_key = candidate
                break

        if not found_key:
            row_norm = norm_name(row.name)
            for upd in set(updates.values()):
                upd_norm = norm_name(upd.name)
                if row_norm and upd_norm and (row_norm in upd_norm or upd_norm in row_norm):
                    found_key = upd.name.lower()
                    updates[found_key] = upd
                    break

        if found_key and found_key in updates:
            upd = updates[found_key]
            row.update_available = True
            row.update_status = "YES"
            row.latest_version = upd.latest_version
            row.source = "Registry + winget"
            row.raw_id = upd.raw_id
            row.update_link = upd.update_link
            row.vendor = row.vendor or upd.vendor
            row.vendor_link = row.vendor_link or upd.vendor_link
            row.confidence = "Installed app matched to winget update."
            row.details += f"\n\nUpdate detected by winget.\nLatest version: {upd.latest_version}\nPackage ID: {upd.raw_id}"
            row.risk = risk_for(row)
            matched_update_names.add(upd.name.lower())

    # Add winget update rows that did not match registry inventory.
    existing_names = {r.name.lower() for r in rows}
    for upd in set(updates.values()):
        if upd.name.lower() not in existing_names and upd.name.lower() not in matched_update_names:
            rows.append(upd)
            existing_names.add(upd.name.lower())

    return rows


# -------------------------
# Drivers
# -------------------------

def scan_drivers(progress: Progress | None, config: Config) -> List[UpdateRow]:
    if not config.get_bool("scan_drivers"):
        return []

    if progress:
        progress("Reading installed drivers...")

    script = r"""
$drivers = Get-CimInstance Win32_PnPSignedDriver -ErrorAction SilentlyContinue |
  Where-Object { $_.DeviceName } |
  Select-Object DeviceName, DriverVersion, Manufacturer, DriverDate, InfName, DeviceClass
$drivers | ConvertTo-Json -Depth 4
"""
    raw, timed_out, err = run_powershell(script, timeout=config.get_int("driver_timeout"))
    if timed_out:
        return [warning_row("Driver scan timed out", err, "WMI")]
    if err and err != "Not running on Windows":
        return [warning_row("Driver scan failed", err, "WMI")]

    data = as_list(normalize_json(raw))
    rows: List[UpdateRow] = []
    seen = set()

    for d in data:
        name = clean(d.get("DeviceName", ""))
        if not name:
            continue
        version = clean(d.get("DriverVersion", ""))
        manufacturer = clean(d.get("Manufacturer", ""))
        inf = clean(d.get("InfName", ""))
        driver_class = clean(d.get("DeviceClass", ""))
        key = (name.lower(), version.lower(), inf.lower())
        if key in seen:
            continue
        seen.add(key)

        vendor, vendor_link = detect_vendor(name, manufacturer, inf, driver_class)
        row = UpdateRow(
            item_type="Driver",
            name=name,
            current_version=version,
            latest_version="",
            update_available=False,
            update_status="NO",
            source="Win32_PnPSignedDriver",
            vendor=vendor,
            vendor_link=vendor_link,
            confidence="Installed driver inventory. No update detected yet.",
            details=f"Manufacturer: {manufacturer}\nDriver date: {clean(d.get('DriverDate', ''))}\nINF: {inf}\nClass: {driver_class}",
        )
        row.risk = risk_for(row)
        rows.append(row)

    if rows:
        return sorted(rows, key=lambda r: r.name.lower())

    # Fallback to driverquery if WMI returns nothing
    if progress:
        progress("WMI returned no drivers. Trying driverquery fallback...")

    raw2, timed_out2, err2 = run_cmd(["driverquery", "/v", "/fo", "csv"], timeout=45)
    if timed_out2 or err2:
        return [warning_row("Driver fallback failed", err2 or "driverquery timed out", "driverquery")]

    try:
        reader = csv.DictReader(raw2.splitlines())
        for r in reader:
            name = clean(r.get("Display Name", "") or r.get("Module Name", ""))
            if not name:
                continue
            vendor, vendor_link = detect_vendor(name, r.get("Module Name", ""))
            rows.append(UpdateRow(
                item_type="Driver",
                name=name,
                current_version="",
                latest_version="",
                update_available=False,
                update_status="NO",
                source="driverquery",
                vendor=vendor,
                vendor_link=vendor_link,
                confidence="Fallback driver inventory. Version may not be available.",
                details=f"Module: {clean(r.get('Module Name', ''))}\nType: {clean(r.get('Driver Type', ''))}\nLink date: {clean(r.get('Link Date', ''))}",
            ))
    except Exception as exc:
        return [warning_row("Driver fallback parse failed", str(exc), "driverquery")]

    return sorted(rows, key=lambda r: r.name.lower())


# -------------------------
# Windows Update optional matching
# -------------------------


def scan_windows_update_fallback(error: str = "") -> UpdateRow:
    """Return an actionable Windows Update row when automatic scan is blocked."""
    if not is_windows():
        details = "Windows Update scanning is only available on Windows."
        if error:
            details += "\n\nTechnical error:\n" + error
        return UpdateRow(
            update_status="WARNING",
            item_type="Windows Update",
            name="Windows Update",
            current_version="Not running on Windows",
            latest_version="Unavailable",
            update_available=False,
            vendor="Microsoft",
            source="Windows Update",
            risk="Info",
            confidence="Not available",
            update_link="ms-settings:windowsupdate",
            notes_link="ms-settings:windowsupdate",
            details=details,
        )

    details = (
        "The automatic Windows Update scan could not complete. "
        "This is commonly caused by Windows Update services being busy, "
        "disabled, restricted by policy, or still initializing. "
        "Open Windows Update Settings, check for updates manually, then scan again."
    )
    if error:
        details += "\n\nTechnical error:\n" + error

    return UpdateRow(
        update_status="WARNING",
        item_type="Windows Update",
        name="Windows Update needs manual review",
        current_version="Scanner fallback",
        latest_version="Open Settings",
        update_available=False,
        vendor="Microsoft",
        source="Windows Update",
        risk="Review",
        confidence="Fallback",
        update_link="ms-settings:windowsupdate",
        notes_link="ms-settings:windowsupdate",
        details=details,
    )



def scan_windows_update(progress: Progress | None, config: Config, existing_rows: List[UpdateRow]) -> List[UpdateRow]:
    if not config.get_bool("scan_windows_update"):
        return [UpdateRow(
            item_type="Windows Update",
            name="Windows Update scan",
            current_version="Disabled",
            latest_version="Not checked",
            update_available=False,
            update_status="NO",
            source="Settings",
            risk="Unknown",
            confidence="Windows Update scanning is currently turned off.",
            details="Turn Windows Update scanning ON from the header button to include Windows Update results.",
            update_link="ms-settings:windowsupdate",
            notes_link="ms-settings:windowsupdate",
        )]

    if progress:
        progress("Checking Windows Update...")

    script = r"""
try {
  $session = New-Object -ComObject Microsoft.Update.Session
  $searcher = $session.CreateUpdateSearcher()
  $result = $searcher.Search("IsInstalled=0 and IsHidden=0")
  $items = @()
  for ($i = 0; $i -lt $result.Updates.Count; $i++) {
    $u = $result.Updates.Item($i)
    $cats = @()
    foreach ($cat in $u.Categories) { if ($cat.Name) { $cats += [string]$cat.Name } }
    $urls = @()
    foreach ($url in $u.MoreInfoUrls) { if ($url) { $urls += [string]$url } }
    $items += [pscustomobject]@{
      Title = [string]$u.Title
      Description = [string]$u.Description
      TypeNumber = [int]$u.Type
      Categories = $cats
      SupportUrl = [string]$u.SupportUrl
      MoreInfoUrls = $urls
      UpdateID = [string]$u.Identity.UpdateID
    }
  }
  $items | ConvertTo-Json -Depth 5
}
catch {
  @([pscustomobject]@{
    Title = "Windows Update scan failed"
    Description = $_.Exception.Message
    TypeNumber = -1
    Categories = @("Error")
    SupportUrl = ""
    MoreInfoUrls = @()
    UpdateID = ""
  }) | ConvertTo-Json -Depth 4
}
"""
    raw, timed_out, err = run_powershell(script, timeout=config.get_int("windows_update_timeout"))
    if timed_out:
        return [scan_windows_update_fallback(err)]
    if err == "Not running on Windows":
        return [scan_windows_update_fallback("Windows Update scanning requires Windows.")]
    if err:
        return [scan_windows_update_fallback(err)]

    results = []
    for u in as_list(normalize_json(raw)):
        title = clean(u.get("Title", ""))
        if not title:
            continue
        cats = u.get("Categories", [])
        if isinstance(cats, str):
            cats = [cats]
        is_error = "error" in [str(c).lower() for c in cats] or "scan failed" in title.lower()
        if is_error:
            results.append(scan_windows_update_fallback(clean(u.get("Description", "")) or title))
            continue

        is_driver = str(u.get("TypeNumber", "")) == "2" or "driver" in title.lower() or "drivers" in [str(c).lower() for c in cats]
        item_type = "Driver" if is_driver else "Windows Update"
        status = "YES"
        update_available = True

        urls = u.get("MoreInfoUrls", [])
        if isinstance(urls, str):
            urls = [urls]
        link = next((str(x) for x in urls if x), "") or clean(u.get("SupportUrl", "")) or "ms-settings:windowsupdate"
        vendor, vendor_link = detect_vendor(title, clean(u.get("Description", "")))

        row = UpdateRow(
            item_type=item_type,
            name=title,
            current_version="Not installed / Windows component" if not is_driver else "Unknown / no safe match",
            latest_version=version_from_title(title),
            update_available=update_available,
            update_status=status,
            source="Windows Update",
            vendor=vendor,
            vendor_link=vendor_link,
            update_link=link,
            notes_link=link,
            confidence="Reported by Windows Update.",
            details=clean(u.get("Description", "")),
            raw_id=clean(u.get("UpdateID", "")),
        )
        row.risk = risk_for(row)
        results.append(row)

    if not results:
        results.append(UpdateRow(
            item_type="Windows Update",
            name="Windows Update",
            current_version="System checked",
            latest_version="No updates detected",
            update_available=False,
            update_status="NO",
            source="Windows Update",
            risk="Unknown",
            confidence="Windows Update scan completed and did not report available updates.",
            details="Windows Update search completed successfully. No available Windows Update items were returned.",
            update_link="ms-settings:windowsupdate",
            notes_link="ms-settings:windowsupdate",
        ))

    return results


def version_from_title(title: str) -> str:
    m = re.search(r"\b\d+(?:\.\d+){1,5}\b", title or "")
    return m.group(0) if m else clean(title)


# -------------------------
# Full scan
# -------------------------


def scan_updates_only(progress: Progress | None = None) -> List[UpdateRow]:
    """Scan app updates and Windows Update items only.

    Driver inventory and driver update comparison are handled by the Drivers page.
    """
    config = Config()
    rows: List[UpdateRow] = []

    rows.extend(scan_installed_programs(progress, config))
    rows = apply_winget_updates(rows, progress, config)
    rows.extend(scan_windows_update(progress, config, rows))

    for row in rows:
        row.risk = risk_for(row)

    return rows

def scan_all(progress: Progress | None = None) -> List[UpdateRow]:
    config = Config()
    rows: List[UpdateRow] = []

    rows.extend(scan_installed_programs(progress, config))
    rows = apply_winget_updates(rows, progress, config)

    rows.extend(scan_drivers(progress, config))
    rows.extend(scan_windows_update(progress, config, rows))

    for row in rows:
        if row.update_status == "YES":
            row.update_available = True
        elif row.update_status == "NO":
            row.update_available = False
        row.risk = risk_for(row)

    # Show all rows. User specifically wants NO rows visible.
    return rows
