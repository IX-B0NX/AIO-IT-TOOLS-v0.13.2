import sys

from core.admin import should_request_admin, relaunch_as_admin
from core.diagnostics import install_global_exception_hook, log_exception, set_last_action
from ui.main_window import run_app


if __name__ == "__main__":
    ensure_runtime_dirs()
    install_global_exception_hook()
    set_last_action("Launcher started")

    try:
        if should_request_admin():
            set_last_action("Requesting administrator elevation")
            if relaunch_as_admin():
                sys.exit(0)

        set_last_action("Starting UI")
        run_app()
    except Exception:
        log_exception("main launcher")
        raise
