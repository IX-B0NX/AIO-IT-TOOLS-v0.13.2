@echo off
setlocal
cd /d "%~dp0"

echo Building AIO IT TOOLS single EXE...
echo.

python -m pip install --upgrade pip
python -m pip install -r requirements.txt
python -m pip install pyinstaller

if exist build rmdir /s /q build
if exist dist rmdir /s /q dist
if exist AIOITTools.spec del AIOITTools.spec

pyinstaller ^
  --noconfirm ^
  --clean ^
  --onefile ^
  --windowed ^
  --uac-admin ^
  --name "AIOITTools" ^
  --icon "assets\AIO_IT_TOOLS.ico" ^
  --add-data "assets;assets" ^
  main.py

echo.
echo Build complete.
echo Consumer EXE:
echo dist\AIOITTools.exe
echo.
pause
