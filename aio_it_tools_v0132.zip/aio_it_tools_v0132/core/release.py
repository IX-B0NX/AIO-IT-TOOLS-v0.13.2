from __future__ import annotations

APP_PUBLIC_VERSION = "0.13.2"
RELEASE_CHANNEL = "Gold Master"

RELEASE_WARNING = """
AIO IT TOOLS is ready for final validation.

Safety and privacy choices:
- Source code remains readable and reviewable.
- Sensitive values are redacted from logs and Support ZIPs.
- Wi-Fi passwords are shown only on demand and are not stored by the app.
- Driver automation requires review and high-confidence matches.
""".strip()

KNOWN_ISSUES = [
    {
        "area": "Windows Update policy restrictions",
        "severity": "Notice",
        "status": "External Windows/policy dependency",
        "issue": "Automatic scan can still fail on PCs where Windows Update is disabled, restricted by organization policy, or broken outside this app.",
        "workaround": "Use Check Update Health, Repair Windows Update Services, then open Windows Update manually if policy still blocks scanning.",
    },
    {
        "area": "Optional winget provider",
        "severity": "Notice",
        "status": "Optional Microsoft App Installer provider",
        "issue": "App update automation uses winget when available. If winget is missing or blocked, the app still provides diagnostics and repair guidance.",
        "workaround": "Use Open App Installer, Repair winget Sources, or manually update apps from the vendor/Microsoft Store.",
    },
    {
        "area": "Unsigned build",
        "severity": "Notice",
        "status": "Expected for unsigned distribution",
        "issue": "Unsigned builds may trigger Windows SmartScreen or antivirus reputation prompts.",
        "workaround": "Run from source, build locally, or use executables from a trusted source.",
    },
    {
        "area": "Windows-only Wi-Fi password display",
        "severity": "Notice",
        "status": "External Windows/netsh behavior",
        "issue": "Wi-Fi password display depends on Windows netsh/admin/security policy and may not show keys for every profile.",
        "workaround": "Run as administrator and verify output in Repair > Wi-Fi Profiles + Passwords.",
    },
]


def known_issues_text() -> str:
    lines = ["System Notes", "============", ""]
    for item in KNOWN_ISSUES:
        lines.append(f"[{item['severity']}] {item['area']} — {item.get('status', 'Tracked')}")
        lines.append(f"  Note: {item['issue']}")
        lines.append(f"  Action: {item['workaround']}")
        lines.append("")
    return "\n".join(lines).strip()
