from __future__ import annotations

from core.release import (
    APP_PUBLIC_VERSION,
    RELEASE_CHANNEL,
    RELEASE_WARNING,
    KNOWN_ISSUES,
    known_issues_text,
)

# Backwards-compatible name for older app code.
BETA_WARNING = RELEASE_WARNING
