# AIO IT TOOLS Distribution Notes

## Consumer goal

The consumer-facing release should eventually be only:

```text
dist\AIOITTools.exe
```

No source files, README, assets folder, logs folder, support_zips folder, or build scripts should be distributed to normal users.

## Why no installer yet

A single EXE is better for local testing and review:

```text
Download EXE
Run as administrator
Use app
Delete EXE to remove it
```

An installer is optional later only if the app needs Start Menu shortcuts, uninstall entries, auto-update infrastructure, or code-signed installer trust flow.

## Runtime data in single-EXE mode

When compiled, writable runtime files are created under:

```text
%LOCALAPPDATA%\AIOITTools
```

Runtime folders:

```text
logs
support_zips
driver_backups
```

## Build

Run:

```bat
build_exe.bat
```

Expected output:

```text
dist\AIOITTools.exe
```

## Current distribution note

Unsigned EXEs may trigger Windows SmartScreen or antivirus reputation prompts until code signing is added.


## Project distribution

For this project, source distribution is preferred. The EXE is optional.

Recommended project package:
- source code ZIP
- README
- screenshots
- optional locally built EXE

Do not pay for a code-signing certificate unless this becomes a real public product.
