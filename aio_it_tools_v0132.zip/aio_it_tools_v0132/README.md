# AIO IT TOOLS v0.13.2

**AIO IT TOOLS** is a Windows maintenance and diagnostics utility built with Python and PySide6.

It combines app update checks, Windows Update health checks, driver review workflows, cleanup tools, repair tools, reports, runtime diagnostics, and Support ZIP export into a polished desktop interface.

## Purpose

AIO IT TOOLS is designed to provide a clean, centralized interface for common Windows maintenance and troubleshooting tasks.

The project demonstrates:

- Windows desktop utility design
- PySide6 GUI development
- background worker/thread design
- Windows command integration
- safer repair workflows
- logging and diagnostics
- user-focused UI iteration
- privacy-aware support export
- practical system administration tooling

## Source transparency

The source code is intentionally kept readable and reviewable.

No code obfuscation is used. Instead, the project focuses on:

- clear structure
- safe defaults
- transparent Windows commands
- privacy-safe logging
- readable documentation

## Privacy and safety choices

AIO IT TOOLS does **not** store Wi-Fi passwords.

When Wi-Fi profile passwords are shown, they are retrieved locally from Windows `netsh` only after administrator approval. Sensitive values are redacted from Support ZIP/log output where possible.

Privacy layer:

- `core/privacy.py`
- redacts Wi-Fi key content
- redacts common password/token/key patterns
- applies redaction to Support ZIP text output
- keeps code readable instead of hidden

## Features

- Home dashboard
- App update scan
- Optional winget update provider
- Windows Update health checks
- Conservative Windows Update service repair
- Driver update comparison
- Driver review and guarded automation
- Cleaner with safe defaults
- Advanced cleanup toggle
- Repair tools with advanced toggle
- Wi-Fi profiles and local password display
- Health scan page
- Reports
- Runtime self-test
- Support ZIP export
- System Notes page

## Tech stack

- Python
- PySide6
- Windows command-line tools
- PowerShell integration
- PyInstaller build support

## Running from source

```bat
run_aio_it_tools.bat
```

The launcher checks for PySide6 and installs requirements if needed.

## Building the EXE

```bat
build_exe.bat
```

Expected output:

```text
dist\AIOITTools.exe
```

## Unsigned build note

This build is unsigned. Windows may show a SmartScreen warning for unsigned executables.

Running from source or building locally is recommended when reviewing or testing the project.

## Optional winget provider

AIO IT TOOLS uses winget when available. If winget is missing or blocked, the app still provides diagnostics, repair guidance, and App Installer repair links.

This makes winget an optional provider rather than a hard requirement.

## System Notes

The remaining System Notes are external Windows or deployment dependencies:

- Windows Update policy restrictions
- Optional winget provider behavior
- Unsigned build reputation
- Windows-only Wi-Fi password display behavior

## Recommended screenshots

Useful screenshots for documentation:

1. Home dashboard
2. Updates page
3. Drivers page with review workflow
4. Cleaner page with advanced toggle enabled
5. Repair page with advanced toggle enabled
6. Health page
7. Reports page
8. System Notes page
