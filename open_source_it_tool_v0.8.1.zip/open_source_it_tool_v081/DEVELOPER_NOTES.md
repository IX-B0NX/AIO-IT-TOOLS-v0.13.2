# Developer Notes

## v0.8.1 cleanup pass

- Removed production debug artifacts from the package.
- Added plain-text command logs under `logs/`.
- Tightened `Update Detected Apps` so it processes scanned winget rows instead of running a blind global update.
- Broadened Cleaner analysis for consumer use.
- Added a More Info tab for technical cleaner detail.
- Added cleaner targets for browser cache, crash dumps, Windows Update cache review, and personal-folder review.
- Added table repaint suppression while loading rows.
- Left driver updates as detection/manual-vendor-link only.

## Safety decisions

- Personal folders are review-only.
- Windows Update download cache is review-only until a proper service-stop workflow is added.
- Browser cache cleanup skips locked files.
- Cleaner actions are confirmation-gated.
- Package updates are limited to detected winget package IDs.
