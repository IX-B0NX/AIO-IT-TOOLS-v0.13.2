# Open Source IT Tool v0.8.1

created by ฿0₦Ӿ

Professional Windows update, cleanup, and IT maintenance utility.

## Main features

- Dark glass desktop interface
- Full app/driver/update inventory
- Green YES for available updates
- Red NO for no update detected
- Orange WARNING for scanner issues
- Direct app updating through winget
- Update Selected
- Update Detected Apps
- Consumer-friendly Cleaner tab
- More Info tab for technical cleanup details
- AIO Toolkit tab with repair and diagnostic actions
- Logs saved under `logs/`
- CSV and HTML report export

## Cleaner design

The Cleaner tab shows a consumer-friendly summary first.

It separates results into:

- Safe cleanup estimate
- Review-only storage
- Browser and privacy cache
- Windows cleanup
- Diagnostics cleanup
- Personal file review

The More Info tab shows:

- full paths
- risk labels
- cleanup status
- estimated size
- notes for each target

## Direct update behavior

Direct updates currently support winget app updates only.

`Update Selected` updates the selected YES app row when it has a winget package ID.

`Update Detected Apps` processes only the winget app updates detected in the current scan. It does not blindly run a full package-manager update against items that were not shown in the table.

## Run

```text
run_open_source_it_tool.bat
```

## Build portable EXE

```text
build_exe.bat
```

Output:

```text
dist\OpenSourceITTool.exe
```

## Developer notes

- Keep destructive actions behind confirmation prompts.
- Keep driver updates conservative until official vendor/OEM update flows are added.
- Keep review-only locations separate from cleanable locations.
- Avoid cleaning personal folders automatically.
- Keep logs plain text for support workflows.
