from __future__ import annotations

import json
import platform
import sys
import threading
import traceback
import zipfile
from datetime import datetime
from pathlib import Path
from typing import Any

from core.config import app_dir


APP_VERSION = "0.10.3"
_LAST_ACTION = "App started"
_PREVIOUS_EXCEPTHOOK = None
_PREVIOUS_THREADING_EXCEPTHOOK = None


def now_stamp() -> str:
    return datetime.now().strftime("%Y%m%d_%H%M%S")


def logs_root() -> Path:
    path = app_dir() / "logs"
    path.mkdir(parents=True, exist_ok=True)
    return path


def diagnostics_root() -> Path:
    path = logs_root() / "diagnostics"
    path.mkdir(parents=True, exist_ok=True)
    return path


def support_root() -> Path:
    path = app_dir() / "support_zips"
    path.mkdir(parents=True, exist_ok=True)
    return path


def daily_diagnostics_file() -> Path:
    return diagnostics_root() / f"diagnostics_{datetime.now().strftime('%Y%m%d')}.log"


def safe_admin_status() -> str:
    try:
        from core.admin import is_admin
        return "admin" if is_admin() else "limited"
    except Exception:
        return "unknown"


def get_last_action() -> str:
    return _LAST_ACTION


def system_snapshot() -> dict[str, Any]:
    return {
        "app": "Open Source IT Tool",
        "app_version": APP_VERSION,
        "timestamp": datetime.now().isoformat(timespec="seconds"),
        "admin_status": safe_admin_status(),
        "platform": platform.platform(),
        "system": platform.system(),
        "release": platform.release(),
        "version": platform.version(),
        "machine": platform.machine(),
        "processor": platform.processor(),
        "python": sys.version,
        "frozen": bool(getattr(sys, "frozen", False)),
        "executable": sys.executable,
        "cwd": str(Path.cwd()),
        "app_dir": str(app_dir()),
        "argv": sys.argv,
        "last_action": get_last_action(),
    }


def write_json(path: Path, payload: dict[str, Any]) -> None:
    path.write_text(json.dumps(payload, indent=2, default=str), encoding="utf-8")


def log_event(kind: str, message: str, details: str = "") -> Path:
    path = daily_diagnostics_file()
    snapshot = system_snapshot()
    entry = [
        "=" * 88,
        f"{datetime.now().isoformat(timespec='seconds')} | {kind}",
        f"Message: {message}",
        f"Last action: {get_last_action()}",
        f"Admin: {snapshot.get('admin_status')}",
        f"Platform: {snapshot.get('platform')}",
    ]
    if details:
        entry.extend(["", "Details:", details])
    entry.append("")
    with path.open("a", encoding="utf-8", errors="replace") as f:
        f.write("\n".join(entry))
    return path


def set_last_action(action: str) -> None:
    global _LAST_ACTION
    _LAST_ACTION = action or "Unknown action"
    try:
        (diagnostics_root() / "last_action.txt").write_text(_LAST_ACTION, encoding="utf-8")
    except Exception:
        pass
    log_event("ACTION", _LAST_ACTION)


def log_exception(context: str, exc_info=None) -> str:
    if exc_info is None:
        exc_info = sys.exc_info()
    if isinstance(exc_info, BaseException):
        tb = "".join(traceback.format_exception(type(exc_info), exc_info, exc_info.__traceback__))
    else:
        tb = "".join(traceback.format_exception(*exc_info))
    log_event("EXCEPTION", context, tb)
    return tb


def log_qt_message(level: str, message: str, source: str = "") -> None:
    log_event("QT", message, f"Qt level: {level}\nSource: {source}\nMessage: {message}")


def _global_exception_hook(exc_type, exc, tb):
    tb_text = "".join(traceback.format_exception(exc_type, exc, tb))
    log_event("UNCAUGHT_EXCEPTION", str(exc), tb_text)
    if _PREVIOUS_EXCEPTHOOK and _PREVIOUS_EXCEPTHOOK is not _global_exception_hook:
        try:
            _PREVIOUS_EXCEPTHOOK(exc_type, exc, tb)
        except Exception:
            pass


def _threading_exception_hook(args):
    tb_text = "".join(traceback.format_exception(args.exc_type, args.exc_value, args.exc_traceback))
    log_event("THREAD_EXCEPTION", str(args.exc_value), tb_text)
    if _PREVIOUS_THREADING_EXCEPTHOOK and _PREVIOUS_THREADING_EXCEPTHOOK is not _threading_exception_hook:
        try:
            _PREVIOUS_THREADING_EXCEPTHOOK(args)
        except Exception:
            pass


def install_global_exception_hook() -> None:
    global _PREVIOUS_EXCEPTHOOK, _PREVIOUS_THREADING_EXCEPTHOOK
    if sys.excepthook is not _global_exception_hook:
        _PREVIOUS_EXCEPTHOOK = sys.excepthook
        sys.excepthook = _global_exception_hook
    if hasattr(threading, "excepthook") and threading.excepthook is not _threading_exception_hook:
        _PREVIOUS_THREADING_EXCEPTHOOK = threading.excepthook
        threading.excepthook = _threading_exception_hook
    try:
        write_json(diagnostics_root() / "system_snapshot.json", system_snapshot())
        log_event("STARTUP", "Global diagnostics hook installed.")
    except Exception:
        pass


def export_support_zip(destination: str | Path | None = None) -> Path:
    install_global_exception_hook()
    zip_path = Path(destination) if destination else support_root() / f"OpenSourceITTool_Support_{now_stamp()}.zip"
    zip_path.parent.mkdir(parents=True, exist_ok=True)

    snapshot_path = diagnostics_root() / "system_snapshot.json"
    write_json(snapshot_path, system_snapshot())
    try:
        (diagnostics_root() / "last_action.txt").write_text(get_last_action(), encoding="utf-8")
    except Exception:
        pass

    with zipfile.ZipFile(zip_path, "w", compression=zipfile.ZIP_DEFLATED) as z:
        diag_root = diagnostics_root()
        for path in diag_root.rglob("*"):
            if path.is_file():
                z.write(path, arcname=Path("diagnostics") / path.relative_to(diag_root))

        root_logs = logs_root()
        for path in root_logs.rglob("*"):
            if path.is_file() and path.stat().st_size <= 5 * 1024 * 1024:
                z.write(path, arcname=Path("logs") / path.relative_to(root_logs))

        for name in ["README.md", "DEVELOPER_NOTES.md", "requirements.txt", "build_exe.bat"]:
            candidate = app_dir() / name
            if candidate.exists() and candidate.is_file():
                z.write(candidate, arcname=Path("project") / name)

        z.writestr("system_snapshot.json", json.dumps(system_snapshot(), indent=2, default=str))

    log_event("SUPPORT_ZIP", f"Support ZIP created: {zip_path}")
    return zip_path
